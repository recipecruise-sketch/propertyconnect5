import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
      '@/components': path.resolve(__dirname, './src/components'),
      '@/screens': path.resolve(__dirname, './src/screens'),
      '@/widgets': path.resolve(__dirname, './src/widgets'),
      '@/theme': path.resolve(__dirname, './src/theme'),
      '@/routes': path.resolve(__dirname, './src/routes')
    }
  },
  server: {
    port: 3000,
    host: '0.0.0.0'
  }
})
