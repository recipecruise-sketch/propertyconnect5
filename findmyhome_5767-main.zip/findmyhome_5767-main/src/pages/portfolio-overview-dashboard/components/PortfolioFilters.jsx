import React, { useState } from 'react';
import Select from '../../../components/ui/Select';
import Input from '../../../components/ui/Input';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const PortfolioFilters = ({ onFiltersChange, initialFilters = {} }) => {
  const [filters, setFilters] = useState({
    properties: initialFilters?.properties || [],
    dateRange: initialFilters?.dateRange || 'last30',
    propertyType: initialFilters?.propertyType || '',
    location: initialFilters?.location || '',
    customDateStart: initialFilters?.customDateStart || '',
    customDateEnd: initialFilters?.customDateEnd || '',
    ...initialFilters
  });

  const [isExpanded, setIsExpanded] = useState(false);

  const propertyOptions = [
    { value: 'all', label: 'All Properties' },
    { value: 'residential', label: 'Residential Only' },
    { value: 'commercial', label: 'Commercial Only' },
    { value: 'mixed', label: 'Mixed Use' }
  ];

  const dateRangeOptions = [
    { value: 'last30', label: 'Last 30 Days' },
    { value: 'last90', label: 'Last 90 Days' },
    { value: 'last6months', label: 'Last 6 Months' },
    { value: 'last12months', label: 'Last 12 Months' },
    { value: 'ytd', label: 'Year to Date' },
    { value: 'last5years', label: 'Last 5 Years' },
    { value: 'custom', label: 'Custom Range' }
  ];

  const propertyTypeOptions = [
    { value: '', label: 'All Types' },
    { value: '1 room studio apartment', label: '1 room studio apartment' },
    { value: '1 bedroom apartment or duplex', label: '1 bedroom apartment or duplex' },
    { value: '2 bedroom apartment or duplex', label: '2 bedroom apartment or duplex' },
    { value: '3 bedroom apartment or duplex', label: '3 bedroom apartment or duplex' }
  ];

  const locationOptions = [
    { value: '', label: 'All Locations' },
    { value: 'downtown', label: 'Downtown District' },
    { value: 'suburbs', label: 'Suburban Areas' },
    { value: 'waterfront', label: 'Waterfront Properties' },
    { value: 'business-district', label: 'Business District' },
    { value: 'university-area', label: 'University Area' },
    { value: 'historic-district', label: 'Historic District' }
  ];

  const handleFilterChange = (key, value) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    onFiltersChange(newFilters);
  };

  const clearFilters = () => {
    const clearedFilters = {
      properties: [],
      dateRange: 'last30',
      propertyType: '',
      location: '',
      customDateStart: '',
      customDateEnd: ''
    };
    setFilters(clearedFilters);
    onFiltersChange(clearedFilters);
  };

  const hasActiveFilters = () => {
    return filters?.properties?.length > 0 || 
           filters?.propertyType || 
           filters?.location || 
           filters?.dateRange !== 'last30';
  };

  return (
    <div className="bg-white border border-border rounded-lg shadow-elevation-1">
      <div className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Icon name="Filter" size={20} color="var(--color-primary)" />
            <h3 className="text-lg font-semibold text-foreground">Portfolio Filters</h3>
            {hasActiveFilters() && (
              <span className="px-2 py-1 bg-primary/10 text-primary text-xs font-medium rounded-full">
                {Object.values(filters)?.filter(v => v && (Array.isArray(v) ? v?.length > 0 : true))?.length} active
              </span>
            )}
          </div>
          
          <div className="flex items-center space-x-2">
            {hasActiveFilters() && (
              <Button
                variant="ghost"
                size="sm"
                iconName="RotateCcw"
                onClick={clearFilters}
              >
                Clear
              </Button>
            )}
            
            <Button
              variant="outline"
              size="sm"
              iconName={isExpanded ? "ChevronUp" : "ChevronDown"}
              onClick={() => setIsExpanded(!isExpanded)}
            >
              {isExpanded ? 'Less' : 'More'}
            </Button>
          </div>
        </div>

        {/* Primary Filters - Always Visible */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-4">
          <Select
            label="Properties"
            options={propertyOptions}
            value={filters?.properties}
            onChange={(value) => handleFilterChange('properties', value)}
            multiple
            placeholder="Select properties..."
          />
          
          <Select
            label="Date Range"
            options={dateRangeOptions}
            value={filters?.dateRange}
            onChange={(value) => handleFilterChange('dateRange', value)}
            placeholder="Select date range..."
          />
          
          <Select
            label="Property Type"
            options={propertyTypeOptions}
            value={filters?.propertyType}
            onChange={(value) => handleFilterChange('propertyType', value)}
            placeholder="All types"
          />
        </div>

        {/* Custom Date Range */}
        {filters?.dateRange === 'custom' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
            <Input
              label="Start Date"
              type="date"
              value={filters?.customDateStart}
              onChange={(e) => handleFilterChange('customDateStart', e?.target?.value)}
            />
            
            <Input
              label="End Date"
              type="date"
              value={filters?.customDateEnd}
              onChange={(e) => handleFilterChange('customDateEnd', e?.target?.value)}
            />
          </div>
        )}

        {/* Expanded Filters */}
        {isExpanded && (
          <div className="mt-6 pt-4 border-t border-border">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <Select
                label="Location"
                options={locationOptions}
                value={filters?.location}
                onChange={(value) => handleFilterChange('location', value)}
                placeholder="All locations"
              />
              
              <div className="flex items-end">
                <Button
                  variant="primary"
                  iconName="Search"
                  iconPosition="left"
                  className="w-full"
                >
                  Apply Filters
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PortfolioFilters;
