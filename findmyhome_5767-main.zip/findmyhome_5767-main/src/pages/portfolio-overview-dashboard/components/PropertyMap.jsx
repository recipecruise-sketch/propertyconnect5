import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const PropertyMap = ({ properties, onPropertySelect, selectedProperty }) => {
  const [mapView, setMapView] = useState('satellite');
  const [showFilters, setShowFilters] = useState(false);

  const getMarkerColor = (occupancyRate) => {
    if (occupancyRate >= 90) return 'bg-success';
    if (occupancyRate >= 70) return 'bg-warning';
    return 'bg-error';
  };

  const getMarkerSize = (value) => {
    if (value >= 1000000) return 'w-6 h-6';
    if (value >= 500000) return 'w-5 h-5';
    return 'w-4 h-4';
  };

  return (
    <div className="bg-white border border-border rounded-lg shadow-elevation-1 overflow-hidden">
      {/* Map Header */}
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Icon name="Map" size={20} color="var(--color-primary)" />
            <h3 className="text-lg font-semibold text-foreground">Property Locations</h3>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              iconName="Filter"
              onClick={() => setShowFilters(!showFilters)}
            >
              Filters
            </Button>
            
            <div className="flex items-center bg-muted rounded-lg p-1">
              <button
                onClick={() => setMapView('satellite')}
                className={`px-3 py-1 text-sm rounded transition-smooth ${
                  mapView === 'satellite' ?'bg-white text-foreground shadow-sm' :'text-muted-foreground hover:text-foreground'
                }`}
              >
                Satellite
              </button>
              <button
                onClick={() => setMapView('street')}
                className={`px-3 py-1 text-sm rounded transition-smooth ${
                  mapView === 'street' ?'bg-white text-foreground shadow-sm' :'text-muted-foreground hover:text-foreground'
                }`}
              >
                Street
              </button>
            </div>
          </div>
        </div>
        
        {showFilters && (
          <div className="mt-4 p-3 bg-muted/30 rounded-lg">
            <div className="flex items-center space-x-4 text-sm">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-success rounded-full"></div>
                <span>High Occupancy (90%+)</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-warning rounded-full"></div>
                <span>Medium Occupancy (70-89%)</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-error rounded-full"></div>
                <span>Low Occupancy (&lt;70%)</span>
              </div>
            </div>
          </div>
        )}
      </div>
      {/* Map Container */}
      <div className="relative h-96 bg-muted">
        {/* Google Maps Iframe */}
        <iframe
          width="100%"
          height="100%"
          loading="lazy"
          title="Property Portfolio Map"
          referrerPolicy="no-referrer-when-downgrade"
          src="https://www.google.com/maps?q=40.7128,-74.0060&z=12&output=embed"
          className="absolute inset-0"
        />
        
        {/* Property Markers Overlay */}
        <div className="absolute inset-0 pointer-events-none">
          {properties?.map((property, index) => (
            <div
              key={property?.id}
              className="absolute pointer-events-auto cursor-pointer transform -translate-x-1/2 -translate-y-1/2"
              style={{
                left: `${20 + (index % 5) * 15}%`,
                top: `${30 + Math.floor(index / 5) * 20}%`
              }}
              onClick={() => onPropertySelect(property)}
            >
              <div
                className={`
                  ${getMarkerSize(property?.value)} ${getMarkerColor(property?.occupancyRate)}
                  rounded-full border-2 border-white shadow-elevation-2 hover:scale-110 transition-smooth
                  ${selectedProperty?.id === property?.id ? 'ring-2 ring-primary' : ''}
                `}
              />
              
              {selectedProperty?.id === property?.id && (
                <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-2 bg-white border border-border rounded-lg shadow-elevation-2 p-3 min-w-48 z-10">
                  <h4 className="font-semibold text-foreground mb-2">{property?.name}</h4>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Value:</span>
                      <span className="font-medium">{property?.value}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Occupancy:</span>
                      <span className="font-medium">{property?.occupancyRate}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Monthly Income:</span>
                      <span className="font-medium">{property?.monthlyIncome}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
        
        {/* Map Controls */}
        <div className="absolute top-4 right-4 flex flex-col space-y-2">
          <Button variant="outline" size="sm" iconName="Plus" />
          <Button variant="outline" size="sm" iconName="Minus" />
          <Button variant="outline" size="sm" iconName="Maximize2" />
        </div>
      </div>
    </div>
  );
};

export default PropertyMap;