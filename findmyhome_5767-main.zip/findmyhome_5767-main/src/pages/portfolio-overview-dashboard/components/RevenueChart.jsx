import React, { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar } from 'recharts';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const RevenueChart = ({ data, loading = false }) => {
  const [chartType, setChartType] = useState('line');
  const [showOverlay, setShowOverlay] = useState({
    expenses: true,
    netProfit: true
  });

  const toggleOverlay = (type) => {
    setShowOverlay(prev => ({
      ...prev,
      [type]: !prev?.[type]
    }));
  };

  if (loading) {
    return (
      <div className="bg-white border border-border rounded-lg p-6 shadow-elevation-1">
        <div className="animate-pulse">
          <div className="flex items-center justify-between mb-6">
            <div className="h-6 bg-muted rounded w-48"></div>
            <div className="flex space-x-2">
              <div className="h-8 w-20 bg-muted rounded"></div>
              <div className="h-8 w-20 bg-muted rounded"></div>
            </div>
          </div>
          <div className="h-80 bg-muted rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white border border-border rounded-lg shadow-elevation-1">
      <div className="p-6 border-b border-border">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Icon name="TrendingUp" size={20} color="var(--color-primary)" />
            <h3 className="text-lg font-semibold text-foreground">Revenue Trends</h3>
          </div>
          
          <div className="flex items-center space-x-4">
            {/* Chart Type Toggle */}
            <div className="flex items-center bg-muted rounded-lg p-1">
              <button
                onClick={() => setChartType('line')}
                className={`px-3 py-1 text-sm rounded transition-smooth ${
                  chartType === 'line' ?'bg-white text-foreground shadow-sm' :'text-muted-foreground hover:text-foreground'
                }`}
              >
                Line
              </button>
              <button
                onClick={() => setChartType('bar')}
                className={`px-3 py-1 text-sm rounded transition-smooth ${
                  chartType === 'bar' ?'bg-white text-foreground shadow-sm' :'text-muted-foreground hover:text-foreground'
                }`}
              >
                Bar
              </button>
            </div>
            
            <Button variant="outline" size="sm" iconName="Download">
              Export
            </Button>
          </div>
        </div>
        
        {/* Legend Controls */}
        <div className="flex items-center space-x-6 mt-4">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 bg-primary rounded-full"></div>
            <span className="text-sm text-foreground">Revenue</span>
          </div>
          
          <button
            onClick={() => toggleOverlay('expenses')}
            className={`flex items-center space-x-2 transition-smooth ${
              showOverlay?.expenses ? 'opacity-100' : 'opacity-50'
            }`}
          >
            <div className="w-3 h-3 bg-error rounded-full"></div>
            <span className="text-sm text-foreground">Expenses</span>
          </button>
          
          <button
            onClick={() => toggleOverlay('netProfit')}
            className={`flex items-center space-x-2 transition-smooth ${
              showOverlay?.netProfit ? 'opacity-100' : 'opacity-50'
            }`}
          >
            <div className="w-3 h-3 bg-success rounded-full"></div>
            <span className="text-sm text-foreground">Net Profit</span>
          </button>
        </div>
      </div>
      <div className="p-6">
        <div className="h-80">
          <ResponsiveContainer width="100%" height="100%">
            {chartType === 'line' ? (
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis 
                  dataKey="month" 
                  stroke="var(--color-muted-foreground)"
                  fontSize={12}
                />
                <YAxis 
                  stroke="var(--color-muted-foreground)"
                  fontSize={12}
                  tickFormatter={(value) => `₦${(value / 1000)?.toFixed(0)}K`}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: 'white',
                    border: '1px solid var(--color-border)',
                    borderRadius: '8px',
                    boxShadow: 'var(--shadow-md)'
                  }}
                  formatter={(value, name) => [`₦${value?.toLocaleString()}`, name]}
                />
                <Legend />
                
                <Line 
                  type="monotone" 
                  dataKey="revenue" 
                  stroke="var(--color-primary)" 
                  strokeWidth={3}
                  dot={{ fill: 'var(--color-primary)', strokeWidth: 2, r: 4 }}
                  activeDot={{ r: 6, stroke: 'var(--color-primary)', strokeWidth: 2 }}
                />
                
                {showOverlay?.expenses && (
                  <Line 
                    type="monotone" 
                    dataKey="expenses" 
                    stroke="var(--color-error)" 
                    strokeWidth={2}
                    strokeDasharray="5 5"
                    dot={{ fill: 'var(--color-error)', strokeWidth: 2, r: 3 }}
                  />
                )}
                
                {showOverlay?.netProfit && (
                  <Line 
                    type="monotone" 
                    dataKey="netProfit" 
                    stroke="var(--color-success)" 
                    strokeWidth={2}
                    dot={{ fill: 'var(--color-success)', strokeWidth: 2, r: 3 }}
                  />
                )}
              </LineChart>
            ) : (
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
                <XAxis 
                  dataKey="month" 
                  stroke="var(--color-muted-foreground)"
                  fontSize={12}
                />
                <YAxis 
                  stroke="var(--color-muted-foreground)"
                  fontSize={12}
                  tickFormatter={(value) => `₦${(value / 1000)?.toFixed(0)}K`}
                />
                <Tooltip 
                  contentStyle={{
                    backgroundColor: 'white',
                    border: '1px solid var(--color-border)',
                    borderRadius: '8px',
                    boxShadow: 'var(--shadow-md)'
                  }}
                  formatter={(value, name) => [`₦${value?.toLocaleString()}`, name]}
                />
                <Legend />
                
                <Bar dataKey="revenue" fill="var(--color-primary)" radius={[4, 4, 0, 0]} />
                
                {showOverlay?.expenses && (
                  <Bar dataKey="expenses" fill="var(--color-error)" radius={[4, 4, 0, 0]} />
                )}
                
                {showOverlay?.netProfit && (
                  <Bar dataKey="netProfit" fill="var(--color-success)" radius={[4, 4, 0, 0]} />
                )}
              </BarChart>
            )}
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};

export default RevenueChart;
