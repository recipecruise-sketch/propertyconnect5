import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const PropertyRankingTable = ({ properties, onPropertySelect }) => {
  const [sortBy, setSortBy] = useState('roi');
  const [sortOrder, setSortOrder] = useState('desc');

  const sortedProperties = [...properties]?.sort((a, b) => {
    const aValue = a?.[sortBy];
    const bValue = b?.[sortBy];
    
    if (sortOrder === 'asc') {
      return aValue > bValue ? 1 : -1;
    }
    return aValue < bValue ? 1 : -1;
  });

  const handleSort = (field) => {
    if (sortBy === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortBy(field);
      setSortOrder('desc');
    }
  };

  const getPerformanceColor = (value, type) => {
    if (type === 'occupancy') {
      if (value >= 90) return 'text-success';
      if (value >= 70) return 'text-warning';
      return 'text-error';
    }
    if (type === 'roi') {
      if (value >= 8) return 'text-success';
      if (value >= 5) return 'text-warning';
      return 'text-error';
    }
    return 'text-foreground';
  };

  const getPerformanceIcon = (value, type) => {
    if (type === 'occupancy') {
      if (value >= 90) return 'TrendingUp';
      if (value >= 70) return 'Minus';
      return 'TrendingDown';
    }
    if (type === 'roi') {
      if (value >= 8) return 'TrendingUp';
      if (value >= 5) return 'Minus';
      return 'TrendingDown';
    }
    return 'Minus';
  };

  return (
    <div className="bg-white border border-border rounded-lg shadow-elevation-1">
      <div className="p-4 border-b border-border">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Icon name="BarChart3" size={20} color="var(--color-primary)" />
            <h3 className="text-lg font-semibold text-foreground">Property Performance</h3>
          </div>
          
          <Button variant="outline" size="sm" iconName="MoreVertical" />
        </div>
      </div>
      <div className="overflow-hidden">
        {/* Table Header */}
        <div className="px-4 py-3 bg-muted/30 border-b border-border">
          <div className="grid grid-cols-12 gap-4 text-sm font-medium text-muted-foreground">
            <div className="col-span-4">Property</div>
            <div 
              className="col-span-2 cursor-pointer hover:text-foreground flex items-center space-x-1"
              onClick={() => handleSort('occupancyRate')}
            >
              <span>Occupancy</span>
              <Icon 
                name={sortBy === 'occupancyRate' && sortOrder === 'asc' ? 'ChevronUp' : 'ChevronDown'} 
                size={14} 
              />
            </div>
            <div 
              className="col-span-2 cursor-pointer hover:text-foreground flex items-center space-x-1"
              onClick={() => handleSort('roi')}
            >
              <span>ROI</span>
              <Icon 
                name={sortBy === 'roi' && sortOrder === 'asc' ? 'ChevronUp' : 'ChevronDown'} 
                size={14} 
              />
            </div>
            <div 
              className="col-span-2 cursor-pointer hover:text-foreground flex items-center space-x-1"
              onClick={() => handleSort('monthlyIncome')}
            >
              <span>Income</span>
              <Icon 
                name={sortBy === 'monthlyIncome' && sortOrder === 'asc' ? 'ChevronUp' : 'ChevronDown'} 
                size={14} 
              />
            </div>
            <div className="col-span-2">Actions</div>
          </div>
        </div>

        {/* Table Body */}
        <div className="max-h-96 overflow-y-auto">
          {sortedProperties?.map((property, index) => (
            <div
              key={property?.id}
              className="px-4 py-3 border-b border-border hover:bg-muted/20 transition-smooth cursor-pointer"
              onClick={() => onPropertySelect(property)}
            >
              <div className="grid grid-cols-12 gap-4 items-center">
                <div className="col-span-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-8 h-8 bg-primary/10 rounded-lg flex items-center justify-center">
                      <span className="text-sm font-bold text-primary">#{index + 1}</span>
                    </div>
                    <div>
                      <p className="font-medium text-foreground">{property?.name}</p>
                      <p className="text-sm text-muted-foreground">{property?.location}</p>
                    </div>
                  </div>
                </div>
                
                <div className="col-span-2">
                  <div className="flex items-center space-x-2">
                    <Icon 
                      name={getPerformanceIcon(property?.occupancyRate, 'occupancy')} 
                      size={14} 
                      color={getPerformanceColor(property?.occupancyRate, 'occupancy')?.replace('text-', 'var(--color-')}
                    />
                    <span className={`font-medium ${getPerformanceColor(property?.occupancyRate, 'occupancy')}`}>
                      {property?.occupancyRate}%
                    </span>
                  </div>
                </div>
                
                <div className="col-span-2">
                  <div className="flex items-center space-x-2">
                    <Icon 
                      name={getPerformanceIcon(property?.roi, 'roi')} 
                      size={14} 
                      color={getPerformanceColor(property?.roi, 'roi')?.replace('text-', 'var(--color-')}
                    />
                    <span className={`font-medium ${getPerformanceColor(property?.roi, 'roi')}`}>
                      {property?.roi}%
                    </span>
                  </div>
                </div>
                
                <div className="col-span-2">
                  <span className="font-medium text-foreground">{property?.monthlyIncome}</span>
                </div>
                
                <div className="col-span-2">
                  <div className="flex items-center space-x-1">
                    <Button variant="ghost" size="sm" iconName="Eye" />
                    <Button variant="ghost" size="sm" iconName="Edit" />
                    <Button variant="ghost" size="sm" iconName="MoreHorizontal" />
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default PropertyRankingTable;