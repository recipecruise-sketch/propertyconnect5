import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import GlobalFilterBar, { FilterProvider } from '../../components/ui/GlobalFilterBar';
import RealTimeStatusIndicator, { StatusProvider } from '../../components/ui/RealTimeStatusIndicator';
import ExportControlPanel, { ExportProvider } from '../../components/ui/ExportControlPanel';
import KPICard from './components/KPICard';
import PropertyMap from './components/PropertyMap';
import PropertyRankingTable from './components/PropertyRankingTable';
import RevenueChart from './components/RevenueChart';
import PortfolioFilters from './components/PortfolioFilters';

const PortfolioOverviewDashboard = () => {
  const [selectedProperty, setSelectedProperty] = useState(null);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    properties: [],
    dateRange: 'last30',
    propertyType: '',
    location: ''
  });

  // Mock data for KPI cards
  const kpiData = [
    {
      title: 'Total Portfolio Value',
      value: '₦12.4M',
      change: '+8.2%',
      changeType: 'positive',
      icon: 'DollarSign',
      trend: [65, 72, 68, 75, 82, 78, 85, 88, 92, 89, 95, 100]
    },
    {
      title: 'Monthly Rental Income',
      value: '₦89,500',
      change: '+5.7%',
      changeType: 'positive',
      icon: 'TrendingUp',
      trend: [70, 75, 73, 78, 85, 82, 88, 91, 87, 93, 96, 100]
    },
    {
      title: 'Overall Occupancy Rate',
      value: '94.2%',
      change: '+2.1%',
      changeType: 'positive',
      icon: 'Home',
      trend: [85, 87, 89, 91, 88, 92, 94, 96, 93, 95, 97, 100]
    },
    {
      title: 'Net ROI',
      value: '11.8%',
      change: '-0.3%',
      changeType: 'negative',
      icon: 'Target',
      trend: [100, 98, 95, 97, 94, 92, 90, 88, 91, 89, 87, 85]
    }
  ];

  // Mock data for properties
  const propertiesData = [
    {
      id: 1,
      name: 'Sunset Apartments',
      location: 'Downtown District',
      value: '₦2.1M',
      occupancyRate: 96,
      monthlyIncome: '₦18,500',
      roi: 12.4,
      lat: 40.7128,
      lng: -74.0060
    },
    {
      id: 2,
      name: 'Riverside Condos',
      location: 'Waterfront',
      value: '₦3.2M',
      occupancyRate: 92,
      monthlyIncome: '₦24,800',
      roi: 10.8,
      lat: 40.7589,
      lng: -73.9851
    },
    {
      id: 3,
      name: 'Metro Office Complex',
      location: 'Business District',
      value: '₦4.8M',
      occupancyRate: 88,
      monthlyIncome: '₦32,200',
      roi: 9.6,
      lat: 40.7505,
      lng: -73.9934
    },
    {
      id: 4,
      name: 'Garden View Townhouses',
      location: 'Suburban Areas',
      value: '₦1.8M',
      occupancyRate: 100,
      monthlyIncome: '₦14,000',
      roi: 13.2,
      lat: 40.7282,
      lng: -74.0776
    },
    {
      id: 5,
      name: 'University Heights',
      location: 'University Area',
      value: '₦2.5M',
      occupancyRate: 94,
      monthlyIncome: '₦19,800',
      roi: 11.5,
      lat: 40.8176,
      lng: -73.9482
    }
  ];

  // Mock data for revenue chart
  const revenueData = [
    { month: 'Jan', revenue: 82000, expenses: 45000, netProfit: 37000 },
    { month: 'Feb', revenue: 85000, expenses: 47000, netProfit: 38000 },
    { month: 'Mar', revenue: 88000, expenses: 48000, netProfit: 40000 },
    { month: 'Apr', revenue: 91000, expenses: 49000, netProfit: 42000 },
    { month: 'May', revenue: 87000, expenses: 46000, netProfit: 41000 },
    { month: 'Jun', revenue: 93000, expenses: 50000, netProfit: 43000 },
    { month: 'Jul', revenue: 96000, expenses: 51000, netProfit: 45000 },
    { month: 'Aug', revenue: 89000, expenses: 48000, netProfit: 41000 },
    { month: 'Sep', revenue: 92000, expenses: 49000, netProfit: 43000 },
    { month: 'Oct', revenue: 95000, expenses: 52000, netProfit: 43000 },
    { month: 'Nov', revenue: 89500, expenses: 48500, netProfit: 41000 },
    { month: 'Dec', revenue: 98000, expenses: 53000, netProfit: 45000 }
  ];

  useEffect(() => {
    // Simulate loading
    const timer = setTimeout(() => {
      setLoading(false);
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  const handlePropertySelect = (property) => {
    setSelectedProperty(property);
  };

  const handleFiltersChange = (newFilters) => {
    setFilters(newFilters);
    // In real implementation, this would trigger data refetch
    console.log('Filters changed:', newFilters);
  };

  return (
    <FilterProvider>
      <StatusProvider>
        <ExportProvider>
          <div className="min-h-screen bg-muted/30">
            <Helmet>
              <title>Portfolio Overview - FindMyHome Analytics</title>
              <meta name="description" content="Comprehensive property portfolio analytics dashboard with real-time insights and performance metrics" />
            </Helmet>

            <Header />
            <GlobalFilterBar />
            
            <main className="pt-32 pb-8">
              <div className="max-w-7xl mx-auto px-6 space-y-6">
                {/* Portfolio Filters */}
                <PortfolioFilters 
                  onFiltersChange={handleFiltersChange}
                  initialFilters={filters}
                />

                {/* KPI Cards Row */}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                  {kpiData?.map((kpi, index) => (
                    <KPICard
                      key={index}
                      title={kpi?.title}
                      value={kpi?.value}
                      change={kpi?.change}
                      changeType={kpi?.changeType}
                      icon={kpi?.icon}
                      trend={kpi?.trend}
                      loading={loading}
                    />
                  ))}
                </div>

                {/* Main Content Grid */}
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                  {/* Property Map */}
                  <div className="lg:col-span-8">
                    <PropertyMap
                      properties={propertiesData}
                      onPropertySelect={handlePropertySelect}
                      selectedProperty={selectedProperty}
                    />
                  </div>

                  {/* Property Ranking Table */}
                  <div className="lg:col-span-4">
                    <PropertyRankingTable
                      properties={propertiesData}
                      onPropertySelect={handlePropertySelect}
                    />
                  </div>
                </div>

                {/* Revenue Chart */}
                <div className="w-full">
                  <RevenueChart
                    data={revenueData}
                    loading={loading}
                  />
                </div>
              </div>
            </main>

            {/* Real-time Status Indicator */}
            <RealTimeStatusIndicator position="floating" />
            
            {/* Export Control Panel */}
            <ExportControlPanel position="floating" />
          </div>
        </ExportProvider>
      </StatusProvider>
    </FilterProvider>
  );
};

export default PortfolioOverviewDashboard;
