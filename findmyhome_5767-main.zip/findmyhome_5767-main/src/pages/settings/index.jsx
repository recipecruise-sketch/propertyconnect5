import React, { useEffect, useMemo, useState } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Settings, Moon, Sun, Bell, Globe, Shield, Database, Download } from 'lucide-react';

const SettingsPage = () => {
  const navigate = useNavigate();
  const [theme, setTheme] = useState(() => localStorage.getItem('theme') || 'light');
  const [emailNotifs, setEmailNotifs] = useState(() => localStorage.getItem('emailNotifs') !== 'false');
  const [pushNotifs, setPushNotifs] = useState(() => localStorage.getItem('pushNotifs') !== 'false');
  const [language, setLanguage] = useState(() => localStorage.getItem('language') || 'en');
  const [currency, setCurrency] = useState(() => localStorage.getItem('currency') || 'NGN');
  const [publicProfile, setPublicProfile] = useState(() => localStorage.getItem('publicProfile') !== 'false');

  useEffect(() => {
    document.documentElement.classList.toggle('dark', theme === 'dark');
    localStorage.setItem('theme', theme);
  }, [theme]);

  useEffect(() => { localStorage.setItem('emailNotifs', String(emailNotifs)); }, [emailNotifs]);
  useEffect(() => { localStorage.setItem('pushNotifs', String(pushNotifs)); }, [pushNotifs]);
  useEffect(() => { localStorage.setItem('language', language); }, [language]);
  useEffect(() => { localStorage.setItem('currency', currency); }, [currency]);
  useEffect(() => { localStorage.setItem('publicProfile', String(publicProfile)); }, [publicProfile]);

  const exportData = () => {
    const data = { theme, emailNotifs, pushNotifs, language, currency, publicProfile };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'settings-export.json'; a.click();
    URL.revokeObjectURL(url);
  };

  const resetDefaults = () => {
    setTheme('light'); setEmailNotifs(true); setPushNotifs(true); setLanguage('en'); setCurrency('NGN'); setPublicProfile(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      <Helmet>
        <title>Settings - Findmyhome</title>
        <meta name="description" content="Application settings and preferences" />
      </Helmet>

      <div className="bg-white/80 backdrop-blur-sm border-b border-white/20 shadow-sm sticky top-0 z-40">
        <div className="max-w-screen-md w-full mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-lg transition-colors" aria-label="Back">
              <ArrowLeft className="w-5 h-5 text-gray-600" />
            </button>
            <h1 className="text-xl font-bold text-gray-900">Settings</h1>
          </div>
          <div className="flex items-center space-x-2">
            <button onClick={resetDefaults} className="text-sm text-gray-600 hover:text-gray-900">Reset</button>
            <button onClick={exportData} className="text-sm text-blue-600 hover:text-blue-700 flex items-center space-x-1">
              <Download className="w-4 h-4" />
              <span>Export</span>
            </button>
          </div>
        </div>
      </div>

      <main className="max-w-screen-md w-full mx-auto px-4 py-4 pb-20 space-y-4">
        <section className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-4 shadow-sm">
          <div className="flex items-center space-x-2 mb-3">
            <Settings className="w-4 h-4 text-gray-600" />
            <h2 className="text-sm font-semibold text-gray-900">Appearance</h2>
          </div>
          <div className="flex items-center justify-between">
            <div className="text-sm text-gray-700">Theme</div>
            <div className="flex items-center space-x-2">
              <button onClick={() => setTheme('light')} className={`px-3 py-1.5 text-sm rounded-lg border ${theme==='light'?'bg-blue-500 text-white border-blue-500':'border-gray-300 text-gray-700'}`}><Sun className="w-4 h-4 inline mr-1"/>Light</button>
              <button onClick={() => setTheme('dark')} className={`px-3 py-1.5 text-sm rounded-lg border ${theme==='dark'?'bg-blue-500 text-white border-blue-500':'border-gray-300 text-gray-700'}`}><Moon className="w-4 h-4 inline mr-1"/>Dark</button>
            </div>
          </div>
        </section>

        <section className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-4 shadow-sm">
          <div className="flex items-center space-x-2 mb-3">
            <Bell className="w-4 h-4 text-gray-600" />
            <h2 className="text-sm font-semibold text-gray-900">Notifications</h2>
          </div>
          <div className="space-y-3">
            <label className="flex items-center justify-between text-sm">
              <span>Email Notifications</span>
              <input type="checkbox" className="w-4 h-4" checked={emailNotifs} onChange={(e)=>setEmailNotifs(e.target.checked)} />
            </label>
            <label className="flex items-center justify-between text-sm">
              <span>Push Notifications</span>
              <input type="checkbox" className="w-4 h-4" checked={pushNotifs} onChange={(e)=>setPushNotifs(e.target.checked)} />
            </label>
          </div>
        </section>

        <section className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-4 shadow-sm">
          <div className="flex items-center space-x-2 mb-3">
            <Globe className="w-4 h-4 text-gray-600" />
            <h2 className="text-sm font-semibold text-gray-900">Localization</h2>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm">
            <label className="flex items-center justify-between">
              <span>Language</span>
              <select value={language} onChange={(e)=>setLanguage(e.target.value)} className="border border-gray-300 rounded px-2 py-1">
                <option value="en">English</option>
                <option value="yo">Yorùbá</option>
                <option value="ha">Hausa</option>
                <option value="ig">Igbo</option>
              </select>
            </label>
            <label className="flex items-center justify-between">
              <span>Currency</span>
              <select value={currency} onChange={(e)=>setCurrency(e.target.value)} className="border border-gray-300 rounded px-2 py-1">
                <option value="NGN">₦ NGN</option>
                <option value="USD">$ USD</option>
                <option value="EUR">€ EUR</option>
              </select>
            </label>
          </div>
        </section>

        <section className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-4 shadow-sm">
          <div className="flex items-center space-x-2 mb-3">
            <Shield className="w-4 h-4 text-gray-600" />
            <h2 className="text-sm font-semibold text-gray-900">Privacy</h2>
          </div>
          <label className="flex items-center justify-between text-sm">
            <span>Public Profile</span>
            <input type="checkbox" className="w-4 h-4" checked={publicProfile} onChange={(e)=>setPublicProfile(e.target.checked)} />
          </label>
        </section>

        <section className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-4 shadow-sm">
          <div className="flex items-center space-x-2 mb-3">
            <Database className="w-4 h-4 text-gray-600" />
            <h2 className="text-sm font-semibold text-gray-900">Data</h2>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span>Clear cached settings</span>
            <button
              onClick={() => { localStorage.clear(); resetDefaults(); }}
              className="px-3 py-1.5 rounded-lg border border-red-200 text-red-600 hover:bg-red-50"
            >
              Clear
            </button>
          </div>
        </section>
      </main>
    </div>
  );
};

export default SettingsPage;
