import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import GlobalFilterBar, { FilterProvider } from '../../components/ui/GlobalFilterBar';
import RealTimeStatusIndicator, { StatusProvider } from '../../components/ui/RealTimeStatusIndicator';
import ExportControlPanel, { ExportProvider } from '../../components/ui/ExportControlPanel';
import MetricsStrip from './components/MetricsStrip';
import RevenueExpenseChart from './components/RevenueExpenseChart';
import ExpenseBreakdownChart from './components/ExpenseBreakdownChart';
import CashFlowForecast from './components/CashFlowForecast';
import GlobalControls from './components/GlobalControls';

const FinancialAnalyticsDashboard = () => {
  const [selectedProperties, setSelectedProperties] = useState('all');
  const [fiscalPeriod, setFiscalPeriod] = useState('current-year');
  const [comparisonMode, setComparisonMode] = useState('yoy');
  const [lastUpdated, setLastUpdated] = useState(new Date());
  const [isLoading, setIsLoading] = useState(false);

  // Mock data for financial metrics
  const metricsData = [
    {
      id: 'revenue',
      label: 'Total Revenue',
      value: 2847500,
      previousValue: 2654200,
      change: 7.3,
      icon: 'DollarSign',
      bgColor: 'bg-primary'
    },
    {
      id: 'expenses',
      label: 'Total Expenses',
      value: 1456800,
      previousValue: 1523400,
      change: -4.4,
      icon: 'TrendingDown',
      bgColor: 'bg-error'
    },
    {
      id: 'net-income',
      label: 'Net Income',
      value: 1390700,
      previousValue: 1130800,
      change: 23.0,
      icon: 'TrendingUp',
      bgColor: 'bg-success'
    },
    {
      id: 'cash-flow',
      label: 'Operating Cash Flow',
      value: 1245600,
      previousValue: 1089200,
      change: 14.4,
      icon: 'Activity',
      bgColor: 'bg-accent'
    }
  ];

  // Mock data for revenue vs expenses chart
  const revenueExpenseData = [
    { month: 'Jan 2024', revenue: 235000, expenses: 118000 },
    { month: 'Feb 2024', revenue: 242000, expenses: 125000 },
    { month: 'Mar 2024', revenue: 238000, expenses: 121000 },
    { month: 'Apr 2024', revenue: 245000, expenses: 119000 },
    { month: 'May 2024', revenue: 251000, expenses: 127000 },
    { month: 'Jun 2024', revenue: 248000, expenses: 123000 },
    { month: 'Jul 2024', revenue: 253000, expenses: 129000 },
    { month: 'Aug 2024', revenue: 247000, expenses: 122000 },
    { month: 'Sep 2024', revenue: 249000, expenses: 126000 },
    { month: 'Oct 2024', revenue: 252000, expenses: 124000 },
    { month: 'Nov 2024', revenue: 255000, expenses: 128000 },
    { month: 'Dec 2024', revenue: 258000, expenses: 130000 }
  ];

  // Mock data for expense breakdown
  const expenseBreakdownData = [
    { name: 'Maintenance & Repairs', value: 425000, properties: 18 },
    { name: 'Property Management', value: 285000, properties: 24 },
    { name: 'Insurance', value: 195000, properties: 24 },
    { name: 'Property Taxes', value: 165000, properties: 24 },
    { name: 'Utilities', value: 145000, properties: 16 },
    { name: 'Marketing & Advertising', value: 85000, properties: 12 },
    { name: 'Legal & Professional', value: 75000, properties: 24 },
    { name: 'Other Expenses', value: 81800, properties: 15 }
  ];

  // Mock data for cash flow forecast
  const cashFlowForecastData = [
    { month: 'Jan 2025', optimistic: 145000, base: 125000, pessimistic: 105000 },
    { month: 'Feb 2025', optimistic: 148000, base: 128000, pessimistic: 108000 },
    { month: 'Mar 2025', optimistic: 152000, base: 132000, pessimistic: 112000 },
    { month: 'Apr 2025', optimistic: 155000, base: 135000, pessimistic: 115000 },
    { month: 'May 2025', optimistic: 158000, base: 138000, pessimistic: 118000 },
    { month: 'Jun 2025', optimistic: 162000, base: 142000, pessimistic: 122000 },
    { month: 'Jul 2025', optimistic: 165000, base: 145000, pessimistic: 125000 },
    { month: 'Aug 2025', optimistic: 168000, base: 148000, pessimistic: 128000 },
    { month: 'Sep 2025', optimistic: 172000, base: 152000, pessimistic: 132000 },
    { month: 'Oct 2025', optimistic: 175000, base: 155000, pessimistic: 135000 },
    { month: 'Nov 2025', optimistic: 178000, base: 158000, pessimistic: 138000 },
    { month: 'Dec 2025', optimistic: 182000, base: 162000, pessimistic: 142000 }
  ];

  // Mock scenarios data
  const scenariosData = [
    {
      name: 'Optimistic',
      value: 'optimistic',
      totalCashFlow: 1965000,
      icon: 'TrendingUp',
      description: 'High occupancy, rent increases',
      assumptions: {
        occupancyRate: 97,
        rentGrowth: 5.5,
        expenseGrowth: 2.0,
        vacancyRate: 3
      }
    },
    {
      name: 'Base Case',
      value: 'base',
      totalCashFlow: 1692000,
      icon: 'Activity',
      description: 'Current market conditions',
      assumptions: {
        occupancyRate: 94,
        rentGrowth: 3.5,
        expenseGrowth: 3.0,
        vacancyRate: 6
      }
    },
    {
      name: 'Pessimistic',
      value: 'pessimistic',
      totalCashFlow: 1458000,
      icon: 'TrendingDown',
      description: 'Economic downturn scenario',
      assumptions: {
        occupancyRate: 89,
        rentGrowth: 1.5,
        expenseGrowth: 4.5,
        vacancyRate: 11
      }
    }
  ];

  const handleRefresh = async () => {
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => {
      setLastUpdated(new Date());
      setIsLoading(false);
    }, 1500);
  };

  const handleDrillDown = (type, value) => {
    console.log(`Drilling down into ${type}: ${value}`);
    // In real implementation, this would filter data or navigate to detailed view
  };

  const handleCategoryFilter = (hiddenCategories) => {
    console.log('Filtering categories:', hiddenCategories);
    // In real implementation, this would update the chart data
  };

  useEffect(() => {
    // Simulate real-time data updates
    const interval = setInterval(() => {
      setLastUpdated(new Date());
    }, 30000); // Update every 30 seconds

    return () => clearInterval(interval);
  }, []);

  return (
    <FilterProvider>
      <StatusProvider>
        <ExportProvider>
          <div className="min-h-screen bg-background">
            <Helmet>
              <title>Financial Analytics Dashboard - FindMyHome</title>
              <meta name="description" content="Comprehensive financial analytics and cash flow forecasting for property portfolio optimization" />
            </Helmet>

            <Header />
            
            <main className="pt-16">
              <GlobalControls
                selectedProperties={selectedProperties}
                onPropertiesChange={setSelectedProperties}
                fiscalPeriod={fiscalPeriod}
                onFiscalPeriodChange={setFiscalPeriod}
                comparisonMode={comparisonMode}
                onComparisonModeChange={setComparisonMode}
                onRefresh={handleRefresh}
                lastUpdated={lastUpdated}
              />

              <GlobalFilterBar isCollapsed={true} />

              <div className="container mx-auto px-6 py-8">
                {/* Metrics Strip */}
                <MetricsStrip metrics={metricsData} />

                {/* Main Content Grid */}
                <div className="grid grid-cols-1 xl:grid-cols-16 gap-8 mb-8">
                  {/* Revenue vs Expenses Chart - 12 columns */}
                  <div className="xl:col-span-12">
                    <RevenueExpenseChart 
                      data={revenueExpenseData}
                      onDrillDown={handleDrillDown}
                    />
                  </div>

                  {/* Expense Breakdown Chart - 4 columns */}
                  <div className="xl:col-span-4">
                    <ExpenseBreakdownChart 
                      data={expenseBreakdownData}
                      onCategoryFilter={handleCategoryFilter}
                    />
                  </div>
                </div>

                {/* Cash Flow Forecast - Full Width */}
                <CashFlowForecast 
                  data={cashFlowForecastData}
                  scenarios={scenariosData}
                />
              </div>
            </main>

            <RealTimeStatusIndicator position="header" />
            <ExportControlPanel position="floating" />
          </div>
        </ExportProvider>
      </StatusProvider>
    </FilterProvider>
  );
};

export default FinancialAnalyticsDashboard;