import React from 'react';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const GlobalControls = ({ 
  selectedProperties, 
  onPropertiesChange, 
  fiscalPeriod, 
  onFiscalPeriodChange,
  comparisonMode,
  onComparisonModeChange,
  onRefresh,
  lastUpdated 
}) => {
  const propertyOptions = [
    { value: 'all', label: 'All Properties (24)' },
    { value: 'residential', label: 'Residential Only (18)' },
    { value: 'commercial', label: 'Commercial Only (6)' },
    { value: 'high-performance', label: 'High Performance (8)' },
    { value: 'underperforming', label: 'Underperforming (3)' }
  ];

  const fiscalPeriodOptions = [
    { value: 'current-month', label: 'Current Month' },
    { value: 'current-quarter', label: 'Current Quarter' },
    { value: 'current-year', label: 'Current Year (2024)' },
    { value: 'last-12-months', label: 'Last 12 Months' },
    { value: 'ytd', label: 'Year to Date' },
    { value: 'custom', label: 'Custom Range' }
  ];

  const comparisonModeOptions = [
    { value: 'yoy', label: 'Year over Year' },
    { value: 'mom', label: 'Month over Month' },
    { value: 'budget-actual', label: 'Budget vs Actual' },
    { value: 'previous-period', label: 'Previous Period' }
  ];

  const formatLastUpdated = () => {
    if (!lastUpdated) return 'Never';
    const now = new Date();
    const diff = now?.getTime() - lastUpdated?.getTime();
    
    if (diff < 60000) return 'Just now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    return lastUpdated?.toLocaleDateString();
  };

  return (
    <div className="bg-white border-b border-border p-6 shadow-elevation-1">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
        {/* Left Section - Filters */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
          <Select
            label="Properties"
            options={propertyOptions}
            value={selectedProperties}
            onChange={onPropertiesChange}
            className="w-full sm:w-56"
          />
          
          <Select
            label="Fiscal Period"
            options={fiscalPeriodOptions}
            value={fiscalPeriod}
            onChange={onFiscalPeriodChange}
            className="w-full sm:w-48"
          />
          
          <Select
            label="Comparison"
            options={comparisonModeOptions}
            value={comparisonMode}
            onChange={onComparisonModeChange}
            className="w-full sm:w-48"
          />
        </div>

        {/* Right Section - Actions & Status */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <Icon name="Clock" size={16} />
            <span>Last updated: {formatLastUpdated()}</span>
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="sm"
              iconName="RefreshCw"
              iconPosition="left"
              onClick={onRefresh}
            >
              Refresh
            </Button>
            
            <Button
              variant="outline"
              size="sm"
              iconName="Download"
              iconPosition="left"
            >
              Export
            </Button>
          </div>
        </div>
      </div>

      {/* Quick Stats Bar */}
      <div className="mt-6 pt-4 border-t border-border">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
          <div className="text-center">
            <p className="text-xs text-muted-foreground mb-1">Active Properties</p>
            <p className="text-lg font-bold text-foreground">24</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-muted-foreground mb-1">Total Units</p>
            <p className="text-lg font-bold text-foreground">156</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-muted-foreground mb-1">Occupancy Rate</p>
            <p className="text-lg font-bold text-success">94.2%</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-muted-foreground mb-1">Avg. Rent/Unit</p>
            <p className="text-lg font-bold text-foreground">₦2,450</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-muted-foreground mb-1">Portfolio Value</p>
            <p className="text-lg font-bold text-foreground">₦12.8M</p>
          </div>
          <div className="text-center">
            <p className="text-xs text-muted-foreground mb-1">Net Yield</p>
            <p className="text-lg font-bold text-primary">8.7%</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GlobalControls;
