import React, { useState } from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ExpenseBreakdownChart = ({ data, onCategoryFilter }) => {
  const [activeIndex, setActiveIndex] = useState(null);
  const [hiddenCategories, setHiddenCategories] = useState(new Set());

  const colors = [
    'var(--color-primary)',
    'var(--color-accent)',
    'var(--color-warning)',
    'var(--color-error)',
    'var(--color-secondary)',
    '#8B5CF6',
    '#F59E0B',
    '#10B981'
  ];

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    })?.format(value);
  };

  const formatPercentage = (value, total) => {
    return ((value / total) * 100)?.toFixed(1) + '%';
  };

  const totalExpenses = data?.reduce((sum, item) => sum + item?.value, 0);
  const visibleData = data?.filter(item => !hiddenCategories?.has(item?.name));

  const CustomTooltip = ({ active, payload }) => {
    if (active && payload && payload?.length) {
      const data = payload?.[0]?.payload;
      return (
        <div className="bg-white border border-border rounded-lg p-4 shadow-elevation-2">
          <p className="font-medium text-foreground mb-2">{data?.name}</p>
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">
              Amount: <span className="font-medium text-foreground">{formatCurrency(data?.value)}</span>
            </p>
            <p className="text-sm text-muted-foreground">
              Percentage: <span className="font-medium text-foreground">{formatPercentage(data?.value, totalExpenses)}</span>
            </p>
            <p className="text-sm text-muted-foreground">
              Properties: <span className="font-medium text-foreground">{data?.properties}</span>
            </p>
          </div>
        </div>
      );
    }
    return null;
  };

  const handleLegendClick = (category) => {
    const newHiddenCategories = new Set(hiddenCategories);
    if (hiddenCategories?.has(category)) {
      newHiddenCategories?.delete(category);
    } else {
      newHiddenCategories?.add(category);
    }
    setHiddenCategories(newHiddenCategories);
    
    if (onCategoryFilter) {
      onCategoryFilter(Array.from(newHiddenCategories));
    }
  };

  const onPieEnter = (_, index) => {
    setActiveIndex(index);
  };

  const onPieLeave = () => {
    setActiveIndex(null);
  };

  return (
    <div className="bg-white rounded-lg border border-border p-6 shadow-elevation-1">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <Icon name="PieChart" size={24} color="var(--color-primary)" />
          <h3 className="text-lg font-semibold text-foreground">Expense Breakdown</h3>
        </div>
        
        <Button
          variant="outline"
          size="sm"
          iconName="RotateCcw"
          onClick={() => setHiddenCategories(new Set())}
        >
          Reset
        </Button>
      </div>
      <div className="h-80 w-full mb-6">
        <ResponsiveContainer width="100%" height="100%">
          <PieChart>
            <Pie
              data={visibleData}
              cx="50%"
              cy="50%"
              outerRadius={100}
              innerRadius={40}
              paddingAngle={2}
              dataKey="value"
              onMouseEnter={onPieEnter}
              onMouseLeave={onPieLeave}
            >
              {visibleData?.map((entry, index) => (
                <Cell 
                  key={`cell-${index}`} 
                  fill={colors?.[index % colors?.length]}
                  stroke={activeIndex === index ? '#000' : 'none'}
                  strokeWidth={activeIndex === index ? 2 : 0}
                />
              ))}
            </Pie>
            <Tooltip content={<CustomTooltip />} />
          </PieChart>
        </ResponsiveContainer>
      </div>
      <div className="space-y-3">
        <h4 className="text-sm font-medium text-foreground mb-3">Categories (Click to toggle)</h4>
        <div className="grid grid-cols-1 gap-2">
          {data?.map((item, index) => (
            <button
              key={item?.name}
              onClick={() => handleLegendClick(item?.name)}
              className={`flex items-center justify-between p-3 rounded-lg border transition-smooth ${
                hiddenCategories?.has(item?.name)
                  ? 'border-border bg-muted/50 opacity-50' :'border-border bg-white hover:bg-muted/30'
              }`}
            >
              <div className="flex items-center space-x-3">
                <div 
                  className="w-4 h-4 rounded-full"
                  style={{ backgroundColor: colors?.[index % colors?.length] }}
                />
                <span className="text-sm font-medium text-foreground">{item?.name}</span>
              </div>
              <div className="text-right">
                <p className="text-sm font-medium text-foreground">{formatCurrency(item?.value)}</p>
                <p className="text-xs text-muted-foreground">{formatPercentage(item?.value, totalExpenses)}</p>
              </div>
            </button>
          ))}
        </div>
      </div>
      <div className="mt-6 pt-4 border-t border-border">
        <div className="flex items-center justify-between">
          <span className="text-sm font-medium text-foreground">Total Expenses</span>
          <span className="text-lg font-bold text-foreground">{formatCurrency(totalExpenses)}</span>
        </div>
      </div>
    </div>
  );
};

export default ExpenseBreakdownChart;