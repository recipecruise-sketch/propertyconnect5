import React, { useState } from 'react';
import { ComposedChart, Bar, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const RevenueExpenseChart = ({ data, onDrillDown }) => {
  const [selectedProperty, setSelectedProperty] = useState('all');
  const [selectedCategory, setSelectedCategory] = useState('all');

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    })?.format(value);
  };

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload?.length) {
      return (
        <div className="bg-white border border-border rounded-lg p-4 shadow-elevation-2">
          <p className="font-medium text-foreground mb-2">{label}</p>
          {payload?.map((entry, index) => (
            <div key={index} className="flex items-center space-x-2 mb-1">
              <div 
                className="w-3 h-3 rounded-full" 
                style={{ backgroundColor: entry?.color }}
              />
              <span className="text-sm text-muted-foreground">{entry?.dataKey}:</span>
              <span className="text-sm font-medium text-foreground">
                {formatCurrency(entry?.value)}
              </span>
            </div>
          ))}
        </div>
      );
    }
    return null;
  };

  const handleBarClick = (data, index) => {
    if (onDrillDown) {
      onDrillDown('property', data?.month);
    }
  };

  return (
    <div className="bg-white rounded-lg border border-border p-6 shadow-elevation-1">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center space-x-3">
          <Icon name="BarChart3" size={24} color="var(--color-primary)" />
          <h3 className="text-lg font-semibold text-foreground">Revenue vs Expenses</h3>
        </div>
        
        <div className="flex items-center space-x-2">
          <Button
            variant={selectedProperty === 'all' ? 'primary' : 'outline'}
            size="sm"
            onClick={() => setSelectedProperty('all')}
          >
            All Properties
          </Button>
          <Button
            variant={selectedProperty === 'residential' ? 'primary' : 'outline'}
            size="sm"
            onClick={() => setSelectedProperty('residential')}
          >
            Residential
          </Button>
          <Button
            variant={selectedProperty === 'commercial' ? 'primary' : 'outline'}
            size="sm"
            onClick={() => setSelectedProperty('commercial')}
          >
            Commercial
          </Button>
        </div>
      </div>

      <div className="h-80 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <ComposedChart
            data={data}
            margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
          >
            <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
            <XAxis 
              dataKey="month" 
              stroke="var(--color-muted-foreground)"
              fontSize={12}
            />
            <YAxis 
              stroke="var(--color-muted-foreground)"
              fontSize={12}
              tickFormatter={formatCurrency}
            />
            <Tooltip content={<CustomTooltip />} />
            <Legend />
            <Bar 
              dataKey="revenue" 
              fill="var(--color-primary)" 
              name="Revenue"
              onClick={handleBarClick}
              cursor="pointer"
              radius={[4, 4, 0, 0]}
            />
            <Line 
              type="monotone" 
              dataKey="expenses" 
              stroke="var(--color-error)" 
              strokeWidth={3}
              name="Expenses"
              dot={{ fill: 'var(--color-error)', strokeWidth: 2, r: 4 }}
            />
          </ComposedChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-4 flex items-center justify-between text-sm text-muted-foreground">
        <span>Click on bars to drill down by property</span>
        <span>Drag to zoom • Double-click to reset</span>
      </div>
    </div>
  );
};

export default RevenueExpenseChart;