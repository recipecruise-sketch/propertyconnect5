import React from 'react';
import Icon from '../../../components/AppIcon';

const MetricsStrip = ({ metrics }) => {
  const getChangeColor = (change) => {
    if (change > 0) return 'text-success';
    if (change < 0) return 'text-error';
    return 'text-muted-foreground';
  };

  const getChangeIcon = (change) => {
    if (change > 0) return 'TrendingUp';
    if (change < 0) return 'TrendingDown';
    return 'Minus';
  };

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    })?.format(value);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {metrics?.map((metric) => (
        <div key={metric?.id} className="bg-white rounded-lg border border-border p-6 shadow-elevation-1 hover:shadow-elevation-2 transition-smooth">
          <div className="flex items-center justify-between mb-4">
            <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${metric?.bgColor}`}>
              <Icon name={metric?.icon} size={24} color="white" />
            </div>
            <div className={`flex items-center space-x-1 ${getChangeColor(metric?.change)}`}>
              <Icon name={getChangeIcon(metric?.change)} size={16} />
              <span className="text-sm font-medium">
                {Math.abs(metric?.change)}%
              </span>
            </div>
          </div>
          
          <div className="space-y-2">
            <h3 className="text-sm font-medium text-muted-foreground">{metric?.label}</h3>
            <p className="text-2xl font-bold text-foreground">
              {formatCurrency(metric?.value)}
            </p>
            <p className="text-xs text-muted-foreground">
              vs last period: {formatCurrency(metric?.previousValue)}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default MetricsStrip;