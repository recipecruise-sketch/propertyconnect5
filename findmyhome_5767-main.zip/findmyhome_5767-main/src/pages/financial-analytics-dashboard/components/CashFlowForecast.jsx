import React, { useState } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const CashFlowForecast = ({ data, scenarios }) => {
  const [selectedScenario, setSelectedScenario] = useState('base');
  const [showConfidenceInterval, setShowConfidenceInterval] = useState(true);
  const [timeRange, setTimeRange] = useState('12months');

  const scenarioOptions = [
    { value: 'optimistic', label: 'Optimistic Scenario' },
    { value: 'base', label: 'Base Case Scenario' },
    { value: 'pessimistic', label: 'Pessimistic Scenario' }
  ];

  const timeRangeOptions = [
    { value: '6months', label: 'Next 6 Months' },
    { value: '12months', label: 'Next 12 Months' },
    { value: '24months', label: 'Next 24 Months' }
  ];

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    })?.format(value);
  };

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload?.length) {
      return (
        <div className="bg-white border border-border rounded-lg p-4 shadow-elevation-2">
          <p className="font-medium text-foreground mb-3">{label}</p>
          {payload?.map((entry, index) => (
            <div key={index} className="flex items-center justify-between space-x-4 mb-2">
              <div className="flex items-center space-x-2">
                <div 
                  className="w-3 h-3 rounded-full" 
                  style={{ backgroundColor: entry?.color }}
                />
                <span className="text-sm text-muted-foreground">{entry?.name}:</span>
              </div>
              <span className="text-sm font-medium text-foreground">
                {formatCurrency(entry?.value)}
              </span>
            </div>
          ))}
          {showConfidenceInterval && (
            <div className="mt-3 pt-2 border-t border-border">
              <p className="text-xs text-muted-foreground">
                Confidence Level: 85%
              </p>
            </div>
          )}
        </div>
      );
    }
    return null;
  };

  const getScenarioData = () => {
    return data?.map(item => ({
      ...item,
      cashFlow: item?.[selectedScenario],
      upperBound: item?.[selectedScenario] * 1.15,
      lowerBound: item?.[selectedScenario] * 0.85
    }));
  };

  const scenarioData = getScenarioData();
  const currentMonth = new Date()?.toLocaleString('default', { month: 'short', year: 'numeric' });

  return (
    <div className="bg-white rounded-lg border border-border p-6 shadow-elevation-1">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-6 space-y-4 lg:space-y-0">
        <div className="flex items-center space-x-3">
          <Icon name="TrendingUp" size={24} color="var(--color-primary)" />
          <h3 className="text-lg font-semibold text-foreground">Cash Flow Forecast</h3>
        </div>
        
        <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-3 sm:space-y-0 sm:space-x-4">
          <Select
            options={scenarioOptions}
            value={selectedScenario}
            onChange={setSelectedScenario}
            className="w-full sm:w-48"
          />
          
          <Select
            options={timeRangeOptions}
            value={timeRange}
            onChange={setTimeRange}
            className="w-full sm:w-40"
          />
          
          <Button
            variant={showConfidenceInterval ? 'primary' : 'outline'}
            size="sm"
            onClick={() => setShowConfidenceInterval(!showConfidenceInterval)}
          >
            Confidence Bands
          </Button>
        </div>
      </div>
      <div className="h-96 w-full mb-6">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart
            data={scenarioData}
            margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
          >
            <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
            <XAxis 
              dataKey="month" 
              stroke="var(--color-muted-foreground)"
              fontSize={12}
            />
            <YAxis 
              stroke="var(--color-muted-foreground)"
              fontSize={12}
              tickFormatter={formatCurrency}
            />
            <Tooltip content={<CustomTooltip />} />
            
            {/* Confidence Interval */}
            {showConfidenceInterval && (
              <>
                <Area
                  type="monotone"
                  dataKey="upperBound"
                  stackId="1"
                  stroke="none"
                  fill="var(--color-primary)"
                  fillOpacity={0.1}
                  name="Upper Bound"
                />
                <Area
                  type="monotone"
                  dataKey="lowerBound"
                  stackId="1"
                  stroke="none"
                  fill="white"
                  fillOpacity={1}
                  name="Lower Bound"
                />
              </>
            )}
            
            {/* Main Cash Flow Line */}
            <Area
              type="monotone"
              dataKey="cashFlow"
              stroke="var(--color-primary)"
              strokeWidth={3}
              fill="var(--color-primary)"
              fillOpacity={0.3}
              name="Projected Cash Flow"
            />
            
            {/* Current Month Reference Line */}
            <ReferenceLine 
              x={currentMonth} 
              stroke="var(--color-error)" 
              strokeDasharray="5 5"
              label={{ value: "Current", position: "top" }}
            />
            
            {/* Zero Line */}
            <ReferenceLine 
              y={0} 
              stroke="var(--color-muted-foreground)" 
              strokeDasharray="3 3"
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>
      {/* Scenario Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        {scenarios?.map((scenario) => (
          <div 
            key={scenario?.name}
            className={`p-4 rounded-lg border transition-smooth cursor-pointer ${
              selectedScenario === scenario?.value
                ? 'border-primary bg-primary/5' :'border-border hover:border-primary/50'
            }`}
            onClick={() => setSelectedScenario(scenario?.value)}
          >
            <div className="flex items-center justify-between mb-2">
              <h4 className="text-sm font-medium text-foreground">{scenario?.name}</h4>
              <Icon 
                name={scenario?.icon} 
                size={16} 
                color={selectedScenario === scenario?.value ? 'var(--color-primary)' : 'var(--color-muted-foreground)'}
              />
            </div>
            <p className="text-lg font-bold text-foreground mb-1">
              {formatCurrency(scenario?.totalCashFlow)}
            </p>
            <p className="text-xs text-muted-foreground">{scenario?.description}</p>
          </div>
        ))}
      </div>
      {/* Key Assumptions */}
      <div className="bg-muted/30 rounded-lg p-4">
        <h4 className="text-sm font-medium text-foreground mb-3 flex items-center">
          <Icon name="Info" size={16} className="mr-2" />
          Key Assumptions ({selectedScenario} scenario)
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
          <div>
            <span className="text-muted-foreground">Occupancy Rate:</span>
            <span className="ml-2 font-medium text-foreground">
              {scenarios?.find(s => s?.value === selectedScenario)?.assumptions?.occupancyRate}%
            </span>
          </div>
          <div>
            <span className="text-muted-foreground">Rent Growth:</span>
            <span className="ml-2 font-medium text-foreground">
              {scenarios?.find(s => s?.value === selectedScenario)?.assumptions?.rentGrowth}%
            </span>
          </div>
          <div>
            <span className="text-muted-foreground">Expense Growth:</span>
            <span className="ml-2 font-medium text-foreground">
              {scenarios?.find(s => s?.value === selectedScenario)?.assumptions?.expenseGrowth}%
            </span>
          </div>
          <div>
            <span className="text-muted-foreground">Vacancy Rate:</span>
            <span className="ml-2 font-medium text-foreground">
              {scenarios?.find(s => s?.value === selectedScenario)?.assumptions?.vacancyRate}%
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CashFlowForecast;