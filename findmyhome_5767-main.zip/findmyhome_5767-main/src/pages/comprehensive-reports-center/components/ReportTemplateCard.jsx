import React from 'react';
        import { Eye, Edit, Clock, Download, Share2, Calendar } from 'lucide-react';

        const ReportTemplateCard = ({ template, onView, onEdit, onSchedule, onExport, onShare }) => {
          const getStatusColor = (status) => {
            switch (status) {
              case 'ready':
                return 'bg-green-100 text-green-800';
              case 'processing':
                return 'bg-yellow-100 text-yellow-800';
              case 'error':
                return 'bg-red-100 text-red-800';
              default:
                return 'bg-gray-100 text-gray-800';
            }
          };

          const getStatusText = (status) => {
            switch (status) {
              case 'ready':
                return 'Ready';
              case 'processing':
                return 'Processing';
              case 'error':
                return 'Error';
              default:
                return 'Unknown';
            }
          };

          return (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow">
              {/* Thumbnail */}
              <div className="relative">
                <img
                  src={template?.thumbnail || '/assets/images/no_image.png'}
                  alt={template?.name}
                  className="w-full h-32 object-cover"
                />
                <div className="absolute top-2 right-2 flex space-x-1">
                  <span className={`px-2 py-1 rounded text-xs font-medium ${getStatusColor(template?.status)}`}>
                    {getStatusText(template?.status)}
                  </span>
                  {template?.scheduled && (
                    <div className="bg-blue-500 p-1 rounded">
                      <Clock className="w-3 h-3 text-white" />
                    </div>
                  )}
                </div>
              </div>

              {/* Content */}
              <div className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-semibold text-gray-900 text-sm">{template?.name}</h3>
                </div>
                
                <p className="text-gray-600 text-xs mb-3 line-clamp-2">{template?.description}</p>
                
                <div className="flex items-center justify-between text-xs text-gray-500 mb-4">
                  <span>{template?.frequency}</span>
                  <span>Updated {template?.lastUpdated}</span>
                </div>

                {/* Action Buttons */}
                <div className="flex items-center justify-between">
                  <div className="flex space-x-1">
                    <button
                      onClick={onView}
                      className="p-2 bg-blue-50 hover:bg-blue-100 rounded-md transition-colors"
                      title="View Report"
                    >
                      <Eye className="w-4 h-4 text-blue-600" />
                    </button>
                    <button
                      onClick={onEdit}
                      className="p-2 bg-gray-50 hover:bg-gray-100 rounded-md transition-colors"
                      title="Edit Report"
                    >
                      <Edit className="w-4 h-4 text-gray-600" />
                    </button>
                    <button
                      onClick={onSchedule}
                      className="p-2 bg-green-50 hover:bg-green-100 rounded-md transition-colors"
                      title="Schedule Report"
                    >
                      <Calendar className="w-4 h-4 text-green-600" />
                    </button>
                  </div>
                  
                  <div className="flex space-x-1">
                    <button
                      onClick={onExport}
                      className="p-2 bg-purple-50 hover:bg-purple-100 rounded-md transition-colors"
                      title="Export Report"
                    >
                      <Download className="w-4 h-4 text-purple-600" />
                    </button>
                    <button
                      onClick={onShare}
                      className="p-2 bg-orange-50 hover:bg-orange-100 rounded-md transition-colors"
                      title="Share Report"
                    >
                      <Share2 className="w-4 h-4 text-orange-600" />
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        };

        export default ReportTemplateCard;