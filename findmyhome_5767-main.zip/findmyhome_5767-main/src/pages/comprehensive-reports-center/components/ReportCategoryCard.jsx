import React from 'react';
import Icon from '../../../components/AppIcon';


        const ReportCategoryCard = ({ category, isSelected, onClick }) => {
          const Icon = category?.icon;

          return (
            <div
              onClick={onClick}
              className={`p-4 rounded-lg border cursor-pointer transition-all duration-200 ${
                isSelected
                  ? 'border-blue-500 bg-blue-50 shadow-md'
                  : 'border-gray-200 bg-white hover:shadow-md hover:border-gray-300'
              }`}
            >
              <div className="flex items-start space-x-3">
                <div className={`p-2 rounded-lg ${category?.color}`}>
                  <Icon className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900 text-sm">{category?.name}</h3>
                  <p className="text-gray-600 text-xs mt-1">{category?.description}</p>
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-sm text-gray-500">{category?.count} reports</span>
                    {isSelected && (
                      <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          );
        };

        export default ReportCategoryCard;