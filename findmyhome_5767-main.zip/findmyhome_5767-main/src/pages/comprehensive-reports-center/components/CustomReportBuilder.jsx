import React, { useState } from 'react';
        import { Plus, BarChart, PieChart, LineChart, Table } from 'lucide-react';
import Icon from '../../../components/AppIcon';


        const CustomReportBuilder = () => {
          const [reportName, setReportName] = useState('');
          const [selectedDataSources, setSelectedDataSources] = useState([]);
          const [selectedVisualization, setSelectedVisualization] = useState('table');
          const [selectedDateRange, setSelectedDateRange] = useState('last_30_days');
          const [selectedProperties, setSelectedProperties] = useState([]);

          const dataSources = [
            { id: 'financial', name: 'Financial Data', description: 'Revenue, expenses, profit/loss' },
            { id: 'occupancy', name: 'Occupancy Data', description: 'Tenant data, vacancy rates' },
            { id: 'maintenance', name: 'Maintenance Records', description: 'Work orders, costs, schedules' },
            { id: 'market', name: 'Market Data', description: 'Rental rates, competition analysis' }
          ];

          const visualizationTypes = [
            { id: 'table', name: 'Data Table', icon: Table, description: 'Structured data in rows and columns' },
            { id: 'bar', name: 'Bar Chart', icon: BarChart, description: 'Compare values across categories' },
            { id: 'pie', name: 'Pie Chart', icon: PieChart, description: 'Show proportions of a whole' },
            { id: 'line', name: 'Line Chart', icon: LineChart, description: 'Display trends over time' }
          ];

          const dateRanges = [
            { id: 'last_7_days', name: 'Last 7 Days' },
            { id: 'last_30_days', name: 'Last 30 Days' },
            { id: 'last_90_days', name: 'Last 90 Days' },
            { id: 'last_year', name: 'Last Year' },
            { id: 'custom', name: 'Custom Range' }
          ];

          const properties = [
            { id: 1, name: 'Sunset Apartments' },
            { id: 2, name: 'Garden View Complex' },
            { id: 3, name: 'Riverside Condos' }
          ];

          const handleDataSourceToggle = (sourceId) => {
            setSelectedDataSources(prev => 
              prev?.includes(sourceId)
                ? prev?.filter(id => id !== sourceId)
                : [...prev, sourceId]
            );
          };

          const handlePropertyToggle = (propertyId) => {
            setSelectedProperties(prev => 
              prev?.includes(propertyId)
                ? prev?.filter(id => id !== propertyId)
                : [...prev, propertyId]
            );
          };

          const handleGenerateReport = () => {
            if (!reportName?.trim()) {
              alert('Please enter a report name');
              return;
            }
            if (selectedDataSources?.length === 0) {
              alert('Please select at least one data source');
              return;
            }
            
            console.log('Generating custom report:', {
              name: reportName,
              dataSources: selectedDataSources,
              visualization: selectedVisualization,
              dateRange: selectedDateRange,
              properties: selectedProperties
            });
            
            alert('Report generation started! You will be notified when it\'s ready.');
          };

          return (
            <div className="space-y-8">
              {/* Report Name */}
              <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Report Configuration</h3>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Report Name
                  </label>
                  <input
                    type="text"
                    value={reportName}
                    onChange={(e) => setReportName(e?.target?.value)}
                    placeholder="Enter report name..."
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
              {/* Data Sources */}
              <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Select Data Sources</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {dataSources?.map((source) => (
                    <div
                      key={source?.id}
                      onClick={() => handleDataSourceToggle(source?.id)}
                      className={`p-4 border rounded-lg cursor-pointer transition-all ${
                        selectedDataSources?.includes(source?.id)
                          ? 'border-blue-500 bg-blue-50' :'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium text-gray-900">{source?.name}</h4>
                          <p className="text-sm text-gray-600">{source?.description}</p>
                        </div>
                        {selectedDataSources?.includes(source?.id) && (
                          <div className="w-5 h-5 bg-blue-500 rounded-full flex items-center justify-center">
                            <div className="w-2 h-2 bg-white rounded-full"></div>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              {/* Visualization Type */}
              <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Visualization Type</h3>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {visualizationTypes?.map((type) => {
                    const Icon = type?.icon;
                    return (
                      <div
                        key={type?.id}
                        onClick={() => setSelectedVisualization(type?.id)}
                        className={`p-4 border rounded-lg cursor-pointer text-center transition-all ${
                          selectedVisualization === type?.id
                            ? 'border-blue-500 bg-blue-50' :'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <Icon className="w-8 h-8 mx-auto mb-2 text-gray-600" />
                        <h4 className="font-medium text-gray-900 text-sm">{type?.name}</h4>
                        <p className="text-xs text-gray-600 mt-1">{type?.description}</p>
                      </div>
                    );
                  })}
                </div>
              </div>
              {/* Date Range */}
              <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Date Range</h3>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
                  {dateRanges?.map((range) => (
                    <button
                      key={range?.id}
                      onClick={() => setSelectedDateRange(range?.id)}
                      className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                        selectedDateRange === range?.id
                          ? 'bg-blue-500 text-white' :'bg-gray-100 text-gray-700 hover:bg-gray-200'
                      }`}
                    >
                      {range?.name}
                    </button>
                  ))}
                </div>
              </div>
              {/* Property Selection */}
              <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 mb-4">Select Properties</h3>
                <div className="space-y-3">
                  <button
                    onClick={() => {
                      if (selectedProperties?.length === properties?.length) {
                        setSelectedProperties([]);
                      } else {
                        setSelectedProperties(properties?.map(p => p?.id));
                      }
                    }}
                    className="text-blue-500 hover:text-blue-600 text-sm font-medium"
                  >
                    {selectedProperties?.length === properties?.length ? 'Deselect All' : 'Select All'}
                  </button>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    {properties?.map((property) => (
                      <div
                        key={property?.id}
                        onClick={() => handlePropertyToggle(property?.id)}
                        className={`p-3 border rounded-lg cursor-pointer transition-all ${
                          selectedProperties?.includes(property?.id)
                            ? 'border-blue-500 bg-blue-50' :'border-gray-200 hover:border-gray-300'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-medium text-gray-900 text-sm">{property?.name}</span>
                          {selectedProperties?.includes(property?.id) && (
                            <div className="w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center">
                              <div className="w-1.5 h-1.5 bg-white rounded-full"></div>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
              {/* Generate Button */}
              <div className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900">Generate Report</h3>
                    <p className="text-sm text-gray-600 mt-1">
                      Your custom report will be generated based on the selected configuration
                    </p>
                  </div>
                  <button
                    onClick={handleGenerateReport}
                    className="px-6 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded-lg font-medium transition-colors flex items-center space-x-2"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Generate Report</span>
                  </button>
                </div>
              </div>
            </div>
          );
        };

        export default CustomReportBuilder;