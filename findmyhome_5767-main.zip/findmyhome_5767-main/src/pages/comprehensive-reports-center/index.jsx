import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import { Filter, Calendar, TrendingUp, Users, Home, DollarSign } from 'lucide-react';
import Header from '../../components/ui/Header';
import GlobalFilterBar, { FilterProvider } from '../../components/ui/GlobalFilterBar';
import ExportControlPanel, { ExportProvider } from '../../components/ui/ExportControlPanel';
import ReportCategoryCard from './components/ReportCategoryCard';
import ReportTemplateCard from './components/ReportTemplateCard';
import CustomReportBuilder from './components/CustomReportBuilder';

const ComprehensiveReportsCenter = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('templates');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [showCustomBuilder, setShowCustomBuilder] = useState(false);

  const reportCategories = [
    {
      id: 'financial',
      name: 'Financial Reports',
      icon: DollarSign,
      count: 12,
      color: 'bg-green-500',
      description: 'Revenue, expenses, and profitability analysis'
    },
    {
      id: 'occupancy',
      name: 'Occupancy Reports',
      icon: Users,
      count: 8,
      color: 'bg-blue-500',
      description: 'Tenant occupancy and vacancy tracking'
    },
    {
      id: 'maintenance',
      name: 'Maintenance Analytics',
      icon: Home,
      count: 6,
      color: 'bg-orange-500',
      description: 'Work orders, costs, and performance metrics'
    },
    {
      id: 'market',
      name: 'Market Analysis',
      icon: TrendingUp,
      count: 4,
      color: 'bg-purple-500',
      description: 'Competitive analysis and market trends'
    }
  ];

  const reportTemplates = [
    {
      id: 1,
      name: 'Monthly Financial Summary',
      category: 'financial',
      frequency: 'Monthly',
      lastUpdated: '2025-09-03',
      thumbnail: 'https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=200&h=120&fit=crop',
      description: 'Comprehensive monthly revenue and expense breakdown',
      status: 'ready',
      scheduled: true
    },
    {
      id: 2,
      name: 'Occupancy Performance Report',
      category: 'occupancy',
      frequency: 'Weekly',
      lastUpdated: '2025-09-04',
      thumbnail: 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=200&h=120&fit=crop',
      description: 'Track vacancy rates and tenant turnover',
      status: 'ready',
      scheduled: false
    },
    {
      id: 3,
      name: 'Maintenance Cost Analysis',
      category: 'maintenance',
      frequency: 'Quarterly',
      lastUpdated: '2025-09-01',
      thumbnail: 'https://images.unsplash.com/photo-1581578731548-c64695cc6952?w=200&h=120&fit=crop',
      description: 'Analyze maintenance spending patterns',
      status: 'processing',
      scheduled: true
    },
    {
      id: 4,
      name: 'Market Comparison Report',
      category: 'market',
      frequency: 'Monthly',
      lastUpdated: '2025-08-30',
      thumbnail: 'https://images.unsplash.com/photo-1611224923853-80b023f02d71?w=200&h=120&fit=crop',
      description: 'Compare your properties against market rates',
      status: 'ready',
      scheduled: false
    },
    {
      id: 5,
      name: 'Tenant Demographics Report',
      category: 'occupancy',
      frequency: 'Quarterly',
      lastUpdated: '2025-09-02',
      thumbnail: 'https://images.unsplash.com/photo-1600880292203-757bb62b4baf?w=200&h=120&fit=crop',
      description: 'Analyze tenant profiles and satisfaction',
      status: 'ready',
      scheduled: true
    },
    {
      id: 6,
      name: 'Cash Flow Forecast',
      category: 'financial',
      frequency: 'Monthly',
      lastUpdated: '2025-09-05',
      thumbnail: 'https://images.unsplash.com/photo-1590736969955-71cc94901144?w=200&h=120&fit=crop',
      description: 'Project future cash flow trends',
      status: 'ready',
      scheduled: false
    }
  ];

  const filteredTemplates = selectedCategory === 'all' 
    ? reportTemplates 
    : reportTemplates?.filter(template => template?.category === selectedCategory);

  const handleBackClick = () => {
    navigate('/');
  };

  const handleViewReport = (reportId) => {
    console.log('Viewing report:', reportId);
    // Navigate to report viewer
  };

  const handleEditReport = (reportId) => {
    console.log('Editing report:', reportId);
    // Navigate to report editor
  };

  const handleScheduleReport = (reportId) => {
    console.log('Scheduling report:', reportId);
    // Open scheduling modal
  };

  const handleExportReport = (reportId) => {
    console.log('Exporting report:', reportId);
    // Trigger export functionality
  };

  const handleShareReport = (reportId) => {
    console.log('Sharing report:', reportId);
    // Open share modal
  };

  return (
    <FilterProvider>
      <ExportProvider>
        <div className="min-h-screen bg-gradient-to-br from-slate-50 to-white">
          <Helmet>
            <title>Comprehensive Reports Center - Property Management</title>
            <meta name="description" content="Generate, customize, and manage all property-related reports" />
          </Helmet>
          {/* Header */}
          <Header 
            title="Reports Center"
            onBackClick={handleBackClick}
            showProfile={true}
            onProfileClick={() => navigate('/property-details-management')}
          />
          {/* Global Filter Bar */}
          <GlobalFilterBar />
          {/* Main Content */}
          <main className="max-w-7xl mx-auto px-6 py-6">
            {/* Tab Navigation */}
            <div className="flex items-center justify-between mb-8">
              <div className="flex space-x-1 bg-white rounded-lg p-1 shadow-sm">
                <button
                  onClick={() => setActiveTab('templates')}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                    activeTab === 'templates' ?'bg-blue-500 text-white shadow-md' :'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  Templates
                </button>
                <button
                  onClick={() => setActiveTab('builder')}
                  className={`px-4 py-2 rounded-md text-sm font-medium transition-all ${
                    activeTab === 'builder' ?'bg-blue-500 text-white shadow-md' :'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  Custom Builder
                </button>
              </div>

              <ExportControlPanel />
            </div>

            {activeTab === 'templates' ? (
              <div>
                {/* Category Filter */}
                <div className="mb-8">
                  <h2 className="text-lg font-semibold text-gray-900 mb-4">Report Categories</h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                    {reportCategories?.map((category) => (
                      <ReportCategoryCard
                        key={category?.id}
                        category={category}
                        isSelected={selectedCategory === category?.id}
                        onClick={() => setSelectedCategory(category?.id)}
                      />
                    ))}
                  </div>
                  
                  <button
                    onClick={() => setSelectedCategory('all')}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                      selectedCategory === 'all' ?'bg-gray-900 text-white' :'bg-gray-100 text-gray-600 hover:bg-gray-200'
                    }`}
                  >
                    Show All Categories
                  </button>
                </div>

                {/* Report Templates */}
                <div>
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-lg font-semibold text-gray-900">
                      Available Reports ({filteredTemplates?.length})
                    </h2>
                    <div className="flex items-center space-x-2">
                      <button className="flex items-center space-x-2 px-3 py-2 bg-white rounded-lg border border-gray-200 text-sm hover:bg-gray-50">
                        <Filter className="w-4 h-4" />
                        <span>Filter</span>
                      </button>
                      <button className="flex items-center space-x-2 px-3 py-2 bg-white rounded-lg border border-gray-200 text-sm hover:bg-gray-50">
                        <Calendar className="w-4 h-4" />
                        <span>Schedule</span>
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredTemplates?.map((template) => (
                      <ReportTemplateCard
                        key={template?.id}
                        template={template}
                        onView={() => handleViewReport(template?.id)}
                        onEdit={() => handleEditReport(template?.id)}
                        onSchedule={() => handleScheduleReport(template?.id)}
                        onExport={() => handleExportReport(template?.id)}
                        onShare={() => handleShareReport(template?.id)}
                      />
                    ))}
                  </div>
                </div>
              </div>
            ) : (
              <CustomReportBuilder />
            )}
          </main>
        </div>
      </ExportProvider>
    </FilterProvider>
  );
};

export default ComprehensiveReportsCenter;