import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Bell, CheckCircle2, Clock } from 'lucide-react';

const NotificationsPage = () => {
  const navigate = useNavigate();
  const [items, setItems] = useState([
    { id: 1, title: 'New maintenance request', detail: 'Unit 204 reported a leak.', time: '5m ago', read: false },
    { id: 2, title: 'Payment received', detail: 'Michael Chen paid ₦1,650.', time: '1h ago', read: false },
    { id: 3, title: 'Lease expiring', detail: '3 leases expiring in 30 days.', time: 'Yesterday', read: true },
  ]);

  const markAllRead = () => setItems(prev => prev.map(i => ({ ...i, read: true })));

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      <Helmet>
        <title>Notifications - Findmyhome</title>
        <meta name="description" content="View notifications" />
      </Helmet>

      <div className="bg-white/80 backdrop-blur-sm border-b border-white/20 shadow-sm sticky top-0 z-40">
        <div className="max-w-3xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-lg transition-colors" aria-label="Back">
              <ArrowLeft className="w-5 h-5 text-gray-600" />
            </button>
            <h1 className="text-xl font-bold text-gray-900">Notifications</h1>
          </div>
          <button onClick={markAllRead} className="text-sm text-blue-600 hover:text-blue-700">Mark all as read</button>
        </div>
      </div>

      <main className="max-w-3xl mx-auto px-4 py-6 space-y-3">
        {items.map(n => (
          <div key={n.id} className={`bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-4 flex items-start space-x-3 ${n.read ? '' : 'ring-1 ring-blue-100'}`}>
            <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${n.read ? 'bg-gray-100' : 'bg-blue-100'}`}>
              {n.read ? <CheckCircle2 className="w-5 h-5 text-gray-500" /> : <Bell className="w-5 h-5 text-blue-600" />}
            </div>
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <p className="text-sm font-semibold text-gray-900">{n.title}</p>
                <div className="flex items-center text-xs text-gray-500"><Clock className="w-3 h-3 mr-1" />{n.time}</div>
              </div>
              <p className="text-sm text-gray-600 mt-0.5">{n.detail}</p>
            </div>
          </div>
        ))}
      </main>
    </div>
  );
};

export default NotificationsPage;
