import React from 'react';
import { Helmet } from 'react-helmet';
import { User, Mail, Phone, Settings, LogOut, Shield, LifeBuoy } from 'lucide-react';

import { useNavigate } from 'react-router-dom';

const ProfilePage = () => {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      <Helmet>
        <title>Profile - Findmyhome</title>
        <meta name="description" content="Manage your Findmyhome profile and account settings" />
      </Helmet>

      <div className="bg-white/80 backdrop-blur-sm border-b border-white/20 shadow-sm">
        <div className="max-w-screen-md w-full mx-auto px-4 py-3 flex items-center justify-between">
          <h1 className="text-xl font-bold text-gray-900">Profile</h1>
          <button onClick={() => navigate('/chat', { state: { support: true } })} className="px-3 py-1.5 text-sm bg-blue-500 text-white rounded-lg hover:bg-blue-600 flex items-center space-x-2">
            <LifeBuoy className="w-4 h-4" />
            <span>Customer Service</span>
          </button>
        </div>
      </div>

      <main className="max-w-screen-md w-full mx-auto px-4 py-4 pb-6 space-y-4">
        {/* User Summary */}
        <section className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-4 shadow-sm">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 rounded-xl bg-blue-500 flex items-center justify-center shadow-lg">
              <User className="w-6 h-6 text-white" />
            </div>
            <div>
              <p className="text-gray-900 font-semibold">John Doe</p>
              <p className="text-gray-600 text-sm">Property Manager</p>
            </div>
          </div>
        </section>

        {/* Contact Info */}
        <section className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-4 shadow-sm">
          <h2 className="text-sm font-semibold text-gray-900 mb-3">Contact</h2>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Mail className="w-4 h-4 text-gray-500" />
                <span className="text-sm text-gray-700">john.doe@example.com</span>
              </div>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Phone className="w-4 h-4 text-gray-500" />
                <span className="text-sm text-gray-700">+1 (555) 123-4567</span>
              </div>
            </div>
          </div>
        </section>

        {/* Settings */}
        <section className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-2 shadow-sm divide-y divide-white/30">
          <button className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-white/80 transition">
            <div className="flex items-center space-x-3">
              <Settings className="w-4 h-4 text-gray-600" />
              <span className="text-sm text-gray-900">Account Settings</span>
            </div>
            <span className="text-xs text-gray-500">Manage preferences</span>
          </button>
          <button className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-white/80 transition">
            <div className="flex items-center space-x-3">
              <Shield className="w-4 h-4 text-gray-600" />
              <span className="text-sm text-gray-900">Privacy & Security</span>
            </div>
            <span className="text-xs text-gray-500">Permissions</span>
          </button>
          <button className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-white/80 transition">
            <div className="flex items-center space-x-3">
              <LogOut className="w-4 h-4 text-red-600" />
              <span className="text-sm text-red-600">Sign Out</span>
            </div>
            <span className="text-xs text-gray-500">Securely sign out</span>
          </button>
        </section>
      </main>
    </div>
  );
};

export default ProfilePage;
