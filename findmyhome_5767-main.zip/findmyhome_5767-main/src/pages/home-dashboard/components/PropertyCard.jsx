import React from 'react';
import { useNavigate } from 'react-router-dom';

const PropertyCard = ({ id, name, address, occupancy, revenue, image }) => {
  const navigate = useNavigate();

  const handlePropertyClick = () => {
    navigate('/property-details-management', { state: { propertyId: id, propertyData: { name, address, occupancy, revenue, image } } });
  };

  return (
    <div
      onClick={handlePropertyClick}
      className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-3 shadow-sm hover:shadow-md transition-all cursor-pointer hover:bg-white/80"
    >
      <div className="flex items-start space-x-4">
        {/* Property Image */}
        <div className="w-16 h-16 bg-gray-200 rounded-xl overflow-hidden flex-shrink-0">
          <img
            src={image}
            alt={name}
            className="w-full h-full object-cover"
            onError={(e) => {
              e.target.style.display = 'none';
              e.target.parentElement.innerHTML = `
                <div class="w-full h-full bg-gradient-to-br from-blue-100 to-blue-200 flex items-center justify-center">
                  <svg class="w-6 h-6 text-blue-400" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z"/>
                  </svg>
                </div>
              `;
            }}
          />
        </div>

        {/* Property Details */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between mb-1">
            <h4 className="font-semibold text-gray-900 text-sm truncate">{name}</h4>
            <span className="text-xs font-medium text-gray-900 bg-gray-100 px-2 py-1 rounded-full">
              {occupancy}
            </span>
          </div>
          
          <p className="text-xs text-gray-600 mb-2 truncate">{address}</p>
          
          <div className="flex items-center justify-between">
            <span className="text-xs text-gray-500">Revenue</span>
            <span className="text-sm font-semibold text-gray-900">{revenue}</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PropertyCard;
