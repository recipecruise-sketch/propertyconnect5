import React from 'react';

const BottomNavigation = ({ items, onNavigate }) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 max-w-screen-md w-full mx-auto">
      <div className="bg-white/80 backdrop-blur-sm border-t border-white/20 shadow-lg">
        <div className="flex items-center justify-around py-3 px-6">
          {items?.map((item) => (
            <button
              key={item?.id}
              onClick={() => onNavigate?.(item?.id)}
              className={`
                flex flex-col items-center space-y-1 min-w-0 flex-1 transition-colors
                ${item?.active ? 'text-blue-500' : 'text-gray-400 hover:text-gray-600'}
              `}
            >
              <item.icon className="w-5 h-5" />
              <span className="text-xs font-medium truncate">{item?.label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};

export default BottomNavigation;
