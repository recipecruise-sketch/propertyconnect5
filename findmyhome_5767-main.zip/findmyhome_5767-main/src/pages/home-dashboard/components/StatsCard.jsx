import React from 'react';
import Icon from '../../../components/AppIcon';


const StatsCard = ({ title, value, subtitle, icon: Icon, bgColor, glassEffect }) => {
  return (
    <div className={`
      ${glassEffect ? 'bg-white/70 backdrop-blur-sm border border-white/20' : 'bg-white'} 
      p-3 rounded-2xl shadow-sm
    `}>
      <div className="flex items-start justify-between mb-2">
        <div className={`
          ${bgColor} 
          w-10 h-10 rounded-xl flex items-center justify-center
          shadow-lg
        `}>
          <Icon className="w-5 h-5 text-white" />
        </div>
      </div>
      
      <div>
        <p className="text-gray-600 text-sm font-medium mb-1">{title}</p>
        <p className="text-2xl font-bold text-gray-900 mb-1">{value}</p>
        <p className="text-gray-500 text-xs">{subtitle}</p>
      </div>
    </div>
  );
};

export default StatsCard;
