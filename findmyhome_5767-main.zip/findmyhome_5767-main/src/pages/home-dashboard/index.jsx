import React from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import { Home, Users, User, FileText, Plus, LifeBuoy, Settings as SettingsIcon } from 'lucide-react';
import StatsCard from './components/StatsCard';
import PropertyCard from './components/PropertyCard';
import BottomNavigation from './components/BottomNavigation';

const HomeDashboard = () => {
  const navigate = useNavigate();

  // Mock stats data
  const statsData = [
    {
      title: 'Properties',
      value: '3',
      subtitle: '26 units',
      icon: Home,
      bgColor: 'bg-blue-500',
      glassEffect: true
    },
    {
      title: 'Occupancy',
      value: '88.5%',
      subtitle: '29/33 occupied',
      icon: Users,
      bgColor: 'bg-green-500',
      glassEffect: true
    },
    {
      title: 'Revenue',
      value: '₦57K',
      subtitle: '+12% this month',
      icon: FileText,
      bgColor: 'bg-purple-500',
      glassEffect: true
    },
    {
      title: 'Requests',
      value: '2',
      subtitle: '1 pending',
      icon: User,
      bgColor: 'bg-orange-500',
      glassEffect: true
    }
  ];

  // Updated properties data with realistic images
  const propertiesData = [
    {
      id: 1,
      name: 'Sunset Apartments',
      address: '123 Oak Street, Downtown',
      occupancy: '10/12',
      revenue: '₦24K/mo',
      image: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=400&h=300&fit=crop&crop=center'
    },
    {
      id: 2,
      name: 'Garden View Complex',
      address: '456 Pine Avenue, Midtown',
      occupancy: '8/8',
      revenue: '₦18K/mo',
      image: 'https://images.unsplash.com/photo-1572120360610-d971b9d7767c?w=400&h=300&fit=crop&crop=center'
    },
    {
      id: 3,
      name: 'Riverside Condos',
      address: '789 River Road, Uptown',
      occupancy: '5/6',
      revenue: '₦15K/mo',
      image: 'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=400&h=300&fit=crop&crop=center'
    }
  ];

  const handleNavigation = (route) => {
    switch (route) {
      case 'home': navigate('/');
        break;
      case 'tenants': navigate('/tenant-management-dashboard');
        break;
      case 'profile': navigate('/profile');
        break;
      case 'reports': navigate('/comprehensive-reports-center');
        break;
      case 'settings': navigate('/settings');
        break;
      default:
        break;
    }
  };

  const handleAddProperty = () => {
    navigate('/property-details-management');
  };

  const navigationItems = [
    { id: 'home', label: 'Home', icon: Home, active: true },
    { id: 'tenants', label: 'Tenants', icon: Users, active: false },
    { id: 'profile', label: 'Profile', icon: User, active: false },
    { id: 'reports', label: 'Reports', icon: FileText, active: false },
    { id: 'settings', label: 'Settings', icon: SettingsIcon, active: false }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      <Helmet>
        <title>Findmyhome - Property Management Dashboard</title>
        <meta name="description" content="Your property management dashboard" />
      </Helmet>
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-sm border-b border-white/20 shadow-sm">
        <div className="max-w-screen-md w-full mx-auto px-4 py-3">
          <div className="flex items-center justify-between">
            <h1 className="text-xl font-bold text-gray-900">Findmyhome</h1>
            <div className="flex items-center space-x-3">
              <button
                onClick={() => navigate('/property-details-management')}
                className="w-8 h-8 bg-blue-500 hover:bg-blue-600 rounded-full flex items-center justify-center transition-colors"
              >
                <Plus className="w-4 h-4 text-white" />
              </button>
              <button
                onClick={() => navigate('/chat', { state: { support: true } })}
                className="w-8 h-8 bg-blue-500 hover:bg-blue-600 rounded-full flex items-center justify-center transition-colors"
                title="Customer Service"
              >
                <LifeBuoy className="w-5 h-5 text-white" />
              </button>
              <button
                onClick={() => handleNavigation('profile')}
                className="w-8 h-8 bg-blue-500 hover:bg-blue-600 rounded-full flex items-center justify-center transition-colors"
              >
                <User className="w-5 h-5 text-white" />
              </button>
            </div>
          </div>
        </div>
      </div>
      {/* Main Content */}
      <main className="max-w-screen-md w-full mx-auto px-4 py-4 pb-24">
        {/* Welcome Section */}
        <div className="mb-4">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Welcome back, John!</h2>
          <p className="text-gray-600">Here's what's happening with your properties today</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-3 mb-4">
          {statsData?.map((stat, index) => (
            <StatsCard key={index} {...stat} />
          ))}
        </div>

        {/* Your Properties Section */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h3 className="text-lg font-semibold text-gray-900">Your Properties</h3>
            <button
              onClick={handleAddProperty}
              className="text-blue-500 hover:text-blue-600 font-medium text-sm transition-colors"
            >
              Add
            </button>
          </div>
          
          <div className="space-y-2 pb-12">
            {propertiesData?.map((property) => (
              <PropertyCard key={property?.id} {...property} />
            ))}
          </div>
        </div>
      </main>
      {/* Bottom Navigation */}
      <BottomNavigation items={navigationItems} onNavigate={handleNavigation} />
    </div>
  );
};

export default HomeDashboard;
