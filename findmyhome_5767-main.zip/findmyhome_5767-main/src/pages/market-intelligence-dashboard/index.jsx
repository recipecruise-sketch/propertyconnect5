import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import Header from '../../components/ui/Header';
import GlobalFilterBar, { FilterProvider } from '../../components/ui/GlobalFilterBar';
import RealTimeStatusIndicator, { StatusProvider } from '../../components/ui/RealTimeStatusIndicator';
import ExportControlPanel, { ExportProvider } from '../../components/ui/ExportControlPanel';
import MarketControlPanel from './components/MarketControlPanel';
import MarketMetricsRow from './components/MarketMetricsRow';
import MarketComparisonChart from './components/MarketComparisonChart';
import MarketTrendSummary from './components/MarketTrendSummary';
import RentalTrendChart from './components/RentalTrendChart';

const MarketIntelligenceDashboard = () => {
  const [marketFilters, setMarketFilters] = useState({
    marketArea: 'downtown',
    propertyType: 'all',
    timeframe: 'quarterly',
    analysisType: 'competitive'
  });

  const handleMarketFiltersChange = (newFilters) => {
    setMarketFilters(newFilters);
  };

  return (
    <FilterProvider>
      <StatusProvider>
        <ExportProvider>
          <div className="min-h-screen bg-background">
            <Helmet>
              <title>Market Intelligence Dashboard - FindMyHome</title>
              <meta name="description" content="Competitive analysis and pricing optimization insights for property portfolio management" />
            </Helmet>

            <Header />
            <GlobalFilterBar isCollapsed={true} />
            
            <main className="pt-32 pb-8">
              <div className="max-w-7xl mx-auto px-6">
                {/* Page Header */}
                <div className="mb-8">
                  <div className="flex items-center justify-between">
                    <div>
                      <h1 className="text-3xl font-bold text-foreground mb-2">
                        Market Intelligence Dashboard
                      </h1>
                      <p className="text-muted-foreground">
                        Competitive analysis and pricing optimization insights for data-driven market positioning
                      </p>
                    </div>
                    
                    <div className="flex items-center space-x-3">
                      <RealTimeStatusIndicator position="header" />
                    </div>
                  </div>
                </div>

                {/* Market Controls */}
                <MarketControlPanel onFiltersChange={handleMarketFiltersChange} />

                {/* Key Metrics Row */}
                <MarketMetricsRow />

                {/* Main Content Grid */}
                <div className="grid grid-cols-1 xl:grid-cols-12 gap-6 mb-8">
                  {/* Primary Visualization Area */}
                  <div className="xl:col-span-8 space-y-6">
                    <MarketComparisonChart />
                    <RentalTrendChart />
                  </div>

                  {/* Right Sidebar */}
                  <div className="xl:col-span-4">
                    <MarketTrendSummary />
                  </div>
                </div>

                {/* Additional Insights Section */}
                <div className="bg-white rounded-lg border border-border p-6 shadow-elevation-1">
                  <div className="flex items-center justify-between mb-6">
                    <h3 className="text-lg font-semibold text-foreground">
                      Market Intelligence Summary
                    </h3>
                    <div className="text-sm text-muted-foreground">
                      Last updated: {new Date()?.toLocaleDateString('en-US', { 
                        month: 'short', 
                        day: 'numeric', 
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <div className="text-center p-4 bg-success/5 rounded-lg">
                      <div className="text-2xl font-bold text-success mb-1">85%</div>
                      <div className="text-sm text-muted-foreground">Properties Above Market</div>
                      <div className="text-xs text-success mt-1">Strong competitive position</div>
                    </div>
                    
                    <div className="text-center p-4 bg-primary/5 rounded-lg">
                      <div className="text-2xl font-bold text-primary mb-1">₦2,890</div>
                      <div className="text-sm text-muted-foreground">Avg Portfolio Rent</div>
                      <div className="text-xs text-primary mt-1">5.1% above market average</div>
                    </div>
                    
                    <div className="text-center p-4 bg-warning/5 rounded-lg">
                      <div className="text-2xl font-bold text-warning mb-1">3</div>
                      <div className="text-sm text-muted-foreground">Optimization Opportunities</div>
                      <div className="text-xs text-warning mt-1">Potential +₦2,400/month</div>
                    </div>
                  </div>
                </div>
              </div>
            </main>

            <ExportControlPanel position="floating" />
          </div>
        </ExportProvider>
      </StatusProvider>
    </FilterProvider>
  );
};

export default MarketIntelligenceDashboard;
