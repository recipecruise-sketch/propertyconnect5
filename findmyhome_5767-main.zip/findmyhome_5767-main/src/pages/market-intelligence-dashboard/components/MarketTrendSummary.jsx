import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const MarketTrendSummary = () => {
  const marketStats = [
    {
      label: "Avg Market Rent",
      value: "$2,847",
      change: "+5.2%",
      trend: "up",
      period: "vs last quarter"
    },
    {
      label: "Market Vacancy",
      value: "10.9%",
      change: "-1.8%",
      trend: "down",
      period: "vs last quarter"
    },
    {
      label: "Avg Days Listed",
      value: "24 days",
      change: "+3 days",
      trend: "up",
      period: "vs last quarter"
    },
    {
      label: "Price per Sq Ft",
      value: "$2.68",
      change: "+4.1%",
      trend: "up",
      period: "vs last quarter"
    }
  ];

  const recommendations = [
    {
      id: 1,
      priority: "high",
      title: "Increase Rent at Garden View Condos",
      description: "Property is 11% below market rate with strong demand indicators",
      impact: "+$2,400/month",
      action: "Raise rent by $200/unit at lease renewal",
      icon: "TrendingUp"
    },
    {
      id: 2,
      priority: "medium",
      title: "Optimize Marketing for Riverside Towers",
      description: "Above-average days on market suggests pricing or marketing issues",
      impact: "Reduce vacancy by 15 days",
      action: "Review pricing strategy and enhance listings",
      icon: "Target"
    },
    {
      id: 3,
      priority: "medium",
      title: "Monitor Oak Street Studios",
      description: "Below market rent but in declining neighborhood segment",
      impact: "Risk assessment",
      action: "Evaluate market positioning quarterly",
      icon: "AlertTriangle"
    },
    {
      id: 4,
      priority: "low",
      title: "Maintain Premium at Downtown Lofts",
      description: "Successfully commanding premium rates with high occupancy",
      impact: "Sustain performance",
      action: "Continue current strategy",
      icon: "CheckCircle"
    }
  ];

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'text-error';
      case 'medium': return 'text-warning';
      case 'low': return 'text-success';
      default: return 'text-muted-foreground';
    }
  };

  const getPriorityBg = (priority) => {
    switch (priority) {
      case 'high': return 'bg-error/10';
      case 'medium': return 'bg-warning/10';
      case 'low': return 'bg-success/10';
      default: return 'bg-muted/10';
    }
  };

  return (
    <div className="space-y-6">
      {/* Market Statistics */}
      <div className="bg-white rounded-lg border border-border p-6 shadow-elevation-1">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground">Market Overview</h3>
          <Button variant="outline" size="sm" iconName="RefreshCw">
            Refresh
          </Button>
        </div>
        
        <div className="space-y-4">
          {marketStats?.map((stat, index) => (
            <div key={index} className="flex items-center justify-between py-2">
              <div>
                <div className="text-sm text-muted-foreground">{stat?.label}</div>
                <div className="font-semibold text-foreground">{stat?.value}</div>
              </div>
              <div className="text-right">
                <div className={`flex items-center space-x-1 ${
                  stat?.trend === 'up' ? 'text-success' : 'text-error'
                }`}>
                  <Icon 
                    name={stat?.trend === 'up' ? 'ArrowUp' : 'ArrowDown'} 
                    size={14} 
                  />
                  <span className="text-sm font-medium">{stat?.change}</span>
                </div>
                <div className="text-xs text-muted-foreground">{stat?.period}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Recommendations */}
      <div className="bg-white rounded-lg border border-border p-6 shadow-elevation-1">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-foreground">Recommended Actions</h3>
          <div className="text-sm text-muted-foreground">
            Based on market analysis
          </div>
        </div>
        
        <div className="space-y-4">
          {recommendations?.map((rec) => (
            <div key={rec?.id} className="border border-border rounded-lg p-4 hover:shadow-elevation-1 transition-smooth">
              <div className="flex items-start space-x-3">
                <div className={`p-2 rounded-lg ${getPriorityBg(rec?.priority)}`}>
                  <Icon name={rec?.icon} size={16} className={getPriorityColor(rec?.priority)} />
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2 mb-1">
                    <h4 className="font-medium text-foreground">{rec?.title}</h4>
                    <span className={`text-xs px-2 py-1 rounded-full font-medium uppercase tracking-wide ${getPriorityColor(rec?.priority)} ${getPriorityBg(rec?.priority)}`}>
                      {rec?.priority}
                    </span>
                  </div>
                  
                  <p className="text-sm text-muted-foreground mb-2">{rec?.description}</p>
                  
                  <div className="flex items-center justify-between">
                    <div className="text-sm">
                      <span className="text-muted-foreground">Impact: </span>
                      <span className="font-medium text-foreground">{rec?.impact}</span>
                    </div>
                    <Button variant="outline" size="sm">
                      View Details
                    </Button>
                  </div>
                  
                  <div className="mt-2 text-xs text-muted-foreground">
                    <Icon name="Lightbulb" size={12} className="inline mr-1" />
                    {rec?.action}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-4 pt-4 border-t border-border">
          <Button variant="outline" fullWidth iconName="Plus" iconPosition="left">
            Create Custom Analysis
          </Button>
        </div>
      </div>
      {/* Market Insights */}
      <div className="bg-white rounded-lg border border-border p-6 shadow-elevation-1">
        <h3 className="text-lg font-semibold text-foreground mb-4">Market Insights</h3>
        
        <div className="space-y-3">
          <div className="flex items-start space-x-3 p-3 bg-primary/5 rounded-lg">
            <Icon name="TrendingUp" size={16} className="text-primary mt-0.5" />
            <div>
              <div className="text-sm font-medium text-foreground">Strong Rental Demand</div>
              <div className="text-xs text-muted-foreground">
                Your market area shows 15% higher demand than city average
              </div>
            </div>
          </div>
          
          <div className="flex items-start space-x-3 p-3 bg-warning/5 rounded-lg">
            <Icon name="AlertCircle" size={16} className="text-warning mt-0.5" />
            <div>
              <div className="text-sm font-medium text-foreground">Seasonal Adjustment Due</div>
              <div className="text-xs text-muted-foreground">
                Consider 3-5% rent increases for Q4 lease renewals
              </div>
            </div>
          </div>
          
          <div className="flex items-start space-x-3 p-3 bg-success/5 rounded-lg">
            <Icon name="CheckCircle" size={16} className="text-success mt-0.5" />
            <div>
              <div className="text-sm font-medium text-foreground">Competitive Position</div>
              <div className="text-xs text-muted-foreground">
                Portfolio outperforming 78% of comparable properties
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MarketTrendSummary;