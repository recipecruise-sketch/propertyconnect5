import React, { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, ReferenceLine } from 'recharts';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';
import Select from '../../../components/ui/Select';

const RentalTrendChart = () => {
  const [timeframe, setTimeframe] = useState('12months');
  const [showForecast, setShowForecast] = useState(true);
  const [selectedMetric, setSelectedMetric] = useState('rent');

  const trendData = [
    {
      month: 'Jan 2024',
      portfolioRent: 2650,
      marketRent: 2580,
      portfolioOccupancy: 94,
      marketOccupancy: 89,
      forecast: false
    },
    {
      month: 'Feb 2024',
      portfolioRent: 2675,
      marketRent: 2595,
      portfolioOccupancy: 95,
      marketOccupancy: 88,
      forecast: false
    },
    {
      month: 'Mar 2024',
      portfolioRent: 2720,
      marketRent: 2615,
      portfolioOccupancy: 93,
      marketOccupancy: 90,
      forecast: false
    },
    {
      month: 'Apr 2024',
      portfolioRent: 2745,
      marketRent: 2640,
      portfolioOccupancy: 96,
      marketOccupancy: 91,
      forecast: false
    },
    {
      month: 'May 2024',
      portfolioRent: 2780,
      marketRent: 2665,
      portfolioOccupancy: 94,
      marketOccupancy: 89,
      forecast: false
    },
    {
      month: 'Jun 2024',
      portfolioRent: 2825,
      marketRent: 2690,
      portfolioOccupancy: 97,
      marketOccupancy: 92,
      forecast: false
    },
    {
      month: 'Jul 2024',
      portfolioRent: 2850,
      marketRent: 2715,
      portfolioOccupancy: 95,
      marketOccupancy: 90,
      forecast: false
    },
    {
      month: 'Aug 2024',
      portfolioRent: 2875,
      marketRent: 2735,
      portfolioOccupancy: 96,
      marketOccupancy: 91,
      forecast: false
    },
    {
      month: 'Sep 2024',
      portfolioRent: 2890,
      marketRent: 2750,
      portfolioOccupancy: 94,
      marketOccupancy: 89,
      forecast: false
    },
    // Forecast data
    {
      month: 'Oct 2024',
      portfolioRent: 2920,
      marketRent: 2770,
      portfolioOccupancy: 95,
      marketOccupancy: 90,
      forecast: true
    },
    {
      month: 'Nov 2024',
      portfolioRent: 2945,
      marketRent: 2785,
      portfolioOccupancy: 96,
      marketOccupancy: 91,
      forecast: true
    },
    {
      month: 'Dec 2024',
      portfolioRent: 2970,
      marketRent: 2800,
      portfolioOccupancy: 94,
      marketOccupancy: 89,
      forecast: true
    }
  ];

  const timeframeOptions = [
    { value: '6months', label: 'Last 6 Months' },
    { value: '12months', label: 'Last 12 Months' },
    { value: '24months', label: 'Last 24 Months' }
  ];

  const metricOptions = [
    { value: 'rent', label: 'Average Rent' },
    { value: 'occupancy', label: 'Occupancy Rate' }
  ];

  const getFilteredData = () => {
    const months = timeframe === '6months' ? 6 : timeframe === '12months' ? 12 : 24;
    return trendData?.slice(-months);
  };

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload?.length) {
      const data = payload?.[0]?.payload;
      return (
        <div className="bg-white border border-border rounded-lg p-4 shadow-elevation-2">
          <h4 className="font-semibold text-foreground mb-2">{label}</h4>
          <div className="space-y-1">
            {selectedMetric === 'rent' ? (
              <>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-primary"></div>
                    <span className="text-sm text-muted-foreground">Your Portfolio:</span>
                  </div>
                  <span className="font-medium">₦{data?.portfolioRent}</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-muted-foreground"></div>
                    <span className="text-sm text-muted-foreground">Market Average:</span>
                  </div>
                  <span className="font-medium">₦{data?.marketRent}</span>
                </div>
                <div className="pt-1 border-t border-border">
                  <div className="flex justify-between">
                    <span className="text-xs text-muted-foreground">Premium:</span>
                    <span className="text-xs font-medium text-success">
                      +₦{data?.portfolioRent - data?.marketRent} ({(((data?.portfolioRent - data?.marketRent) / data?.marketRent) * 100)?.toFixed(1)}%)
                    </span>
                  </div>
                </div>
              </>
            ) : (
              <>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-primary"></div>
                    <span className="text-sm text-muted-foreground">Your Portfolio:</span>
                  </div>
                  <span className="font-medium">{data?.portfolioOccupancy}%</span>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 rounded-full bg-muted-foreground"></div>
                    <span className="text-sm text-muted-foreground">Market Average:</span>
                  </div>
                  <span className="font-medium">{data?.marketOccupancy}%</span>
                </div>
                <div className="pt-1 border-t border-border">
                  <div className="flex justify-between">
                    <span className="text-xs text-muted-foreground">Difference:</span>
                    <span className="text-xs font-medium text-success">
                      +{data?.portfolioOccupancy - data?.marketOccupancy}%
                    </span>
                  </div>
                </div>
              </>
            )}
            {data?.forecast && (
              <div className="pt-1 text-xs text-warning">
                <Icon name="TrendingUp" size={12} className="inline mr-1" />
                Forecast Data
              </div>
            )}
          </div>
        </div>
      );
    }
    return null;
  };

  const filteredData = getFilteredData();

  return (
    <div className="bg-white rounded-lg border border-border p-6 shadow-elevation-1">
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between mb-6 space-y-4 lg:space-y-0">
        <div>
          <h3 className="text-lg font-semibold text-foreground">Market Trend Analysis</h3>
          <p className="text-sm text-muted-foreground">
            Portfolio performance vs market averages with seasonal adjustments
          </p>
        </div>
        
        <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-2 sm:space-y-0 sm:space-x-4">
          <Select
            options={metricOptions}
            value={selectedMetric}
            onChange={setSelectedMetric}
            className="w-full sm:w-40"
          />
          
          <Select
            options={timeframeOptions}
            value={timeframe}
            onChange={setTimeframe}
            className="w-full sm:w-40"
          />
          
          <Button
            variant={showForecast ? "default" : "outline"}
            size="sm"
            iconName="TrendingUp"
            iconPosition="left"
            onClick={() => setShowForecast(!showForecast)}
          >
            Forecast
          </Button>
        </div>
      </div>

      <div className="h-80 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart
            data={filteredData}
            margin={{ top: 20, right: 30, left: 20, bottom: 60 }}
          >
            <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
            <XAxis 
              dataKey="month" 
              stroke="var(--color-muted-foreground)"
              fontSize={12}
              angle={-45}
              textAnchor="end"
              height={60}
            />
            <YAxis 
              stroke="var(--color-muted-foreground)"
              fontSize={12}
              domain={selectedMetric === 'rent' ? ['dataMin - 100', 'dataMax + 100'] : [80, 100]}
            />
            <Tooltip content={<CustomTooltip />} />
            
            {/* Current date reference line */}
            <ReferenceLine 
              x="Sep 2024" 
              stroke="var(--color-warning)" 
              strokeDasharray="2 2"
              label={{ value: "Current", position: "top" }}
            />
            
            {/* Portfolio line */}
            <Line
              type="monotone"
              dataKey={selectedMetric === 'rent' ? 'portfolioRent' : 'portfolioOccupancy'}
              stroke="var(--color-primary)"
              strokeWidth={3}
              dot={{ fill: 'var(--color-primary)', strokeWidth: 2, r: 4 }}
              activeDot={{ r: 6, stroke: 'var(--color-primary)', strokeWidth: 2 }}
              connectNulls={false}
            />
            
            {/* Market average line */}
            <Line
              type="monotone"
              dataKey={selectedMetric === 'rent' ? 'marketRent' : 'marketOccupancy'}
              stroke="var(--color-muted-foreground)"
              strokeWidth={2}
              strokeDasharray="5 5"
              dot={{ fill: 'var(--color-muted-foreground)', strokeWidth: 2, r: 3 }}
              activeDot={{ r: 5, stroke: 'var(--color-muted-foreground)', strokeWidth: 2 }}
              connectNulls={false}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      <div className="mt-4 flex flex-col sm:flex-row items-start sm:items-center justify-between space-y-4 sm:space-y-0">
        <div className="flex flex-wrap items-center gap-6">
          <div className="flex items-center space-x-2">
            <div className="w-4 h-0.5 bg-primary"></div>
            <span className="text-sm text-muted-foreground">Your Portfolio</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-4 h-0.5 bg-muted-foreground border-dashed border-t-2"></div>
            <span className="text-sm text-muted-foreground">Market Average</span>
          </div>
          {showForecast && (
            <div className="flex items-center space-x-2">
              <Icon name="TrendingUp" size={14} className="text-warning" />
              <span className="text-sm text-muted-foreground">Forecast Data</span>
            </div>
          )}
        </div>
        
        <div className="text-xs text-muted-foreground">
          Data updated weekly • Next update: Sep 12, 2024
        </div>
      </div>
    </div>
  );
};

export default RentalTrendChart;
