import React, { useState } from 'react';
import Select from '../../../components/ui/Select';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const MarketControlPanel = ({ onFiltersChange }) => {
  const [filters, setFilters] = useState({
    marketArea: 'downtown',
    propertyType: 'all',
    timeframe: 'quarterly',
    analysisType: 'competitive'
  });

  const marketAreaOptions = [
    { value: 'downtown', label: 'Downtown Core' },
    { value: 'midtown', label: 'Midtown District' },
    { value: 'suburbs', label: 'Suburban Areas' },
    { value: 'waterfront', label: 'Waterfront Properties' },
    { value: 'business-district', label: 'Business District' },
    { value: 'all', label: 'All Areas' }
  ];

  const propertyTypeOptions = [
    { value: 'all', label: 'All Property Types' },
    { value: '1 room studio apartment', label: '1 room studio apartment' },
    { value: '1 bedroom apartment or duplex', label: '1 bedroom apartment or duplex' },
    { value: '2 bedroom apartment or duplex', label: '2 bedroom apartment or duplex' },
    { value: '3 bedroom apartment or duplex', label: '3 bedroom apartment or duplex' }
  ];

  const timeframeOptions = [
    { value: 'monthly', label: 'Monthly Analysis' },
    { value: 'quarterly', label: 'Quarterly Reports' },
    { value: 'annual', label: 'Annual Overview' },
    { value: 'custom', label: 'Custom Range' }
  ];

  const analysisTypeOptions = [
    { value: 'competitive', label: 'Competitive Analysis' },
    { value: 'pricing', label: 'Pricing Optimization' },
    { value: 'demand', label: 'Demand Forecasting' },
    { value: 'market-timing', label: 'Market Timing' }
  ];

  const handleFilterChange = (key, value) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    if (onFiltersChange) {
      onFiltersChange(newFilters);
    }
  };

  const resetFilters = () => {
    const defaultFilters = {
      marketArea: 'downtown',
      propertyType: 'all',
      timeframe: 'quarterly',
      analysisType: 'competitive'
    };
    setFilters(defaultFilters);
    if (onFiltersChange) {
      onFiltersChange(defaultFilters);
    }
  };

  const hasActiveFilters = () => {
    return filters?.marketArea !== 'downtown' || 
           filters?.propertyType !== 'all' || 
           filters?.timeframe !== 'quarterly' || 
           filters?.analysisType !== 'competitive';
  };

  return (
    <div className="bg-white rounded-lg border border-border p-6 shadow-elevation-1 mb-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center space-x-2">
          <Icon name="Settings" size={20} className="text-muted-foreground" />
          <h3 className="text-lg font-semibold text-foreground">Market Analysis Controls</h3>
        </div>
        
        <div className="flex items-center space-x-2">
          {hasActiveFilters() && (
            <Button
              variant="ghost"
              size="sm"
              iconName="RotateCcw"
              iconPosition="left"
              onClick={resetFilters}
            >
              Reset
            </Button>
          )}
          
          <Button
            variant="outline"
            size="sm"
            iconName="Download"
            iconPosition="left"
          >
            Export Analysis
          </Button>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Select
          label="Market Area"
          options={marketAreaOptions}
          value={filters?.marketArea}
          onChange={(value) => handleFilterChange('marketArea', value)}
          placeholder="Select market area..."
        />

        <Select
          label="Property Type"
          options={propertyTypeOptions}
          value={filters?.propertyType}
          onChange={(value) => handleFilterChange('propertyType', value)}
          placeholder="Select property type..."
        />

        <Select
          label="Analysis Timeframe"
          options={timeframeOptions}
          value={filters?.timeframe}
          onChange={(value) => handleFilterChange('timeframe', value)}
          placeholder="Select timeframe..."
        />

        <Select
          label="Analysis Type"
          options={analysisTypeOptions}
          value={filters?.analysisType}
          onChange={(value) => handleFilterChange('analysisType', value)}
          placeholder="Select analysis type..."
        />
      </div>
      {/* Quick Actions */}
      <div className="mt-6 pt-4 border-t border-border">
        <div className="flex items-center justify-between">
          <div className="text-sm text-muted-foreground">
            Quick Actions:
          </div>
          
          <div className="flex items-center space-x-2">
            <Button
              variant="ghost"
              size="sm"
              iconName="RefreshCw"
              iconPosition="left"
            >
              Refresh Data
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              iconName="Calendar"
              iconPosition="left"
            >
              Schedule Report
            </Button>
            
            <Button
              variant="ghost"
              size="sm"
              iconName="Bell"
              iconPosition="left"
            >
              Set Alerts
            </Button>
          </div>
        </div>
      </div>
      {/* Active Filters Summary */}
      {hasActiveFilters() && (
        <div className="mt-4 p-3 bg-primary/5 rounded-lg">
          <div className="flex items-center space-x-2 mb-2">
            <Icon name="Filter" size={16} className="text-primary" />
            <span className="text-sm font-medium text-foreground">Active Filters:</span>
          </div>
          
          <div className="flex flex-wrap gap-2">
            {filters?.marketArea !== 'downtown' && (
              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-primary/10 text-primary">
                Area: {marketAreaOptions?.find(opt => opt?.value === filters?.marketArea)?.label}
              </span>
            )}
            
            {filters?.propertyType !== 'all' && (
              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-primary/10 text-primary">
                Type: {propertyTypeOptions?.find(opt => opt?.value === filters?.propertyType)?.label}
              </span>
            )}
            
            {filters?.timeframe !== 'quarterly' && (
              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-primary/10 text-primary">
                Period: {timeframeOptions?.find(opt => opt?.value === filters?.timeframe)?.label}
              </span>
            )}
            
            {filters?.analysisType !== 'competitive' && (
              <span className="inline-flex items-center px-2 py-1 rounded-full text-xs bg-primary/10 text-primary">
                Analysis: {analysisTypeOptions?.find(opt => opt?.value === filters?.analysisType)?.label}
              </span>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default MarketControlPanel;
