import React from 'react';
import Icon from '../../../components/AppIcon';

const MarketMetricsRow = () => {
  const metrics = [
    {
      id: 1,
      title: "Market Rent Premium",
      value: "+12.5%",
      subtitle: "Above Market Average",
      trend: "up",
      percentile: "85th",
      icon: "TrendingUp",
      color: "text-success",
      bgColor: "bg-success/10"
    },
    {
      id: 2,
      title: "Days on Market",
      value: "18 days",
      subtitle: "vs 24 market avg",
      trend: "down",
      percentile: "72nd",
      icon: "Clock",
      color: "text-success",
      bgColor: "bg-success/10"
    },
    {
      id: 3,
      title: "Occupancy Rate",
      value: "94.2%",
      subtitle: "vs 89.1% market",
      trend: "up",
      percentile: "91st",
      icon: "Users",
      color: "text-success",
      bgColor: "bg-success/10"
    },
    {
      id: 4,
      title: "Rental Yield",
      value: "6.8%",
      subtitle: "Annual Return",
      trend: "up",
      percentile: "78th",
      icon: "DollarSign",
      color: "text-warning",
      bgColor: "bg-warning/10"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {metrics?.map((metric) => (
        <div key={metric?.id} className="bg-white rounded-lg border border-border p-6 shadow-elevation-1 hover:shadow-elevation-2 transition-smooth">
          <div className="flex items-start justify-between mb-4">
            <div className={`p-3 rounded-lg ${metric?.bgColor}`}>
              <Icon name={metric?.icon} size={24} className={metric?.color} />
            </div>
            <div className="text-right">
              <div className="text-xs text-muted-foreground font-medium">
                {metric?.percentile} Percentile
              </div>
              <div className="flex items-center space-x-1 mt-1">
                <Icon 
                  name={metric?.trend === 'up' ? 'ArrowUp' : 'ArrowDown'} 
                  size={12} 
                  className={metric?.trend === 'up' ? 'text-success' : 'text-error'} 
                />
                <span className={`text-xs font-medium ${metric?.trend === 'up' ? 'text-success' : 'text-error'}`}>
                  {metric?.trend === 'up' ? 'Above' : 'Below'} Market
                </span>
              </div>
            </div>
          </div>
          
          <div className="space-y-1">
            <h3 className="text-sm font-medium text-muted-foreground">{metric?.title}</h3>
            <div className="text-2xl font-bold text-foreground">{metric?.value}</div>
            <p className="text-sm text-muted-foreground">{metric?.subtitle}</p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default MarketMetricsRow;