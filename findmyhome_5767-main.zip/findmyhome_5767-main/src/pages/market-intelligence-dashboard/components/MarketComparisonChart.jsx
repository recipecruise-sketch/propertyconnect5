import React, { useState } from 'react';
import { ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

import Button from '../../../components/ui/Button';

const MarketComparisonChart = () => {
  const [selectedProperty, setSelectedProperty] = useState(null);
  const [viewMode, setViewMode] = useState('rent-vs-size');

  const portfolioData = [
    {
      id: 1,
      name: "Sunset Apartments",
      rentPerSqFt: 2.85,
      size: 1200,
      value: 450000,
      occupancy: 95,
      type: "apartment",
      opportunity: "high",
      marketRent: 2.65,
      daysOnMarket: 15
    },
    {
      id: 2,
      name: "Downtown Lofts",
      rentPerSqFt: 3.20,
      size: 900,
      value: 380000,
      occupancy: 88,
      type: "loft",
      opportunity: "medium",
      marketRent: 3.10,
      daysOnMarket: 22
    },
    {
      id: 3,
      name: "Garden View Condos",
      rentPerSqFt: 2.45,
      size: 1400,
      value: 520000,
      occupancy: 92,
      type: "condo",
      opportunity: "low",
      marketRent: 2.75,
      daysOnMarket: 28
    },
    {
      id: 4,
      name: "Metro Heights",
      rentPerSqFt: 2.95,
      size: 1100,
      value: 420000,
      occupancy: 97,
      type: "apartment",
      opportunity: "high",
      marketRent: 2.80,
      daysOnMarket: 12
    },
    {
      id: 5,
      name: "Riverside Towers",
      rentPerSqFt: 3.45,
      size: 800,
      value: 350000,
      occupancy: 85,
      type: "apartment",
      opportunity: "medium",
      marketRent: 3.25,
      daysOnMarket: 35
    },
    {
      id: 6,
      name: "Oak Street Studios",
      rentPerSqFt: 2.15,
      size: 600,
      value: 180000,
      occupancy: 90,
      type: "studio",
      opportunity: "low",
      marketRent: 2.40,
      daysOnMarket: 18
    }
  ];

  const getOpportunityColor = (opportunity) => {
    switch (opportunity) {
      case 'high': return '#28A745';
      case 'medium': return '#FFC107';
      case 'low': return '#DC3545';
      default: return '#6C757D';
    }
  };

  const CustomTooltip = ({ active, payload, label }) => {
    if (active && payload && payload?.length) {
      const data = payload?.[0]?.payload;
      return (
        <div className="bg-white border border-border rounded-lg p-4 shadow-elevation-2">
          <h4 className="font-semibold text-foreground mb-2">{data?.name}</h4>
          <div className="space-y-1 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Rent/Sq Ft:</span>
              <span className="font-medium">₦{data?.rentPerSqFt}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Market Rate:</span>
              <span className="font-medium">₦{data?.marketRent}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Size:</span>
              <span className="font-medium">{data?.size} sq ft</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Occupancy:</span>
              <span className="font-medium">{data?.occupancy}%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Opportunity:</span>
              <span className={`font-medium capitalize ${
                data?.opportunity === 'high' ? 'text-success' : 
                data?.opportunity === 'medium' ? 'text-warning' : 'text-error'
              }`}>
                {data?.opportunity}
              </span>
            </div>
          </div>
        </div>
      );
    }
    return null;
  };

  const viewModes = [
    { id: 'rent-vs-size', label: 'Rent vs Size', xKey: 'size', yKey: 'rentPerSqFt' },
    { id: 'occupancy-vs-rent', label: 'Occupancy vs Rent', xKey: 'rentPerSqFt', yKey: 'occupancy' },
    { id: 'market-vs-days', label: 'Market Time vs Rent', xKey: 'daysOnMarket', yKey: 'rentPerSqFt' }
  ];

  const currentMode = viewModes?.find(mode => mode?.id === viewMode);

  return (
    <div className="bg-white rounded-lg border border-border p-6 shadow-elevation-1">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h3 className="text-lg font-semibold text-foreground">Portfolio Market Comparison</h3>
          <p className="text-sm text-muted-foreground">
            Interactive analysis of your properties against market benchmarks
          </p>
        </div>
        
        <div className="flex items-center space-x-2">
          {viewModes?.map((mode) => (
            <Button
              key={mode?.id}
              variant={viewMode === mode?.id ? "default" : "outline"}
              size="sm"
              onClick={() => setViewMode(mode?.id)}
            >
              {mode?.label}
            </Button>
          ))}
        </div>
      </div>
      <div className="h-96 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <ScatterChart
            data={portfolioData}
            margin={{ top: 20, right: 20, bottom: 60, left: 60 }}
          >
            <CartesianGrid strokeDasharray="3 3" stroke="var(--color-border)" />
            <XAxis 
              type="number" 
              dataKey={currentMode?.xKey}
              stroke="var(--color-muted-foreground)"
              fontSize={12}
              name={currentMode?.label?.split(' vs ')?.[1]}
            />
            <YAxis 
              type="number" 
              dataKey={currentMode?.yKey}
              stroke="var(--color-muted-foreground)"
              fontSize={12}
              name={currentMode?.label?.split(' vs ')?.[0]}
            />
            <Tooltip content={<CustomTooltip />} />
            <Scatter 
              name="Properties" 
              dataKey={currentMode?.yKey}
              onClick={(data) => setSelectedProperty(data)}
            >
              {portfolioData?.map((entry, index) => (
                <Cell 
                  key={`cell-${index}`} 
                  fill={getOpportunityColor(entry?.opportunity)}
                  stroke={selectedProperty?.id === entry?.id ? '#007BFF' : 'transparent'}
                  strokeWidth={selectedProperty?.id === entry?.id ? 3 : 0}
                  r={Math.sqrt(entry?.value / 10000)}
                />
              ))}
            </Scatter>
          </ScatterChart>
        </ResponsiveContainer>
      </div>
      <div className="mt-4 flex items-center justify-between">
        <div className="flex items-center space-x-6">
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-success"></div>
            <span className="text-sm text-muted-foreground">High Opportunity</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-warning"></div>
            <span className="text-sm text-muted-foreground">Medium Opportunity</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-3 h-3 rounded-full bg-error"></div>
            <span className="text-sm text-muted-foreground">Low Opportunity</span>
          </div>
        </div>
        
        <div className="text-xs text-muted-foreground">
          Bubble size represents property value • Click to select property
        </div>
      </div>
      {selectedProperty && (
        <div className="mt-4 p-4 bg-muted/30 rounded-lg border border-border">
          <div className="flex items-center justify-between">
            <div>
              <h4 className="font-semibold text-foreground">{selectedProperty?.name}</h4>
              <p className="text-sm text-muted-foreground">Selected Property Details</p>
            </div>
            <Button
              variant="ghost"
              size="sm"
              iconName="X"
              onClick={() => setSelectedProperty(null)}
            />
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-3">
            <div>
              <div className="text-xs text-muted-foreground">Current Rent</div>
              <div className="font-semibold">₦{selectedProperty?.rentPerSqFt}/sq ft</div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground">Market Rate</div>
              <div className="font-semibold">₦{selectedProperty?.marketRent}/sq ft</div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground">Opportunity</div>
              <div className={`font-semibold capitalize ${
                selectedProperty?.opportunity === 'high' ? 'text-success' : 
                selectedProperty?.opportunity === 'medium' ? 'text-warning' : 'text-error'
              }`}>
                {selectedProperty?.opportunity}
              </div>
            </div>
            <div>
              <div className="text-xs text-muted-foreground">Days on Market</div>
              <div className="font-semibold">{selectedProperty?.daysOnMarket} days</div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default MarketComparisonChart;
