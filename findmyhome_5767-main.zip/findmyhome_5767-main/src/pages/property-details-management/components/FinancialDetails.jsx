import React from 'react';
import { DollarSign, TrendingUp, TrendingDown, Calculator, PieChart } from 'lucide-react';

const FinancialDetails = ({ property, setProperty, isEditing }) => {
  const handleInputChange = (field, value) => {
    setProperty(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const financialMetrics = [
    { 
      label: 'Purchase Price', 
      field: 'purchasePrice', 
      value: property?.purchasePrice, 
      icon: DollarSign,
      color: 'bg-blue-100 text-blue-600'
    },
    { 
      label: 'Current Market Value', 
      field: 'marketValue', 
      value: property?.marketValue, 
      icon: TrendingUp,
      color: 'bg-green-100 text-green-600'
    },
    { 
      label: 'Monthly Rent', 
      field: 'currentRent', 
      value: property?.currentRent, 
      icon: Calculator,
      color: 'bg-purple-100 text-purple-600'
    },
    { 
      label: 'Monthly Expenses', 
      field: 'monthlyExpenses', 
      value: property?.monthlyExpenses, 
      icon: TrendingDown,
      color: 'bg-red-100 text-red-600'
    }
  ];

  // Calculate derived metrics
  const monthlyRent = parseFloat(property?.currentRent?.replace(/[₦$,]/g, '')) || 0;
  const monthlyExpenses = parseFloat(property?.monthlyExpenses?.replace(/[₦$,]/g, '')) || 0;
  const monthlyProfit = monthlyRent - monthlyExpenses;
  const annualRent = monthlyRent * 12;
  const purchasePrice = parseFloat(property?.purchasePrice?.replace(/[₦$,]/g, '')) || 1;
  const capRate = ((annualRent - (monthlyExpenses * 12)) / purchasePrice * 100)?.toFixed(2);

  return (
    <div className="space-y-6">
      {/* Financial Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {financialMetrics?.map((metric, index) => (
          <div key={index} className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-4">
            <div className="flex items-center space-x-3 mb-3">
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${metric?.color}`}>
                <metric.icon className="w-5 h-5" />
              </div>
              <h3 className="font-medium text-gray-900 text-sm">{metric?.label}</h3>
            </div>
            {isEditing ? (
              <input
                type="text"
                value={metric?.value}
                onChange={(e) => handleInputChange(metric?.field, e?.target?.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="₦0"
              />
            ) : (
              <p className="text-lg font-bold text-gray-900">{metric?.value}</p>
            )}
          </div>
        ))}
      </div>
      {/* Performance Metrics */}
      <div className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Performance Metrics</h3>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center p-4 bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl border border-green-200">
            <div className="flex items-center justify-center w-12 h-12 bg-green-100 rounded-full mx-auto mb-3">
              <TrendingUp className="w-6 h-6 text-green-600" />
            </div>
            <p className="text-2xl font-bold text-green-600">₦{monthlyProfit?.toLocaleString()}</p>
            <p className="text-sm text-green-700">Monthly Cash Flow</p>
          </div>
          
          <div className="text-center p-4 bg-gradient-to-r from-blue-50 to-cyan-50 rounded-xl border border-blue-200">
            <div className="flex items-center justify-center w-12 h-12 bg-blue-100 rounded-full mx-auto mb-3">
              <Calculator className="w-6 h-6 text-blue-600" />
            </div>
            <p className="text-2xl font-bold text-blue-600">{capRate}%</p>
            <p className="text-sm text-blue-700">Cap Rate</p>
          </div>
          
          <div className="text-center p-4 bg-gradient-to-r from-purple-50 to-violet-50 rounded-xl border border-purple-200">
            <div className="flex items-center justify-center w-12 h-12 bg-purple-100 rounded-full mx-auto mb-3">
              <PieChart className="w-6 h-6 text-purple-600" />
            </div>
            <p className="text-2xl font-bold text-purple-600">{property?.occupancyRate}</p>
            <p className="text-sm text-purple-700">Occupancy Rate</p>
          </div>
        </div>
      </div>
      {/* Expense Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Expense Breakdown</h3>
          
          <div className="space-y-3">
            {[
              { label: 'Property Tax', amount: '₦120', percentage: '27%' },
              { label: 'Insurance', amount: '₦85', percentage: '19%' },
              { label: 'Maintenance', amount: '₦100', percentage: '22%' },
              { label: 'Management Fee', amount: '₦95', percentage: '21%' },
              { label: 'Utilities', amount: '₦50', percentage: '11%' }
            ]?.map((expense, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <span className="text-sm font-medium text-gray-700">{expense?.label}</span>
                <div className="flex items-center space-x-3">
                  <span className="text-sm font-semibold text-gray-900">{expense?.amount}</span>
                  <span className="text-xs text-gray-500">({expense?.percentage})</span>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Investment Summary</h3>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 border-b border-gray-200">
              <span className="text-sm font-medium text-gray-600">Total Investment</span>
              <span className="text-sm font-semibold text-gray-900">{property?.purchasePrice}</span>
            </div>
            <div className="flex items-center justify-between p-3 border-b border-gray-200">
              <span className="text-sm font-medium text-gray-600">Current Value</span>
              <span className="text-sm font-semibold text-gray-900">{property?.marketValue}</span>
            </div>
            <div className="flex items-center justify-between p-3 border-b border-gray-200">
              <span className="text-sm font-medium text-gray-600">Appreciation</span>
              <span className="text-sm font-semibold text-green-600">+₦30,000 (8.6%)</span>
            </div>
            <div className="flex items-center justify-between p-3 border-b border-gray-200">
              <span className="text-sm font-medium text-gray-600">Annual Income</span>
              <span className="text-sm font-semibold text-gray-900">₦{(monthlyRent * 12)?.toLocaleString()}</span>
            </div>
            <div className="flex items-center justify-between p-3">
              <span className="text-sm font-medium text-gray-600">ROI (Annual)</span>
              <span className="text-sm font-semibold text-green-600">12.4%</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FinancialDetails;
