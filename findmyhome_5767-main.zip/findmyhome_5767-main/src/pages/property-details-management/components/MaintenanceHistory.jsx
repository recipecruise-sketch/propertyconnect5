import React, { useState } from 'react';
import { Calendar, DollarSign, User, CheckCircle2, Clock, AlertCircle, Plus, Filter } from 'lucide-react';

const MaintenanceHistory = ({ property }) => {
  const [activeTab, setActiveTab] = useState('all');
  const [showAddRequest, setShowAddRequest] = useState(false);

  const maintenanceRecords = [
    {
      id: 1,
      type: 'Plumbing',
      description: 'Kitchen faucet leak repair',
      date: '2024-01-10',
      cost: '₦125',
      status: 'completed',
      contractor: 'Mike\'s Plumbing',
      priority: 'medium',
      requestedBy: 'Sarah Johnson (Tenant)',
      completedDate: '2024-01-12'
    },
    {
      id: 2,
      type: 'HVAC',
      description: 'Annual air conditioning maintenance',
      date: '2023-12-15',
      cost: '₦200',
      status: 'completed',
      contractor: 'Cool Air Services',
      priority: 'low',
      requestedBy: 'Property Manager',
      completedDate: '2023-12-15'
    },
    {
      id: 3,
      type: 'Electrical',
      description: 'Bathroom outlet not working',
      date: '2024-01-08',
      cost: '₦85',
      status: 'in_progress',
      contractor: 'Spark Electric',
      priority: 'high',
      requestedBy: 'Michael Chen (Tenant)',
      estimatedCompletion: '2024-01-20'
    },
    {
      id: 4,
      type: 'General',
      description: 'Paint touch-up in living room',
      date: '2024-01-05',
      cost: '₦60',
      status: 'pending',
      contractor: 'TBD',
      priority: 'low',
      requestedBy: 'Emily Rodriguez (Tenant)',
      estimatedCompletion: '2024-01-25'
    }
  ];

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed': return <CheckCircle2 className="w-4 h-4 text-green-600" />;
      case 'in_progress': return <Clock className="w-4 h-4 text-yellow-600" />;
      case 'pending': return <AlertCircle className="w-4 h-4 text-red-600" />;
      default: return <Clock className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed': return 'bg-green-100 text-green-800 border-green-200';
      case 'in_progress': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'pending': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const filteredRecords = maintenanceRecords?.filter(record => {
    if (activeTab === 'all') return true;
    return record?.status === activeTab;
  });

  const tabs = [
    { id: 'all', label: 'All Requests', count: maintenanceRecords?.length },
    { id: 'pending', label: 'Pending', count: maintenanceRecords?.filter(r => r?.status === 'pending')?.length },
    { id: 'in_progress', label: 'In Progress', count: maintenanceRecords?.filter(r => r?.status === 'in_progress')?.length },
    { id: 'completed', label: 'Completed', count: maintenanceRecords?.filter(r => r?.status === 'completed')?.length }
  ];

  return (
    <div className="space-y-6">
      {/* Summary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <Calendar className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Total Requests</p>
              <p className="text-xl font-bold text-gray-900">{maintenanceRecords?.length}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <CheckCircle2 className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Completed</p>
              <p className="text-xl font-bold text-gray-900">
                {maintenanceRecords?.filter(r => r?.status === 'completed')?.length}
              </p>
            </div>
          </div>
        </div>
        
        <div className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
              <Clock className="w-5 h-5 text-yellow-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">In Progress</p>
              <p className="text-xl font-bold text-gray-900">
                {maintenanceRecords?.filter(r => r?.status === 'in_progress')?.length}
              </p>
            </div>
          </div>
        </div>
        
        <div className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-red-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Total Cost</p>
              <p className="text-xl font-bold text-gray-900">
                ₦{ maintenanceRecords?.reduce((sum, record) =>
                  sum + parseFloat(record?.cost?.replace(/[₦$,]/g, '')), 0)?.toLocaleString() }
              </p>
            </div>
          </div>
        </div>
      </div>
      {/* Tab Navigation and Actions */}
      <div className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900">Maintenance Requests</h3>
          <div className="flex items-center space-x-2">
            <button className="flex items-center space-x-2 px-3 py-2 text-sm text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors">
              <Filter className="w-4 h-4" />
              <span>Filter</span>
            </button>
            <button
              onClick={() => setShowAddRequest(true)}
              className="flex items-center space-x-2 px-3 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
            >
              <Plus className="w-4 h-4" />
              <span>Add Request</span>
            </button>
          </div>
        </div>
        
        {/* Tab Navigation */}
        <div className="flex flex-wrap gap-2 mb-6">
          {tabs?.map((tab) => (
            <button
              key={tab?.id}
              onClick={() => setActiveTab(tab?.id)}
              className={`
                inline-flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors
                ${activeTab === tab?.id
                  ? 'bg-blue-100 text-blue-800 border border-blue-200' :'bg-gray-100 text-gray-600 hover:bg-gray-200 border border-transparent'
                }
              `}
            >
              <span>{tab?.label}</span>
              <span className={`
                inline-flex items-center justify-center w-5 h-5 text-xs font-bold rounded-full
                ${activeTab === tab?.id ? 'bg-blue-200 text-blue-800' : 'bg-gray-200 text-gray-600'}
              `}>
                {tab?.count}
              </span>
            </button>
          ))}
        </div>

        {/* Maintenance Records List */}
        <div className="space-y-4">
          {filteredRecords?.map((record) => (
            <div key={record?.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-all">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center space-x-3">
                  {getStatusIcon(record?.status)}
                  <div>
                    <h4 className="font-medium text-gray-900">{record?.description}</h4>
                    <p className="text-sm text-gray-600">{record?.type}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium border ${getStatusColor(record?.status)}`}>
                    {record?.status?.replace('_', ' ')}
                  </span>
                  <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getPriorityColor(record?.priority)}`}>
                    {record?.priority} priority
                  </span>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 text-sm">
                <div className="flex items-center space-x-2 text-gray-600">
                  <Calendar className="w-4 h-4" />
                  <span>Requested: {new Date(record.date)?.toLocaleDateString()}</span>
                </div>
                <div className="flex items-center space-x-2 text-gray-600">
                  <DollarSign className="w-4 h-4" />
                  <span>Cost: {record?.cost}</span>
                </div>
                <div className="flex items-center space-x-2 text-gray-600">
                  <User className="w-4 h-4" />
                  <span>Contractor: {record?.contractor}</span>
                </div>
                <div className="flex items-center space-x-2 text-gray-600">
                  <span className="text-xs">By: {record?.requestedBy}</span>
                </div>
              </div>
              
              {record?.status === 'completed' && record?.completedDate && (
                <div className="mt-2 pt-2 border-t border-gray-200">
                  <p className="text-sm text-green-600">
                    Completed on {new Date(record.completedDate)?.toLocaleDateString()}
                  </p>
                </div>
              )}
              
              {record?.status !== 'completed' && record?.estimatedCompletion && (
                <div className="mt-2 pt-2 border-t border-gray-200">
                  <p className="text-sm text-yellow-600">
                    Estimated completion: {new Date(record.estimatedCompletion)?.toLocaleDateString()}
                  </p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default MaintenanceHistory;
