import React from 'react';
import { Home, MapPin, Calendar, Square, Bed, Bath, Car, Heart } from 'lucide-react';

const PropertySpecs = ({ property, setProperty, isEditing }) => {
  const handleInputChange = (field, value) => {
    setProperty(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const specs = [
    { icon: Square, label: 'Square Footage', field: 'squareFootage', value: property?.squareFootage, suffix: 'sq ft' },
    { icon: Bed, label: 'Bedrooms', field: 'bedrooms', value: property?.bedrooms },
    { icon: Bath, label: 'Bathrooms', field: 'bathrooms', value: property?.bathrooms },
    { icon: Car, label: 'Parking Spaces', field: 'parkingSpaces', value: property?.parkingSpaces }
  ];

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      {/* Basic Information */}
      <div className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Basic Information</h3>
        
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Property Name</label>
            {isEditing ? (
              <input
                type="text"
                value={property?.name}
                onChange={(e) => handleInputChange('name', e?.target?.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            ) : (
              <p className="text-gray-900">{property?.name}</p>
            )}
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Address</label>
            {isEditing ? (
              <input
                type="text"
                value={property?.address}
                onChange={(e) => handleInputChange('address', e?.target?.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            ) : (
              <div className="flex items-center space-x-2 text-gray-900">
                <MapPin className="w-4 h-4 text-gray-400" />
                <span>{property?.address}</span>
              </div>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">State</label>
            {isEditing ? (
              <select
                value={property?.state || ''}
                onChange={(e) => handleInputChange('state', e?.target?.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="" disabled>Select a state</option>
                {['Abia','Adamawa','Akwa Ibom','Anambra','Bauchi','Bayelsa','Benue','Borno','Cross River','Delta','Ebonyi','Edo','Ekiti','Enugu','Gombe','Imo','Jigawa','Kaduna','Kano','Katsina','Kebbi','Kogi','Kwara','Lagos','Nasarawa','Niger','Ogun','Ondo','Osun','Oyo','Plateau','Rivers','Sokoto','Taraba','Yobe','Zamfara','FCT Abuja'].map(st => (
                  <option key={st} value={st}>{st}</option>
                ))}
              </select>
            ) : (
              <p className="text-gray-900">{property?.state || '—'}</p>
            )}
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Property Type</label>
            {isEditing ? (
              <select
                value={property?.type}
                onChange={(e) => handleInputChange('type', e?.target?.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="1 room studio apartment">1 room studio apartment</option>
                <option value="1 bedroom apartment or duplex">1 bedroom apartment or duplex</option>
                <option value="2 bedroom apartment or duplex">2 bedroom apartment or duplex</option>
                <option value="3 bedroom apartment or duplex">3 bedroom apartment or duplex</option>
                <option value="Selfcon">Selfcon</option>
                <option value="Single room">Single room</option>
                <option value="Duplex">Duplex</option>
                <option value="Hostel">Hostel</option>
                <option value="Shop">Shop</option>
                <option value="Store">Store</option>
                <option value="Land">Land</option>
                <option value="Vehicle">Vehicle</option>
              </select>
            ) : (
              <div className="flex items-center space-x-2 text-gray-900">
                <Home className="w-4 h-4 text-gray-400" />
                <span>{property?.type}</span>
              </div>
            )}
          </div>
          
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
            {isEditing ? (
              <textarea
                value={property?.description}
                onChange={(e) => handleInputChange('description', e?.target?.value)}
                rows={3}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            ) : (
              <p className="text-gray-700">{property?.description}</p>
            )}
          </div>
        </div>
      </div>
      {/* Property Specifications */}
      <div className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Specifications</h3>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {specs?.map((spec, index) => (
            <div key={index} className="flex items-center space-x-3 p-3 bg-gray-50 rounded-lg">
              <div className="flex-shrink-0 w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <spec.icon className="w-5 h-5 text-blue-600" />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-medium text-gray-500 truncate">{spec?.label}</p>
                {isEditing ? (
                  <input
                    type="text"
                    value={spec?.value}
                    onChange={(e) => handleInputChange(spec?.field, e?.target?.value)}
                    className="w-full mt-1 px-2 py-1 border border-gray-300 rounded text-sm focus:ring-1 focus:ring-blue-500 focus:border-transparent"
                  />
                ) : (
                  <p className="text-sm font-semibold text-gray-900 truncate">
                    {spec?.value}{spec?.suffix ? ` ${spec?.suffix}` : ''}
                  </p>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
      {/* Amenities & Features */}
      <div className="lg:col-span-2 bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Amenities & Features</h3>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {[
            'Well tiled', 'Running water', 'Electricity', 'Well water',
            'Painted', 'POP', 'Fenced', 'Security', 'Solar', 'Prepaid'
          ]?.map((amenity, index) => (
            <label key={index} className="flex items-center space-x-3">
              <input
                type="checkbox"
                defaultChecked={index < 6}
                disabled={!isEditing}
                className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
              />
              <span className="text-sm text-gray-700">{amenity}</span>
            </label>
          ))}
        </div>
      </div>
    </div>
  );
};

export default PropertySpecs;
