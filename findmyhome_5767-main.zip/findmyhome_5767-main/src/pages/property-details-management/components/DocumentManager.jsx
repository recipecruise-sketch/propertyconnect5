import React, { useState } from 'react';
import { Upload, FileText, Download, Eye, Trash2, Plus, Search, Calendar } from 'lucide-react';

const DocumentManager = ({ property }) => {
  const [activeCategory, setActiveCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [showUpload, setShowUpload] = useState(false);

  const documents = [
    {
      id: 1,
      name: 'Property Deed',
      category: 'legal',
      type: 'PDF',
      size: '2.4 MB',
      uploadDate: '2023-06-15',
      uploadedBy: 'Property Manager',
      description: 'Original property deed and title documents'
    },
    {
      id: 2,
      name: 'Insurance Policy 2024',
      category: 'insurance',
      type: 'PDF',
      size: '1.8 MB',
      uploadDate: '2023-12-01',
      uploadedBy: 'Property Manager',
      description: 'Current property insurance policy'
    },
    {
      id: 3,
      name: 'Annual Inspection Report',
      category: 'inspection',
      type: 'PDF',
      size: '3.2 MB',
      uploadDate: '2024-01-10',
      uploadedBy: 'Inspector',
      description: '2024 annual property inspection report'
    },
    {
      id: 4,
      name: 'HVAC Warranty',
      category: 'warranty',
      type: 'PDF',
      size: '1.1 MB',
      uploadDate: '2023-08-20',
      uploadedBy: 'Contractor',
      description: 'HVAC system warranty documentation'
    },
    {
      id: 5,
      name: 'Lease Agreement - Sarah Johnson',
      category: 'lease',
      type: 'PDF',
      size: '950 KB',
      uploadDate: '2024-01-15',
      uploadedBy: 'Property Manager',
      description: 'Signed lease agreement for Unit 204'
    },
    {
      id: 6,
      name: 'Property Photos 2024',
      category: 'photos',
      type: 'ZIP',
      size: '15.6 MB',
      uploadDate: '2024-01-05',
      uploadedBy: 'Property Manager',
      description: 'High-resolution property photos for marketing'
    }
  ];

  const categories = [
    { id: 'all', label: 'All Documents', count: documents?.length },
    { id: 'legal', label: 'Legal', count: documents?.filter(d => d?.category === 'legal')?.length },
    { id: 'lease', label: 'Leases', count: documents?.filter(d => d?.category === 'lease')?.length },
    { id: 'inspection', label: 'Inspections', count: documents?.filter(d => d?.category === 'inspection')?.length },
    { id: 'insurance', label: 'Insurance', count: documents?.filter(d => d?.category === 'insurance')?.length },
    { id: 'warranty', label: 'Warranties', count: documents?.filter(d => d?.category === 'warranty')?.length },
    { id: 'photos', label: 'Photos', count: documents?.filter(d => d?.category === 'photos')?.length }
  ];

  const filteredDocuments = documents?.filter(doc => {
    const matchesCategory = activeCategory === 'all' || doc?.category === activeCategory;
    const matchesSearch = doc?.name?.toLowerCase()?.includes(searchTerm?.toLowerCase()) ||
                         doc?.description?.toLowerCase()?.includes(searchTerm?.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const getFileIcon = (type) => {
    switch (type) {
      case 'PDF': return '📄';
      case 'ZIP': return '📦';
      case 'DOC': return '📝';
      case 'XLS': return '📊';
      default: return '📁';
    }
  };

  const getCategoryColor = (category) => {
    const colors = {
      legal: 'bg-red-100 text-red-800',
      lease: 'bg-blue-100 text-blue-800',
      inspection: 'bg-yellow-100 text-yellow-800',
      insurance: 'bg-green-100 text-green-800',
      warranty: 'bg-purple-100 text-purple-800',
      photos: 'bg-pink-100 text-pink-800'
    };
    return colors?.[category] || 'bg-gray-100 text-gray-800';
  };

  return (
    <div className="space-y-6">
      {/* Document Summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <FileText className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Total Files</p>
              <p className="text-xl font-bold text-gray-900">{documents?.length}</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <Download className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Storage Used</p>
              <p className="text-xl font-bold text-gray-900">25.1 MB</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
              <Calendar className="w-5 h-5 text-yellow-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Last Updated</p>
              <p className="text-sm font-bold text-gray-900">Jan 15, 2024</p>
            </div>
          </div>
        </div>
        
        <div className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
              <Eye className="w-5 h-5 text-purple-600" />
            </div>
            <div>
              <p className="text-sm text-gray-600">Categories</p>
              <p className="text-xl font-bold text-gray-900">{categories?.length - 1}</p>
            </div>
          </div>
        </div>
      </div>
      {/* Document Management */}
      <div className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900">Document Library</h3>
          <button
            onClick={() => setShowUpload(true)}
            className="flex items-center space-x-2 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>Upload Document</span>
          </button>
        </div>
        
        {/* Search Bar */}
        <div className="relative mb-4">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            placeholder="Search documents..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e?.target?.value)}
            className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
        
        {/* Category Filters */}
        <div className="flex flex-wrap gap-2 mb-6">
          {categories?.map((category) => (
            <button
              key={category?.id}
              onClick={() => setActiveCategory(category?.id)}
              className={`
                inline-flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors
                ${activeCategory === category?.id
                  ? 'bg-blue-100 text-blue-800 border border-blue-200' :'bg-gray-100 text-gray-600 hover:bg-gray-200 border border-transparent'
                }
              `}
            >
              <span>{category?.label}</span>
              <span className={`
                inline-flex items-center justify-center w-5 h-5 text-xs font-bold rounded-full
                ${activeCategory === category?.id ? 'bg-blue-200 text-blue-800' : 'bg-gray-200 text-gray-600'}
              `}>
                {category?.count}
              </span>
            </button>
          ))}
        </div>

        {/* Documents List */}
        <div className="space-y-3">
          {filteredDocuments?.map((doc) => (
            <div key={doc?.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-all">
              <div className="flex items-start justify-between">
                <div className="flex items-start space-x-3">
                  <div className="text-2xl">{getFileIcon(doc?.type)}</div>
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-1">
                      <h4 className="font-medium text-gray-900">{doc?.name}</h4>
                      <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getCategoryColor(doc?.category)}`}>
                        {doc?.category}
                      </span>
                    </div>
                    <p className="text-sm text-gray-600 mb-1">{doc?.description}</p>
                    <div className="flex items-center space-x-4 text-xs text-gray-500">
                      <span>Size: {doc?.size}</span>
                      <span>Uploaded: {new Date(doc.uploadDate)?.toLocaleDateString()}</span>
                      <span>By: {doc?.uploadedBy}</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <button className="p-2 text-blue-500 hover:bg-blue-50 rounded-lg transition-colors">
                    <Eye className="w-4 h-4" />
                  </button>
                  <button className="p-2 text-green-500 hover:bg-green-50 rounded-lg transition-colors">
                    <Download className="w-4 h-4" />
                  </button>
                  <button className="p-2 text-red-500 hover:bg-red-50 rounded-lg transition-colors">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredDocuments?.length === 0 && (
          <div className="text-center py-12">
            <FileText className="w-12 h-12 text-gray-300 mx-auto mb-3" />
            <p className="text-gray-500">No documents found</p>
          </div>
        )}
      </div>
      {/* Upload Modal */}
      {showUpload && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Upload Document</h3>
              <button
                onClick={() => setShowUpload(false)}
                className="p-1 text-gray-400 hover:text-gray-600 transition-colors"
              >
                <span className="sr-only">Close</span>
                ✕
              </button>
            </div>
            
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Document Name</label>
                <input
                  type="text"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter document name"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
                <select className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                  <option value="">Select category</option>
                  {categories?.slice(1)?.map(cat => (
                    <option key={cat?.id} value={cat?.id}>{cat?.label}</option>
                  ))}
                </select>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                <textarea
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Enter description"
                />
              </div>
              
              <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                <p className="text-sm text-gray-600 mb-2">Drag & drop files here, or click to browse</p>
                <input type="file" className="hidden" />
                <button className="text-blue-500 hover:text-blue-600 font-medium">
                  Choose Files
                </button>
              </div>
              
              <div className="flex items-center space-x-3">
                <button
                  onClick={() => setShowUpload(false)}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button className="flex-1 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors">
                  Upload
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DocumentManager;