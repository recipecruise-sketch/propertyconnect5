import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate, useLocation } from 'react-router-dom';
import { ArrowLeft, Camera, Edit3, Save, MapPin, Home, DollarSign, Upload, X } from 'lucide-react';
import ImageGallery from './components/ImageGallery';
import PropertySpecs from './components/PropertySpecs';
import FinancialDetails from './components/FinancialDetails';

const PropertyDetailsManagement = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [activeTab, setActiveTab] = useState('details');
  const [isEditing, setIsEditing] = useState(!location?.state?.propertyId);
  const [showImageUpload, setShowImageUpload] = useState(false);
  const [showVideoUpload, setShowVideoUpload] = useState(false);

  // Get property data from navigation state or use default
  const propertyData = location?.state?.propertyData || {
    name: 'New Property',
    address: '123 Main Street, City',
    occupancy: '0/0',
    revenue: '₦0/mo',
    image: 'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800&h=600&fit=crop&crop=center'
  };

  const [property, setProperty] = useState({
    state: 'Lagos',
    name: propertyData?.name,
    address: propertyData?.address,
    description: 'A beautiful residential property with modern amenities and excellent location.',
    type: '1 bedroom apartment or duplex',
    listingStatus: 'for_rent',
    yearBuilt: '2018',
    squareFootage: '1,200',
    bedrooms: '2',
    bathrooms: '2',
    parkingSpaces: '1',
    petPolicy: 'Allowed with deposit',
    purchasePrice: '₦350,000',
    currentRent: '₦1,850',
    marketValue: '₦380,000',
    monthlyExpenses: '₦450',
    occupancyRate: '85%',
    images: [
      'https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800&h=600&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=800&h=600&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1572120360610-d971b9d7767c?w=800&h=600&fit=crop&crop=center',
      'https://images.unsplash.com/photo-1560448204-e1a3ecba13e8?w=800&h=600&fit=crop&crop=center'
    ],
    videos: []
  });

  const tabs = [
    { id: 'details', label: 'Property Details', icon: Home },
    { id: 'financial', label: 'Financial', icon: DollarSign }
  ];

  const handleSave = () => {
    setIsEditing(false);
    // Here you would typically save to your backend
    console.log('Saving property:', property);
  };

  const handleImageUpload = (files) => {
    // Here you would typically upload to your storage service
    const newImages = Array.from(files)?.map(file => URL.createObjectURL(file));
    setProperty(prev => ({
      ...prev,
      images: [...prev?.images, ...newImages]
    }));
    setShowImageUpload(false);
  };

  const removeImage = (index) => {
    setProperty(prev => ({
      ...prev,
      images: prev?.images?.filter((_, i) => i !== index)
    }));
  };

  const handleVideoUpload = (files) => {
    const newVideos = Array.from(files)?.map(file => URL.createObjectURL(file));
    setProperty(prev => ({
      ...prev,
      videos: [...(prev?.videos || []), ...newVideos]
    }));
    setShowVideoUpload(false);
  };

  const removeVideo = (index) => {
    setProperty(prev => ({
      ...prev,
      videos: prev?.videos?.filter((_, i) => i !== index)
    }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      <Helmet>
        <title>{property?.name} - Property Management</title>
        <meta name="description" content="Manage property details, images, and information" />
      </Helmet>
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-sm border-b border-white/20 shadow-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/')}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <ArrowLeft className="w-5 h-5 text-gray-600" />
              </button>
              <div>
                <div className="flex items-center space-x-2">
                  <h1 className="text-xl font-bold text-gray-900">{property?.name}</h1>
                  <span className={`${property?.listingStatus === 'for_sale' ? 'bg-purple-100 text-purple-700' : 'bg-green-100 text-green-700'} px-2 py-0.5 rounded-full text-xs font-medium`}>{property?.listingStatus === 'for_sale' ? 'For Sale' : 'For Rent'}</span>
                </div>
                <p className="text-sm text-gray-600 flex items-center">
                  <MapPin className="w-4 h-4 mr-1" />
                  {property?.address}
                </p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <div className="flex rounded-lg border border-gray-300 overflow-hidden">
                <button
                  onClick={() => setProperty(prev => ({ ...prev, listingStatus: 'for_rent' }))}
                  className={`px-3 py-2 text-sm ${property?.listingStatus === 'for_rent' ? 'bg-green-600 text-white' : 'bg-white text-gray-700'} border-r border-gray-300 hover:bg-green-50`}
                >
                  For Rent
                </button>
                <button
                  onClick={() => setProperty(prev => ({ ...prev, listingStatus: 'for_sale' }))}
                  className={`px-3 py-2 text-sm ${property?.listingStatus === 'for_sale' ? 'bg-purple-600 text-white' : 'bg-white text-gray-700'} hover:bg-purple-50`}
                >
                  For Sale
                </button>
              </div>
              {!isEditing ? (
                <button
                  onClick={() => setIsEditing(true)}
                  className="flex items-center space-x-2 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
                >
                  <Edit3 className="w-4 h-4" />
                  <span>Edit Property</span>
                </button>
              ) : null}
            </div>
          </div>
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        
        {/* Image Gallery Section */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Property Images</h2>
            {isEditing && (
              <button
                onClick={() => setShowImageUpload(true)}
                className="flex items-center space-x-2 px-3 py-2 text-sm text-blue-600 hover:text-blue-700 transition-colors"
              >
                <Camera className="w-4 h-4" />
                <span>Add Photos</span>
              </button>
            )}
          </div>
          
          <ImageGallery 
            images={property?.images} 
            isEditing={isEditing}
            onRemoveImage={removeImage}
          />
        </div>

        {/* Property Videos */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Property Videos</h2>
            {isEditing && (
              <button
                onClick={() => setShowVideoUpload(true)}
                className="flex items-center space-x-2 px-3 py-2 text-sm text-blue-600 hover:text-blue-700 transition-colors"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14v-4z" fill="currentColor"/><rect x="3" y="6" width="12" height="12" rx="2" fill="currentColor" opacity="0.2"/></svg>
                <span>Add Videos</span>
              </button>
            )}
          </div>
          {property?.videos?.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {property?.videos?.map((src, idx) => (
                <div key={idx} className="relative group rounded-xl overflow-hidden border border-gray-200 bg-black">
                  <video src={src} controls className="w-full h-48 object-cover" />
                  {isEditing && (
                    <button
                      onClick={() => removeVideo(idx)}
                      className="absolute top-2 right-2 bg-white/90 text-gray-800 px-2 py-1 text-xs rounded shadow hover:bg-white"
                    >
                      Remove
                    </button>
                  )}
                </div>
              ))}
            </div>
          ) : (
            <p className="text-sm text-gray-500">No videos added yet.</p>
          )}
        </div>

        {/* Navigation Tabs */}
        <div className="mb-6">
          <div className="border-b border-gray-200">
            <nav className="-mb-px flex space-x-8">
              {tabs?.map((tab) => (
                <button
                  key={tab?.id}
                  onClick={() => setActiveTab(tab?.id)}
                  className={`
                    flex items-center space-x-2 py-2 px-1 border-b-2 font-medium text-sm transition-colors
                    ${activeTab === tab?.id
                      ? 'border-blue-500 text-blue-600' :'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    }
                  `}
                >
                  <tab.icon className="w-4 h-4" />
                  <span>{tab?.label}</span>
                </button>
              ))}
            </nav>
          </div>
        </div>

        {/* Tab Content */}
        <div className="space-y-6">
          {activeTab === 'details' && (
            <PropertySpecs 
              property={property} 
              setProperty={setProperty}
              isEditing={isEditing} 
            />
          )}
          
          {activeTab === 'financial' && (
            <FinancialDetails 
              property={property} 
              setProperty={setProperty}
              isEditing={isEditing} 
            />
          )}
          
        </div>
      </div>

      {/* Bottom Actions */}
      {isEditing && (
        <div className="border-t border-white/20 bg-white/70">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex items-center justify-end space-x-3">
            <button
              onClick={() => setIsEditing(false)}
              className="px-4 py-2 text-sm text-gray-600 hover:text-gray-900 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleSave}
              className="flex items-center space-x-2 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors"
            >
              <Save className="w-4 h-4" />
              <span>Save Changes</span>
            </button>
          </div>
        </div>
      )}

      {/* Image Upload Modal */}
      {showImageUpload && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Upload Images</h3>
              <button
                onClick={() => setShowImageUpload(false)}
                className="p-1 text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
              <Upload className="w-12 h-12 text-gray-400 mx-auto mb-3" />
              <p className="text-gray-600 mb-2">Drag & drop images here, or</p>
              <input
                type="file"
                multiple
                accept="image/*"
                onChange={(e) => handleImageUpload(e?.target?.files)}
                className="hidden"
                id="image-upload"
              />
              <label
                htmlFor="image-upload"
                className="inline-flex items-center px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 cursor-pointer transition-colors"
              >
                Browse Files
              </label>
            </div>
          </div>
        </div>
      )}

      {/* Video Upload Modal */}
      {showVideoUpload && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl p-6 w-full max-w-md">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Upload Videos</h3>
              <button onClick={() => setShowVideoUpload(false)} className="p-1 text-gray-400 hover:text-gray-600 transition-colors">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
              <p className="text-gray-600 mb-2">Drag & drop videos here, or</p>
              <input type="file" multiple accept="video/*" onChange={(e) => handleVideoUpload(e?.target?.files)} className="hidden" id="video-upload" />
              <label htmlFor="video-upload" className="inline-flex items-center px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 cursor-pointer">
                Browse Files
              </label>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default PropertyDetailsManagement;
