import React from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, User, Shield, Bell, LifeBuoy } from 'lucide-react';

const ProfileSettingsPage = () => {
  const navigate = useNavigate();
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      <Helmet>
        <title>Profile Settings - Findmyhome</title>
        <meta name="description" content="Manage your settings" />
      </Helmet>

      <div className="bg-white/80 backdrop-blur-sm border-b border-white/20 shadow-sm sticky top-0 z-40">
        <div className="max-w-screen-md w-full mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-lg transition-colors" aria-label="Back">
              <ArrowLeft className="w-5 h-5 text-gray-600" />
            </button>
            <h1 className="text-xl font-bold text-gray-900">Profile Settings</h1>
          </div>
          <button onClick={() => navigate('/chat', { state: { support: true } })} className="px-3 py-1.5 text-sm bg-blue-500 text-white rounded-lg hover:bg-blue-600 flex items-center space-x-2">
            <LifeBuoy className="w-4 h-4" />
            <span>Customer Service</span>
          </button>
        </div>
      </div>

      <main className="max-w-screen-md w-full mx-auto px-4 py-4 space-y-4">
        <section className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-4 shadow-sm">
          <h2 className="text-sm font-semibold text-gray-900 mb-3">Account</h2>
          <div className="space-y-2">
            <label className="flex items-center justify-between">
              <span className="text-sm">Display Name</span>
              <input className="border border-gray-300 rounded px-2 py-1 text-sm" defaultValue="John Doe" />
            </label>
            <label className="flex items-center justify-between">
              <span className="text-sm">Email Alerts</span>
              <input type="checkbox" defaultChecked className="w-4 h-4" />
            </label>
          </div>
        </section>
        <section className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-4 shadow-sm">
          <h2 className="text-sm font-semibold text-gray-900 mb-3">Privacy</h2>
          <div className="space-y-2">
            <label className="flex items-center justify-between">
              <span className="text-sm">Two-factor Authentication</span>
              <input type="checkbox" className="w-4 h-4" />
            </label>
            <label className="flex items-center justify-between">
              <span className="text-sm">Show profile publicly</span>
              <input type="checkbox" defaultChecked className="w-4 h-4" />
            </label>
          </div>
        </section>
      </main>
    </div>
  );
};

export default ProfileSettingsPage;
