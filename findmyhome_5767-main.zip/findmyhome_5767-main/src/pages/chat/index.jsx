import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Helmet } from 'react-helmet';
import { useLocation, useNavigate } from 'react-router-dom';
import { ArrowLeft, Send, User, Shield } from 'lucide-react';

const ChatPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const tenant = location?.state?.tenant || null;
  const isSupport = location?.state?.support === true;
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState(() => {
    const intro = [
      { id: 'sys-1', author: 'system', text: 'This is a secure conversation. Please avoid sharing sensitive information.', time: new Date(), avatar: null },
    ];
    if (isSupport) {
      return [
        ...intro,
        { id: 's-1', author: 'tenant', text: 'Hello, this is Customer Service. How can we help you today?', time: new Date(Date.now() - 1000 * 60 * 5), avatar: null },
      ];
    }
    if (!tenant) return intro;
    return [
      ...intro,
      { id: 't-1', author: 'tenant', text: `Hi, I\'m ${tenant.name}. I need some help.`, time: new Date(Date.now() - 1000 * 60 * 30), avatar: tenant?.avatar || null },
      { id: 'me-1', author: 'me', text: 'Hello! How can I assist you today?', time: new Date(Date.now() - 1000 * 60 * 29), avatar: null },
    ];
  });

  const chatEndRef = useRef(null);
  const title = useMemo(() => tenant ? `Chat with ${tenant.name}` : (isSupport ? 'Customer Service' : 'Messages'), [tenant, isSupport]);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages.length]);

  const handleSend = () => {
    const trimmed = message.trim();
    if (!trimmed) return;
    const newMsg = { id: `me-${Date.now()}`, author: 'me', text: trimmed, time: new Date(), avatar: null };
    setMessages(prev => [...prev, newMsg]);
    setMessage('');
  };

  const bubble = (m) => {
    const isMe = m.author === 'me';
    const isSystem = m.author === 'system';
    return (
      <div key={m.id} className={`flex items-end ${isMe ? 'justify-end' : 'justify-start'} mb-3`}>
        {!isMe && !isSystem && (
          <img src={m.avatar || 'https://api.dicebear.com/7.x/initials/svg?seed=T'} alt="avatar" className="w-8 h-8 rounded-full mr-2" />
        )}
        {isSystem ? (
          <div className="max-w-[80%] bg-yellow-50 border border-yellow-200 text-yellow-800 text-xs px-3 py-2 rounded-lg">
            {m.text}
          </div>
        ) : (
          <div className={`max-w-[80%] px-4 py-2 rounded-2xl shadow-sm ${isMe ? 'bg-blue-600 text-white rounded-br-sm' : 'bg-gray-100 text-gray-900 rounded-bl-sm'}`}>
            <p className="whitespace-pre-wrap break-words">{m.text}</p>
            <span className={`block mt-1 text-[10px] ${isMe ? 'text-white/80' : 'text-gray-500'}`}>{m.time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
          </div>
        )}
        {isMe && (
          <div className="ml-2 w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center">
            <User className="w-4 h-4 text-blue-600" />
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      <Helmet>
        <title>{title} - Findmyhome</title>
        <meta name="description" content="Tenant messaging and chat" />
      </Helmet>

      <div className="bg-white/80 backdrop-blur-sm border-b border-white/20 shadow-sm sticky top-0 z-40">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button onClick={() => navigate(-1)} className="p-2 hover:bg-gray-100 rounded-lg transition-colors" aria-label="Back">
                <ArrowLeft className="w-5 h-5 text-gray-600" />
              </button>
              <div>
                <h1 className="text-xl font-bold text-gray-900">{title}</h1>
                {tenant && (<p className="text-xs text-gray-500">{tenant.property}</p>)}
              </div>
            </div>
            <div className="hidden md:flex items-center text-xs text-gray-500">
              <Shield className="w-4 h-4 mr-1" /> End-to-end encrypted mock chat
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl h-[70vh] flex flex-col">
          <div className="flex-1 overflow-y-auto p-4">
            {messages.map(bubble)}
            <div ref={chatEndRef} />
          </div>
          <div className="border-t border-gray-200 p-3">
            <div className="flex items-center space-x-2">
              <input
                type="text"
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') handleSend(); }}
                placeholder="Type a message..."
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                aria-label="Message input"
              />
              <button onClick={handleSend} className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors flex items-center space-x-2">
                <Send className="w-4 h-4" />
                <span>Send</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatPage;
