import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Search, Filter, Bell, User, Mail, Calendar, DollarSign, AlertCircle, CheckCircle2, Clock } from 'lucide-react';
import TenantCard from './components/TenantCard';
import LeaseTimeline from './components/LeaseTimeline';
import CommunicationCenter from './components/CommunicationCenter';
import TenantFilters from './components/TenantFilters';

const TenantManagementDashboard = () => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [activeFilter, setActiveFilter] = useState('all');
  const [showFilters, setShowFilters] = useState(false);


  // Mock tenant data
  const tenantsData = [
    {
      id: 1,
      name: 'Sarah Johnson',
      email: 'sarah.johnson@email.com',
      phone: '+1 (555) 123-4567',
      property: 'Sunset Apartments - Unit 204',
      leaseStart: '2024-01-15',
      leaseEnd: '2024-12-15',
      rent: '₦1,850',
      status: 'active',
      paymentStatus: 'current',
      lastContact: '2024-01-15',
      avatar: 'https://images.unsplash.com/photo-1494790108755-2616b332c5de?w=150&h=150&fit=crop&crop=face'
    },
    {
      id: 2,
      name: 'Michael Chen',
      email: 'michael.chen@email.com',
      phone: '+1 (555) 987-6543',
      property: 'Garden View Complex - Unit 102',
      leaseStart: '2023-08-01',
      leaseEnd: '2024-07-31',
      rent: '₦1,650',
      status: 'renewal_due',
      paymentStatus: 'late',
      lastContact: '2024-01-10',
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face'
    },
    {
      id: 3,
      name: 'Emily Rodriguez',
      email: 'emily.rodriguez@email.com',
      phone: '+1 (555) 456-7890',
      property: 'Riverside Condos - Unit 301',
      leaseStart: '2023-11-01',
      leaseEnd: '2024-10-31',
      rent: '₦1,950',
      status: 'active',
      paymentStatus: 'current',
      lastContact: '2024-01-12',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face'
    }
  ];

  const filteredTenants = tenantsData?.filter(tenant => {
    const matchesSearch = tenant?.name?.toLowerCase()?.includes(searchTerm?.toLowerCase()) ||
                         tenant?.property?.toLowerCase()?.includes(searchTerm?.toLowerCase());
    const matchesFilter = activeFilter === 'all' || 
                         tenant?.status === activeFilter || 
                         tenant?.paymentStatus === activeFilter;
    return matchesSearch && matchesFilter;
  });

  const getStatusColor = (status) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'renewal_due': return 'bg-yellow-100 text-yellow-800';
      case 'late': return 'bg-red-100 text-red-800';
      case 'current': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      <Helmet>
        <title>Tenant Management - Findmyhome</title>
        <meta name="description" content="Manage all your tenants and leases" />
      </Helmet>
      {/* Header */}
      <div className="bg-white/80 backdrop-blur-sm border-b border-white/20 shadow-sm sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button
                onClick={() => navigate('/')}
                className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              >
                <ArrowLeft className="w-5 h-5 text-gray-600" />
              </button>
              <div>
                <h1 className="text-xl font-bold text-gray-900">Tenant Management</h1>
                <p className="text-sm text-gray-600">Manage tenants, leases, and communications</p>
              </div>
            </div>
            <div className="flex items-center space-x-2">
              <button className="relative p-2 text-gray-400 hover:text-gray-600 transition-colors">
                <Bell className="w-5 h-5" />
                <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full"></span>
              </button>
            </div>
          </div>
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid grid-cols-1 lg:grid-cols-16 gap-6">
          
          {/* Main Content - 10 columns */}
          <div className="lg:col-span-10 space-y-6">
            
            {/* Tenant Overview Cards */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-4">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <User className="w-5 h-5 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Total Tenants</p>
                    <p className="text-xl font-bold text-gray-900">{tenantsData?.length}</p>
                  </div>
                </div>
              </div>
              
              <div className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-4">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-green-100 rounded-lg">
                    <CheckCircle2 className="w-5 h-5 text-green-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Active Leases</p>
                    <p className="text-xl font-bold text-gray-900">
                      {tenantsData?.filter(t => t?.status === 'active')?.length}
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-4">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-yellow-100 rounded-lg">
                    <Clock className="w-5 h-5 text-yellow-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Renewals Due</p>
                    <p className="text-xl font-bold text-gray-900">
                      {tenantsData?.filter(t => t?.status === 'renewal_due')?.length}
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-4">
                <div className="flex items-center space-x-3">
                  <div className="p-2 bg-red-100 rounded-lg">
                    <AlertCircle className="w-5 h-5 text-red-600" />
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Late Payments</p>
                    <p className="text-xl font-bold text-gray-900">
                      {tenantsData?.filter(t => t?.paymentStatus === 'late')?.length}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Search and Filter Bar */}
            <div className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-4">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-semibold text-gray-900">Tenant Directory</h2>
                <button
                  onClick={() => setShowFilters(!showFilters)}
                  className="flex items-center space-x-2 px-3 py-2 text-sm text-gray-600 hover:text-gray-900 hover:bg-gray-100 rounded-lg transition-colors"
                >
                  <Filter className="w-4 h-4" />
                  <span>Filter</span>
                </button>
              </div>
              
              <div className="relative mb-4">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search tenants or properties..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e?.target?.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
              
              {showFilters && (
                <TenantFilters 
                  activeFilter={activeFilter}
                  setActiveFilter={setActiveFilter}
                />
              )}
            </div>

            {/* Tenant Cards */}
            <div className="space-y-4">
              {filteredTenants?.map((tenant) => (
                <TenantCard
                  key={tenant?.id}
                  tenant={tenant}
                  getStatusColor={getStatusColor}
                  onMessage={(t)=>navigate('/chat', { state: { tenant: t } })}
                />
              ))}
            </div>

            {/* Lease Timeline */}
            <LeaseTimeline tenants={tenantsData} />
          </div>

          {/* Right Sidebar - 6 columns */}
          <div className="lg:col-span-6 space-y-6">
            <CommunicationCenter tenants={tenantsData} />
            
            {/* Quick Actions */}
            <div className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Actions</h3>
              <div className="space-y-3">
                <button className="w-full flex items-center space-x-3 p-3 text-left hover:bg-gray-50 rounded-lg transition-colors">
                  <Mail className="w-5 h-5 text-blue-500" />
                  <span className="text-sm font-medium text-gray-900">Send Bulk Notice</span>
                </button>
                <button className="w-full flex items-center space-x-3 p-3 text-left hover:bg-gray-50 rounded-lg transition-colors">
                  <Calendar className="w-5 h-5 text-green-500" />
                  <span className="text-sm font-medium text-gray-900">Schedule Inspection</span>
                </button>
                <button className="w-full flex items-center space-x-3 p-3 text-left hover:bg-gray-50 rounded-lg transition-colors">
                  <DollarSign className="w-5 h-5 text-yellow-500" />
                  <span className="text-sm font-medium text-gray-900">Payment Reminder</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TenantManagementDashboard;
