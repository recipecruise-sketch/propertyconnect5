import React from 'react';

const TenantFilters = ({ activeFilter, setActiveFilter }) => {
  const filters = [
    { id: 'all', label: 'All Tenants', count: 3 },
    { id: 'active', label: 'Active Leases', count: 2 },
    { id: 'renewal_due', label: 'Renewal Due', count: 1 },
    { id: 'late', label: 'Late Payments', count: 1 },
    { id: 'current', label: 'Current Payments', count: 2 }
  ];

  return (
    <div className="flex flex-wrap gap-2">
      {filters?.map((filter) => (
        <button
          key={filter?.id}
          onClick={() => setActiveFilter(filter?.id)}
          className={`
            inline-flex items-center space-x-2 px-3 py-2 rounded-lg text-sm font-medium transition-colors
            ${activeFilter === filter?.id
              ? 'bg-blue-100 text-blue-800 border border-blue-200' :'bg-gray-100 text-gray-600 hover:bg-gray-200 border border-transparent'
            }
          `}
        >
          <span>{filter?.label}</span>
          <span className={`
            inline-flex items-center justify-center w-5 h-5 text-xs font-bold rounded-full
            ${activeFilter === filter?.id ? 'bg-blue-200 text-blue-800' : 'bg-gray-200 text-gray-600'}
          `}>
            {filter?.count}
          </span>
        </button>
      ))}
    </div>
  );
};

export default TenantFilters;