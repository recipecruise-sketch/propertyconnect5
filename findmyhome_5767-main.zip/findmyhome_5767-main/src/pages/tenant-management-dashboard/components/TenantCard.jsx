import React from 'react';
import { Mail, Phone, MapPin, Calendar, DollarSign, MoreVertical, MessageCircle } from 'lucide-react';

const TenantCard = ({ tenant, getStatusColor, onMessage }) => {
  return (
    <div className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-4 hover:shadow-md transition-all">
      <div className="flex items-start space-x-4">
        {/* Avatar */}
        <div className="w-12 h-12 rounded-full overflow-hidden flex-shrink-0">
          <img
            src={tenant?.avatar}
            alt={tenant?.name}
            className="w-full h-full object-cover"
            onError={(e) => {
              e.target.style.display = 'none';
              e.target.parentElement.innerHTML = `
                <div class="w-full h-full bg-gradient-to-br from-blue-100 to-blue-200 flex items-center justify-center">
                  <svg class="w-6 h-6 text-blue-400" fill="currentColor" viewBox="0 0 20 20">
                    <path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd" />
                  </svg>
                </div>
              `;
            }}
          />
        </div>

        {/* Tenant Info */}
        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between mb-2">
            <div>
              <h3 className="font-semibold text-gray-900 truncate">{tenant?.name}</h3>
              <div className="flex items-center space-x-2 mt-1">
                <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(tenant?.status)}`}>
                  {tenant?.status?.replace('_', ' ')}
                </span>
                <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(tenant?.paymentStatus)}`}>
                  {tenant?.paymentStatus}
                </span>
              </div>
            </div>
            <button className="p-1 text-gray-400 hover:text-gray-600 transition-colors">
              <MoreVertical className="w-4 h-4" />
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
            <div className="flex items-center space-x-2 text-gray-600">
              <MapPin className="w-4 h-4 flex-shrink-0" />
              <span className="truncate">{tenant?.property}</span>
            </div>
            <div className="flex items-center space-x-2 text-gray-600">
              <DollarSign className="w-4 h-4 flex-shrink-0" />
              <span>{tenant?.rent}/month</span>
            </div>
            <div className="flex items-center space-x-2 text-gray-600">
              <Mail className="w-4 h-4 flex-shrink-0" />
              <span className="truncate">{tenant?.email}</span>
            </div>
            <div className="flex items-center space-x-2 text-gray-600">
              <Phone className="w-4 h-4 flex-shrink-0" />
              <span>{tenant?.phone}</span>
            </div>
          </div>

          <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-200">
            <div className="flex items-center space-x-2 text-sm text-gray-500">
              <Calendar className="w-4 h-4" />
              <span>Lease: {new Date(tenant.leaseStart)?.toLocaleDateString()} - {new Date(tenant.leaseEnd)?.toLocaleDateString()}</span>
            </div>
            <div className="flex items-center space-x-2">
              <button onClick={()=>onMessage?.(tenant)} className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                <MessageCircle className="w-4 h-4" />
              </button>
              <button className="p-2 text-blue-500 hover:bg-blue-50 rounded-lg transition-colors">
                <Mail className="w-4 h-4" />
              </button>
              <button className="p-2 text-green-500 hover:bg-green-50 rounded-lg transition-colors">
                <Phone className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TenantCard;
