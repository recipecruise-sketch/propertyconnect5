import React from 'react';
import { Calendar, AlertTriangle, CheckCircle2 } from 'lucide-react';

const LeaseTimeline = ({ tenants }) => {
  const getTimelineEvents = () => {
    const events = [];
    tenants?.forEach(tenant => {
      const leaseStart = new Date(tenant.leaseStart);
      const leaseEnd = new Date(tenant.leaseEnd);
      const today = new Date();
      
      // Check if lease is ending soon (within 60 days)
      const daysUntilEnd = Math.ceil((leaseEnd - today) / (1000 * 60 * 60 * 24));
      
      if (daysUntilEnd > 0 && daysUntilEnd <= 60) {
        events?.push({
          type: 'renewal',
          tenant: tenant?.name,
          property: tenant?.property,
          date: leaseEnd,
          daysUntil: daysUntilEnd
        });
      }
      
      // Check if lease started recently (within 30 days)
      const daysSinceStart = Math.ceil((today - leaseStart) / (1000 * 60 * 60 * 24));
      if (daysSinceStart >= 0 && daysSinceStart <= 30) {
        events?.push({
          type: 'new',
          tenant: tenant?.name,
          property: tenant?.property,
          date: leaseStart,
          daysSince: daysSinceStart
        });
      }
    });
    
    return events?.sort((a, b) => a?.date - b?.date);
  };

  const events = getTimelineEvents();

  return (
    <div className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-6">
      <div className="flex items-center space-x-2 mb-4">
        <Calendar className="w-5 h-5 text-blue-500" />
        <h3 className="text-lg font-semibold text-gray-900">Lease Timeline</h3>
      </div>
      {events?.length > 0 ? (
        <div className="space-y-4">
          {events?.map((event, index) => (
            <div key={index} className="flex items-start space-x-3">
              <div className={`flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center ${
                event?.type === 'renewal' ? 'bg-yellow-100' : 'bg-green-100'
              }`}>
                {event?.type === 'renewal' ? (
                  <AlertTriangle className="w-4 h-4 text-yellow-600" />
                ) : (
                  <CheckCircle2 className="w-4 h-4 text-green-600" />
                )}
              </div>
              <div className="flex-1">
                <div className="flex items-center justify-between">
                  <p className="font-medium text-gray-900">{event?.tenant}</p>
                  <span className="text-sm text-gray-500">
                    {event?.date?.toLocaleDateString()}
                  </span>
                </div>
                <p className="text-sm text-gray-600">{event?.property}</p>
                <p className="text-xs text-gray-500 mt-1">
                  {event?.type === 'renewal' 
                    ? `Lease expires in ${event?.daysUntil} days`
                    : `New tenant (${event?.daysSince} days ago)`
                  }
                </p>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-center py-8">
          <Calendar className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-500">No upcoming lease events</p>
        </div>
      )}
    </div>
  );
};

export default LeaseTimeline;