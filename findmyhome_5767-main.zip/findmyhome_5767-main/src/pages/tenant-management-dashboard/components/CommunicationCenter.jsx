import React from 'react';
import { MessageCircle, Mail, Phone, Clock } from 'lucide-react';

const CommunicationCenter = ({ tenants }) => {
  // Mock communication data
  const recentCommunications = [
    {
      id: 1,
      tenant: 'Sarah Johnson',
      type: 'email',
      subject: 'Maintenance Request - Kitchen Faucet',
      timestamp: '2 hours ago',
      status: 'unread'
    },
    {
      id: 2,
      tenant: 'Michael Chen',
      type: 'phone',
      subject: 'Lease Renewal Discussion',
      timestamp: '1 day ago',
      status: 'completed'
    },
    {
      id: 3,
      tenant: 'Emily Rodriguez',
      type: 'message',
      subject: 'Parking Space Question',
      timestamp: '2 days ago',
      status: 'replied'
    }
  ];

  const getIconForType = (type) => {
    switch (type) {
      case 'email': return <Mail className="w-4 h-4" />;
      case 'phone': return <Phone className="w-4 h-4" />;
      case 'message': return <MessageCircle className="w-4 h-4" />;
      default: return <MessageCircle className="w-4 h-4" />;
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'unread': return 'bg-red-100 text-red-800';
      case 'completed': return 'bg-green-100 text-green-800';
      case 'replied': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="bg-white/70 backdrop-blur-sm border border-white/20 rounded-2xl p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900">Communication Center</h3>
        <button className="text-sm text-blue-500 hover:text-blue-600 font-medium transition-colors">
          View All
        </button>
      </div>
      <div className="space-y-4">
        {recentCommunications?.map((comm) => (
          <div key={comm?.id} className="flex items-start space-x-3 p-3 hover:bg-gray-50 rounded-lg transition-colors cursor-pointer">
            <div className="flex-shrink-0 w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center text-gray-600">
              {getIconForType(comm?.type)}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between mb-1">
                <p className="font-medium text-gray-900 text-sm truncate">{comm?.tenant}</p>
                <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(comm?.status)}`}>
                  {comm?.status}
                </span>
              </div>
              <p className="text-sm text-gray-600 truncate">{comm?.subject}</p>
              <div className="flex items-center space-x-1 mt-1">
                <Clock className="w-3 h-3 text-gray-400" />
                <span className="text-xs text-gray-500">{comm?.timestamp}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
      {/* Automated Reminders Section */}
      <div className="mt-6 pt-4 border-t border-gray-200">
        <h4 className="font-medium text-gray-900 mb-3">Automated Reminders</h4>
        <div className="space-y-2">
          <div className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
            <span className="text-sm text-gray-700">Rent Due Reminders</span>
            <div className="flex items-center space-x-2">
              <span className="text-xs text-green-600 font-medium">Active</span>
              <button className="text-xs text-blue-500 hover:text-blue-600 transition-colors">Edit</button>
            </div>
          </div>
          <div className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
            <span className="text-sm text-gray-700">Lease Renewal Notices</span>
            <div className="flex items-center space-x-2">
              <span className="text-xs text-green-600 font-medium">Active</span>
              <button className="text-xs text-blue-500 hover:text-blue-600 transition-colors">Edit</button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CommunicationCenter;