import React, { useState, createContext, useContext } from 'react';
import { useLocation } from 'react-router-dom';
import Button from './Button';
import Select from './Select';
import { Checkbox } from './Checkbox';

import { useFilters } from './GlobalFilterBar';

// Export Context
const ExportContext = createContext();

export const ExportProvider = ({ children }) => {
  const [exportHistory, setExportHistory] = useState([]);
  
  const addExport = (exportData) => {
    const newExport = {
      id: Date.now(),
      timestamp: new Date(),
      ...exportData
    };
    setExportHistory(prev => [newExport, ...prev?.slice(0, 9)]); // Keep last 10 exports
  };

  return (
    <ExportContext.Provider value={{ exportHistory, addExport }}>
      {children}
    </ExportContext.Provider>
  );
};

export const useExport = () => {
  const context = useContext(ExportContext);
  if (!context) {
    throw new Error('useExport must be used within an ExportProvider');
  }
  return context;
};

const ExportControlPanel = ({ position = 'floating' }) => {
  const location = useLocation();
  const { filters } = useFilters();
  const { addExport } = useExport();
  const [isOpen, setIsOpen] = useState(false);
  const [exportConfig, setExportConfig] = useState({
    format: 'xlsx',
    includeCharts: true,
    includeFilters: true,
    dateRange: 'current',
    sections: []
  });

  const getScreenContext = () => {
    const path = location?.pathname;
    switch (path) {
      case '/portfolio-overview-dashboard':
        return {
          title: 'Portfolio Overview',
          sections: [
            { id: 'summary', label: 'Portfolio Summary', default: true },
            { id: 'performance', label: 'Performance Metrics', default: true },
            { id: 'properties', label: 'Property List', default: false },
            { id: 'trends', label: 'Trend Analysis', default: false }
          ]
        };
      case '/financial-analytics-dashboard':
        return {
          title: 'Financial Analytics',
          sections: [
            { id: 'revenue', label: 'Revenue Analysis', default: true },
            { id: 'expenses', label: 'Expense Breakdown', default: true },
            { id: 'cashflow', label: 'Cash Flow Statement', default: false },
            { id: 'roi', label: 'ROI Analysis', default: false }
          ]
        };
      case '/operations-management-dashboard':
        return {
          title: 'Operations Management',
          sections: [
            { id: 'occupancy', label: 'Occupancy Rates', default: true },
            { id: 'maintenance', label: 'Maintenance Reports', default: true },
            { id: 'tenant', label: 'Tenant Information', default: false },
            { id: 'workflows', label: 'Workflow Status', default: false }
          ]
        };
      case '/market-intelligence-dashboard':
        return {
          title: 'Market Intelligence',
          sections: [
            { id: 'market-trends', label: 'Market Trends', default: true },
            { id: 'competitive', label: 'Competitive Analysis', default: true },
            { id: 'pricing', label: 'Pricing Recommendations', default: false },
            { id: 'forecasts', label: 'Market Forecasts', default: false }
          ]
        };
      default:
        return {
          title: 'Dashboard Data',
          sections: [
            { id: 'all', label: 'All Available Data', default: true }
          ]
        };
    }
  };

  const screenContext = getScreenContext();

  const formatOptions = [
    { value: 'xlsx', label: 'Excel (.xlsx)' },
    { value: 'csv', label: 'CSV (.csv)' },
    { value: 'pdf', label: 'PDF Report (.pdf)' },
    { value: 'json', label: 'JSON Data (.json)' }
  ];

  const dateRangeOptions = [
    { value: 'current', label: 'Current View' },
    { value: 'last30', label: 'Last 30 Days' },
    { value: 'last90', label: 'Last 90 Days' },
    { value: 'ytd', label: 'Year to Date' },
    { value: 'custom', label: 'Custom Range' }
  ];

  const handleSectionToggle = (sectionId, checked) => {
    setExportConfig(prev => ({
      ...prev,
      sections: checked 
        ? [...prev?.sections, sectionId]
        : prev?.sections?.filter(id => id !== sectionId)
    }));
  };

  const handleExport = () => {
    const exportData = {
      screen: screenContext?.title,
      format: exportConfig?.format,
      sections: exportConfig?.sections?.length > 0 ? exportConfig?.sections : screenContext?.sections?.filter(s => s?.default)?.map(s => s?.id),
      filters: exportConfig?.includeFilters ? filters : null,
      includeCharts: exportConfig?.includeCharts,
      dateRange: exportConfig?.dateRange
    };

    // Simulate export process
    addExport(exportData);
    setIsOpen(false);
    
    // In real implementation, this would trigger the actual export
    console.log('Exporting:', exportData);
  };

  if (position === 'floating') {
    return (
      <>
        {/* Floating Action Button */}
        <div className="fixed bottom-6 right-6 z-[1000]">
          <Button
            variant="primary"
            size="lg"
            iconName="Download"
            onClick={() => setIsOpen(true)}
            className="rounded-full shadow-elevation-3 hover:shadow-elevation-3"
          >
            Export
          </Button>
        </div>
        {/* Export Panel Overlay */}
        {isOpen && (
          <div className="fixed inset-0 z-[2000] bg-black/50 flex items-center justify-center p-4">
            <div className="bg-white rounded-lg shadow-elevation-3 w-full max-w-md max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-lg font-semibold text-foreground">
                    Export {screenContext?.title}
                  </h3>
                  <Button
                    variant="ghost"
                    size="sm"
                    iconName="X"
                    onClick={() => setIsOpen(false)}
                  />
                </div>

                <div className="space-y-6">
                  <Select
                    label="Export Format"
                    options={formatOptions}
                    value={exportConfig?.format}
                    onChange={(value) => setExportConfig(prev => ({ ...prev, format: value }))}
                  />

                  <Select
                    label="Date Range"
                    options={dateRangeOptions}
                    value={exportConfig?.dateRange}
                    onChange={(value) => setExportConfig(prev => ({ ...prev, dateRange: value }))}
                  />

                  <div>
                    <label className="text-sm font-medium text-foreground mb-3 block">
                      Include Sections
                    </label>
                    <div className="space-y-2">
                      {screenContext?.sections?.map((section) => (
                        <Checkbox
                          key={section?.id}
                          label={section?.label}
                          checked={exportConfig?.sections?.includes(section?.id) || (exportConfig?.sections?.length === 0 && section?.default)}
                          onChange={(e) => handleSectionToggle(section?.id, e?.target?.checked)}
                        />
                      ))}
                    </div>
                  </div>

                  <div className="space-y-3">
                    <Checkbox
                      label="Include Charts and Visualizations"
                      checked={exportConfig?.includeCharts}
                      onChange={(e) => setExportConfig(prev => ({ ...prev, includeCharts: e?.target?.checked }))}
                    />
                    
                    <Checkbox
                      label="Include Applied Filters"
                      checked={exportConfig?.includeFilters}
                      onChange={(e) => setExportConfig(prev => ({ ...prev, includeFilters: e?.target?.checked }))}
                    />
                  </div>

                  <div className="flex space-x-3 pt-4">
                    <Button
                      variant="outline"
                      fullWidth
                      onClick={() => setIsOpen(false)}
                    >
                      Cancel
                    </Button>
                    <Button
                      variant="primary"
                      fullWidth
                      iconName="Download"
                      iconPosition="left"
                      onClick={handleExport}
                    >
                      Export Data
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </>
    );
  }

  // Inline export controls
  return (
    <div className="flex items-center space-x-3">
      <Select
        options={formatOptions}
        value={exportConfig?.format}
        onChange={(value) => setExportConfig(prev => ({ ...prev, format: value }))}
        placeholder="Format"
        className="w-32"
      />
      <Button
        variant="outline"
        size="sm"
        iconName="Download"
        iconPosition="left"
        onClick={handleExport}
      >
        Export
      </Button>
    </div>
  );
};

export default ExportControlPanel;