import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import Icon from '../AppIcon';
import Button from './Button';

const Header = () => {
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const navigate = useNavigate();

  const navigationItems = [
    {
      label: 'Portfolio Overview',
      path: '/portfolio-overview-dashboard',
      icon: 'BarChart3',
      tooltip: 'Strategic portfolio health and performance overview'
    },
    {
      label: 'Financial Analytics',
      path: '/financial-analytics-dashboard',
      icon: 'TrendingUp',
      tooltip: 'Revenue optimization and cash flow analysis'
    },
    {
      label: 'Market Intelligence',
      path: '/market-intelligence-dashboard',
      icon: 'Target',
      tooltip: 'Competitive analysis and pricing optimization'
    }
  ];

  const isActiveRoute = (path) => {
    return location?.pathname === path;
  };

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <header className="fixed top-0 left-0 right-0 z-[1000] bg-white border-b border-border shadow-elevation-1">
      <div className="flex items-center justify-between h-16 px-6">
        {/* Logo Section */}
        <div className="flex items-center">
          <Link to="/portfolio-overview-dashboard" className="flex items-center space-x-3">
            <div className="flex items-center justify-center w-10 h-10 bg-primary rounded-lg">
              <Icon name="Home" size={24} color="white" />
            </div>
            <div className="flex flex-col">
              <span className="text-xl font-bold text-foreground">FindMyHome</span>
              <span className="text-xs text-muted-foreground">Property Analytics</span>
            </div>
          </Link>
        </div>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-1">
          {navigationItems?.map((item) => (
            <Link
              key={item?.path}
              to={item?.path}
              className={`
                relative flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-medium transition-smooth
                ${isActiveRoute(item?.path)
                  ? 'text-primary bg-primary/10 border border-primary/20' :'text-muted-foreground hover:text-foreground hover:bg-muted'
                }
              `}
              title={item?.tooltip}
            >
              <Icon name={item?.icon} size={16} />
              <span>{item?.label}</span>
              {isActiveRoute(item?.path) && (
                <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 w-1 h-1 bg-primary rounded-full" />
              )}
            </Link>
          ))}
        </nav>

        {/* Right Section - Desktop */}
        <div className="hidden md:flex items-center space-x-3">
          <Button variant="ghost" size="sm" iconName="Bell" iconPosition="left" onClick={() => navigate('/notifications')}>
            Alerts
          </Button>
          <Button variant="ghost" size="sm" iconName="User" iconPosition="left" onClick={() => navigate('/profile')}>
            Profile
          </Button>
        </div>

        {/* Mobile Menu Button */}
        <div className="md:hidden">
          <Button
            variant="ghost"
            size="sm"
            iconName={isMobileMenuOpen ? "X" : "Menu"}
            onClick={toggleMobileMenu}
          />
        </div>
      </div>
      {/* Mobile Navigation Overlay */}
      {isMobileMenuOpen && (
        <div className="md:hidden fixed inset-0 top-16 z-[1010] bg-white border-t border-border">
          <nav className="flex flex-col p-4 space-y-2">
            {navigationItems?.map((item) => (
              <Link
                key={item?.path}
                to={item?.path}
                onClick={() => setIsMobileMenuOpen(false)}
                className={`
                  flex items-center space-x-3 px-4 py-3 rounded-lg text-base font-medium transition-smooth
                  ${isActiveRoute(item?.path)
                    ? 'text-primary bg-primary/10 border border-primary/20' :'text-muted-foreground hover:text-foreground hover:bg-muted'
                  }
                `}
              >
                <Icon name={item?.icon} size={20} />
                <div className="flex flex-col">
                  <span>{item?.label}</span>
                  <span className="text-xs text-muted-foreground">{item?.tooltip}</span>
                </div>
              </Link>
            ))}
            
            <div className="border-t border-border pt-4 mt-4 space-y-2">
              <Button variant="ghost" fullWidth iconName="Bell" iconPosition="left" onClick={() => { setIsMobileMenuOpen(false); navigate('/notifications'); }}>
                Notifications
              </Button>
              <Button variant="ghost" fullWidth iconName="User" iconPosition="left" onClick={() => { setIsMobileMenuOpen(false); navigate('/profile-settings'); }}>
                Profile Settings
              </Button>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
};

export default Header;
