import React, { useState, useContext, createContext } from 'react';
import Select from './Select';
import Input from './Input';
import Button from './Button';
import Icon from '../AppIcon';

// Filter Context
const FilterContext = createContext();

export const FilterProvider = ({ children }) => {
  const [filters, setFilters] = useState({
    properties: [],
    dateRange: {
      start: '',
      end: ''
    },
    propertyType: '',
    location: ''
  });

  const updateFilter = (key, value) => {
    setFilters(prev => ({
      ...prev,
      [key]: value
    }));
  };

  const clearFilters = () => {
    setFilters({
      properties: [],
      dateRange: { start: '', end: '' },
      propertyType: '',
      location: ''
    });
  };

  return (
    <FilterContext.Provider value={{ filters, updateFilter, clearFilters }}>
      {children}
    </FilterContext.Provider>
  );
};

export const useFilters = () => {
  const context = useContext(FilterContext);
  if (!context) {
    throw new Error('useFilters must be used within a FilterProvider');
  }
  return context;
};

const GlobalFilterBar = ({ isCollapsed = false }) => {
  const { filters, updateFilter, clearFilters } = useFilters();
  const [isExpanded, setIsExpanded] = useState(false);

  const propertyOptions = [
    { value: 'all', label: 'All Properties' },
    { value: 'residential', label: 'Residential Properties' },
    { value: 'commercial', label: 'Commercial Properties' },
    { value: 'mixed', label: 'Mixed Use Properties' }
  ];

  const propertyTypeOptions = [
    { value: '', label: 'All Types' },
    { value: '1 room studio apartment', label: '1 room studio apartment' },
    { value: '1 bedroom apartment or duplex', label: '1 bedroom apartment or duplex' },
    { value: '2 bedroom apartment or duplex', label: '2 bedroom apartment or duplex' },
    { value: '3 bedroom apartment or duplex', label: '3 bedroom apartment or duplex' }
  ];

  const locationOptions = [
    { value: '', label: 'All Locations' },
    { value: 'downtown', label: 'Downtown' },
    { value: 'suburbs', label: 'Suburbs' },
    { value: 'waterfront', label: 'Waterfront' },
    { value: 'business-district', label: 'Business District' }
  ];

  const handleDateRangeChange = (field, value) => {
    updateFilter('dateRange', {
      ...filters?.dateRange,
      [field]: value
    });
  };

  const hasActiveFilters = () => {
    return filters?.properties?.length > 0 || 
           filters?.dateRange?.start || 
           filters?.dateRange?.end || 
           filters?.propertyType || 
           filters?.location;
  };

  if (isCollapsed) {
    return (
      <div className="sticky top-16 z-[999] bg-white border-b border-border shadow-sm">
        <div className="px-6 py-3">
          <Button
            variant="outline"
            size="sm"
            iconName="Filter"
            iconPosition="left"
            onClick={() => setIsExpanded(!isExpanded)}
            className="w-full md:w-auto"
          >
            Filters {hasActiveFilters() && `(${Object.values(filters)?.filter(v => v && (Array.isArray(v) ? v?.length > 0 : true))?.length})`}
          </Button>
        </div>
        {isExpanded && (
          <div className="px-6 pb-4 bg-muted/30 border-t border-border">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mt-4">
              <Select
                label="Properties"
                options={propertyOptions}
                value={filters?.properties}
                onChange={(value) => updateFilter('properties', value)}
                multiple
                searchable
                placeholder="Select properties..."
              />
              
              <Select
                label="Property Type"
                options={propertyTypeOptions}
                value={filters?.propertyType}
                onChange={(value) => updateFilter('propertyType', value)}
                placeholder="Select type..."
              />
              
              <Select
                label="Location"
                options={locationOptions}
                value={filters?.location}
                onChange={(value) => updateFilter('location', value)}
                placeholder="Select location..."
              />
              
              <div className="flex items-end space-x-2">
                <Button
                  variant="outline"
                  size="sm"
                  iconName="RotateCcw"
                  onClick={clearFilters}
                  disabled={!hasActiveFilters()}
                >
                  Clear
                </Button>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
              <Input
                label="Start Date"
                type="date"
                value={filters?.dateRange?.start}
                onChange={(e) => handleDateRangeChange('start', e?.target?.value)}
              />
              
              <Input
                label="End Date"
                type="date"
                value={filters?.dateRange?.end}
                onChange={(e) => handleDateRangeChange('end', e?.target?.value)}
              />
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="sticky top-16 z-[999] bg-white border-b border-border shadow-sm">
      <div className="px-6 py-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center space-x-2">
            <Icon name="Filter" size={20} color="var(--color-muted-foreground)" />
            <h3 className="text-sm font-medium text-foreground">Filters</h3>
          </div>
          
          {hasActiveFilters() && (
            <Button
              variant="ghost"
              size="sm"
              iconName="RotateCcw"
              iconPosition="left"
              onClick={clearFilters}
            >
              Clear All
            </Button>
          )}
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-6 gap-4">
          <div className="lg:col-span-2">
            <Select
              label="Properties"
              options={propertyOptions}
              value={filters?.properties}
              onChange={(value) => updateFilter('properties', value)}
              multiple
              searchable
              placeholder="Select properties..."
            />
          </div>
          
          <Select
            label="Property Type"
            options={propertyTypeOptions}
            value={filters?.propertyType}
            onChange={(value) => updateFilter('propertyType', value)}
            placeholder="All types"
          />
          
          <Select
            label="Location"
            options={locationOptions}
            value={filters?.location}
            onChange={(value) => updateFilter('location', value)}
            placeholder="All locations"
          />
          
          <Input
            label="Start Date"
            type="date"
            value={filters?.dateRange?.start}
            onChange={(e) => handleDateRangeChange('start', e?.target?.value)}
          />
          
          <Input
            label="End Date"
            type="date"
            value={filters?.dateRange?.end}
            onChange={(e) => handleDateRangeChange('end', e?.target?.value)}
          />
        </div>
      </div>
    </div>
  );
};

export default GlobalFilterBar;
