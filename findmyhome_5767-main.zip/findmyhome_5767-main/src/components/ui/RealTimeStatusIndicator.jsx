import React, { useState, useEffect, createContext, useContext } from 'react';
import Icon from '../AppIcon';

// Status Context
const StatusContext = createContext();

export const StatusProvider = ({ children }) => {
  const [status, setStatus] = useState({
    isConnected: true,
    lastUpdate: new Date(),
    updateInterval: 30000, // 30 seconds
    dataFreshness: 'live'
  });

  useEffect(() => {
    // Simulate WebSocket connection status
    const interval = setInterval(() => {
      setStatus(prev => ({
        ...prev,
        lastUpdate: new Date(),
        isConnected: Math.random() > 0.1 // 90% uptime simulation
      }));
    }, status?.updateInterval);

    return () => clearInterval(interval);
  }, [status?.updateInterval]);

  const updateStatus = (newStatus) => {
    setStatus(prev => ({ ...prev, ...newStatus }));
  };

  return (
    <StatusContext.Provider value={{ status, updateStatus }}>
      {children}
    </StatusContext.Provider>
  );
};

export const useStatus = () => {
  const context = useContext(StatusContext);
  if (!context) {
    throw new Error('useStatus must be used within a StatusProvider');
  }
  return context;
};

const RealTimeStatusIndicator = ({ position = 'header' }) => {
  const { status } = useStatus();
  const [showDetails, setShowDetails] = useState(false);

  const getStatusColor = () => {
    if (!status?.isConnected) return 'text-error';
    
    const timeDiff = Date.now() - status?.lastUpdate?.getTime();
    if (timeDiff < 60000) return 'text-success'; // Less than 1 minute
    if (timeDiff < 300000) return 'text-warning'; // Less than 5 minutes
    return 'text-error'; // More than 5 minutes
  };

  const getStatusText = () => {
    if (!status?.isConnected) return 'Disconnected';
    
    const timeDiff = Date.now() - status?.lastUpdate?.getTime();
    if (timeDiff < 60000) return 'Live';
    if (timeDiff < 300000) return 'Recent';
    return 'Stale';
  };

  const formatLastUpdate = () => {
    const now = new Date();
    const diff = now?.getTime() - status?.lastUpdate?.getTime();
    
    if (diff < 60000) return 'Just now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    return status?.lastUpdate?.toLocaleDateString();
  };

  if (position === 'header') {
    return (
      <div className="relative">
        <button
          onClick={() => setShowDetails(!showDetails)}
          className="flex items-center space-x-2 px-3 py-1.5 rounded-lg hover:bg-muted transition-smooth"
        >
          <div className={`w-2 h-2 rounded-full ${getStatusColor()?.replace('text-', 'bg-')} animate-pulse`} />
          <span className={`text-sm font-medium ${getStatusColor()}`}>
            {getStatusText()}
          </span>
          <Icon name="ChevronDown" size={14} className={`transition-transform ${showDetails ? 'rotate-180' : ''}`} />
        </button>
        {showDetails && (
          <div className="absolute right-0 top-full mt-2 w-64 bg-white border border-border rounded-lg shadow-elevation-2 z-[1020] p-4">
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-foreground">Connection Status</span>
                <div className="flex items-center space-x-2">
                  <div className={`w-2 h-2 rounded-full ${getStatusColor()?.replace('text-', 'bg-')}`} />
                  <span className={`text-sm ${getStatusColor()}`}>{getStatusText()}</span>
                </div>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Last Update</span>
                <span className="text-sm text-foreground font-data">{formatLastUpdate()}</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Data Freshness</span>
                <span className="text-sm text-foreground capitalize">{status?.dataFreshness}</span>
              </div>
              
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">Update Interval</span>
                <span className="text-sm text-foreground font-data">{status?.updateInterval / 1000}s</span>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  // Floating status indicator
  return (
    <div className="fixed bottom-4 right-4 z-[1000]">
      <button
        onClick={() => setShowDetails(!showDetails)}
        className="flex items-center space-x-2 bg-white border border-border rounded-lg px-3 py-2 shadow-elevation-2 hover:shadow-elevation-3 transition-smooth"
      >
        <div className={`w-2 h-2 rounded-full ${getStatusColor()?.replace('text-', 'bg-')} animate-pulse`} />
        <span className={`text-sm font-medium ${getStatusColor()}`}>
          {getStatusText()}
        </span>
        <span className="text-xs text-muted-foreground font-data">
          {formatLastUpdate()}
        </span>
      </button>
      {showDetails && (
        <div className="absolute bottom-full right-0 mb-2 w-64 bg-white border border-border rounded-lg shadow-elevation-3 p-4">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm font-medium text-foreground">Real-time Data Status</span>
              <Icon name="Activity" size={16} className={getStatusColor()} />
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Connection</span>
                <span className={`text-sm font-medium ${getStatusColor()}`}>
                  {status?.isConnected ? 'Connected' : 'Disconnected'}
                </span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Last Sync</span>
                <span className="text-sm text-foreground font-data">{formatLastUpdate()}</span>
              </div>
              
              <div className="flex justify-between">
                <span className="text-sm text-muted-foreground">Next Update</span>
                <span className="text-sm text-foreground font-data">
                  {Math.ceil((status?.updateInterval - (Date.now() - status?.lastUpdate?.getTime())) / 1000)}s
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default RealTimeStatusIndicator;