import React from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
import "./styles/tailwind.css";
import "./styles/index.css";

const container = document.getElementById("root");
const root = createRoot(container);

// Load external Rocket script only when not embedded (avoids fetch errors in builder preview)
try {
  if (typeof window !== 'undefined' && window.self === window.top) {
    const script = document.createElement('script');
    script.type = 'module';
    script.src = 'https://static.rocket.new/rocket-web.js?_cfg=https%3A%2F%2Ffindmyhome7864back.builtwithrocket.new&_be=https%3A%2F%2Fapplication.rocket.new&_v=0.1.8';
    script.async = true;
    script.onerror = () => { console.warn('Rocket script failed to load — continuing without it.'); };
    document.head.appendChild(script);
  }
} catch (e) {
  // swallow errors to prevent breaking the app in preview
  // eslint-disable-next-line no-console
  console.warn('Error loading external scripts', e);
}

root.render(<App />);
