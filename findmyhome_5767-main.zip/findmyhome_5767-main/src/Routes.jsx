import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";
import NotFound from "pages/NotFound";
import HomeDashboard from './pages/home-dashboard';
import MarketIntelligenceDashboard from './pages/market-intelligence-dashboard';
import PortfolioOverviewDashboard from './pages/portfolio-overview-dashboard';
import FinancialAnalyticsDashboard from './pages/financial-analytics-dashboard';
import TenantManagementDashboard from './pages/tenant-management-dashboard';
import PropertyDetailsManagement from './pages/property-details-management';
import ProfilePage from './pages/profile';
import ComprehensiveReportsCenter from './pages/comprehensive-reports-center';
import ChatPage from './pages/chat';
import NotificationsPage from './pages/notifications';
import ProfileSettingsPage from './pages/profile-settings';
import SettingsPage from './pages/settings';

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
      <ScrollToTop />
      <RouterRoutes>
        {/* Define your route here */}
        <Route path="/" element={<HomeDashboard />} />
        <Route path="/market-intelligence-dashboard" element={<MarketIntelligenceDashboard />} />
        <Route path="/portfolio-overview-dashboard" element={<PortfolioOverviewDashboard />} />
        <Route path="/financial-analytics-dashboard" element={<FinancialAnalyticsDashboard />} />
        <Route path="/chat" element={<ChatPage />} />
        <Route path="/tenant-management-dashboard" element={<TenantManagementDashboard />} />
        <Route path="/property-details-management" element={<PropertyDetailsManagement />} />
        <Route path="/comprehensive-reports-center" element={<ComprehensiveReportsCenter />} />
        <Route path="/profile" element={<ProfilePage />} />
        <Route path="/profile-settings" element={<ProfileSettingsPage />} />
        <Route path="/notifications" element={<NotificationsPage />} />
        <Route path="/settings" element={<SettingsPage />} />
        <Route path="*" element={<NotFound />} />
      </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;
